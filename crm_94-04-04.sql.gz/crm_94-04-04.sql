-- phpMyAdmin SQL Dump
-- version 4.2.9.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 25, 2015 at 06:54 AM
-- Server version: 5.5.39
-- PHP Version: 5.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `crm`
--

-- --------------------------------------------------------

--
-- Table structure for table `access`
--

CREATE TABLE IF NOT EXISTS `access` (
`id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL DEFAULT '-1',
  `page_name` varchar(50) NOT NULL,
  `is_group` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `access`
--

INSERT INTO `access` (`id`, `group_id`, `page_name`, `is_group`) VALUES
(1, 1, 'home', 1);

-- --------------------------------------------------------

--
-- Table structure for table `access_det`
--

CREATE TABLE IF NOT EXISTS `access_det` (
`id` int(11) NOT NULL,
  `acc_id` int(11) NOT NULL,
  `frase` varchar(100) CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `airline`
--

CREATE TABLE IF NOT EXISTS `airline` (
`id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `airline`
--

INSERT INTO `airline` (`id`, `name`) VALUES
(1, 'آسمان'),
(2, 'ماهان'),
(3, 'ایران ایر'),
(4, 'تابان'),
(5, 'آتا'),
(6, ' کیش ایر'),
(7, 'ایرتور'),
(8, 'قطرایر'),
(9, 'گلف ایر'),
(10, 'ترکیش'),
(11, ' امارات'),
(12, 'فلای دبی');

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE IF NOT EXISTS `cache` (
`id` bigint(20) NOT NULL,
  `tableName` varchar(150) COLLATE utf8_persian_ci NOT NULL,
  `data` longtext COLLATE utf8_persian_ci NOT NULL,
  `query` mediumtext COLLATE utf8_persian_ci NOT NULL,
  `createTime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `viewCount` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE IF NOT EXISTS `city` (
`id` int(11) NOT NULL,
  `name` varchar(150) COLLATE utf8_persian_ci NOT NULL,
  `iata` varchar(10) COLLATE utf8_persian_ci NOT NULL,
  `country_id` int(11) NOT NULL DEFAULT '1',
  `typ` int(11) NOT NULL DEFAULT '1' COMMENT 'یک داخلی دو خارجی سه زیارتی'
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`id`, `name`, `iata`, `country_id`, `typ`) VALUES
(1, 'مشهد', 'MHD', 1, 1),
(2, 'تهران', 'THR', 1, 1),
(3, 'کیش', 'KIH', 1, 1),
(4, 'قشم', 'QSM', 1, 1),
(5, 'تایلند', '', 1, 2),
(6, 'مالزی', '', 1, 1),
(7, 'سنگاپور', '', 1, 2),
(8, 'هنگ کنگ', '', 1, 2),
(9, 'بلغارستان', '', 1, 2),
(10, 'روسیه', '', 1, 12),
(11, 'اروپا', '', 1, 2),
(12, 'ارمنستان', '', 1, 2),
(13, 'آفريقاي جنوبي', '', 1, 2),
(14, 'دبی', '', 1, 2),
(15, 'استانبول', '', 1, 2),
(16, 'آنتالیا', '', 1, 2),
(17, 'هند', '', 1, 2),
(18, 'چین', '', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `conf`
--

CREATE TABLE IF NOT EXISTS `conf` (
`id` int(11) NOT NULL,
  `key` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `value` mediumtext COLLATE utf8_persian_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `conf`
--

INSERT INTO `conf` (`id`, `key`, `value`) VALUES
(1, 'app', 'CRM'),
(2, 'title', 'CRM'),
(3, 'sender', 'info@gohar.ir'),
(4, 'sender_name', 'CRM'),
(5, 'changepass_subject', 'تغییر رمز عبور'),
(6, 'changepass_body', 'رمز عبور شما<br/>\r\n#pass#><br/>\r\nمی باشد'),
(7, 'hasPaper', 'TRUE'),
(8, 'home_page', 'home');

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE IF NOT EXISTS `country` (
`id` int(11) NOT NULL,
  `name` varchar(500) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`id`, `name`) VALUES
(1, 'ایران'),
(2, 'ترکیه');

-- --------------------------------------------------------

--
-- Table structure for table `factor`
--

CREATE TABLE IF NOT EXISTS `factor` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tarikh` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_creator` int(11) NOT NULL,
  `marhale` varchar(100) COLLATE utf8_persian_ci NOT NULL DEFAULT 'profile',
  `is_tasfieh` int(11) NOT NULL,
  `tarikh_tasfieh` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `commision` int(11) NOT NULL,
  `takhfif` int(11) NOT NULL,
  `jaieze` int(11) NOT NULL,
  `commision_girande` int(11) NOT NULL,
  `mablagh` int(11) NOT NULL,
  `mob` varchar(15) COLLATE utf8_persian_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `factor`
--

INSERT INTO `factor` (`id`, `user_id`, `tarikh`, `user_creator`, `marhale`, `is_tasfieh`, `tarikh_tasfieh`, `commision`, `takhfif`, `jaieze`, `commision_girande`, `mablagh`, `mob`, `email`) VALUES
(1, 48, '2015-06-25 10:17:26', 24, 'khadamat_1', 0, '0000-00-00 00:00:00', 1500000, 0, 0, 0, 8500000, '09367948449', 'r_abbasi63@yahoo.com');

-- --------------------------------------------------------

--
-- Table structure for table `grooh_khooni`
--

CREATE TABLE IF NOT EXISTS `grooh_khooni` (
`id` int(11) NOT NULL,
  `name` varchar(10) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `grooh_khooni`
--

INSERT INTO `grooh_khooni` (`id`, `name`) VALUES
(1, 'A+'),
(2, 'B+'),
(3, 'AB+'),
(4, 'A-'),
(5, 'B-'),
(6, 'AB-'),
(7, 'O-'),
(8, 'O+');

-- --------------------------------------------------------

--
-- Table structure for table `grop`
--

CREATE TABLE IF NOT EXISTS `grop` (
`id` int(11) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `en` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grop`
--

INSERT INTO `grop` (`id`, `name`, `en`) VALUES
(1, 'ارشد', 1),
(2, 'کانتر', 1),
(3, 'مشتری', 1),
(4, 'حسابدار', 1);

-- --------------------------------------------------------

--
-- Table structure for table `hotel`
--

CREATE TABLE IF NOT EXISTS `hotel` (
`id` int(11) NOT NULL,
  `khadamat_factor_id` int(11) NOT NULL,
  `maghsad_id` int(11) NOT NULL,
  `az_tarikh` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ta_tarikh` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `gohar_hotel_id` int(11) NOT NULL DEFAULT '-1',
  `adl` int(11) NOT NULL,
  `chd` int(11) NOT NULL,
  `inf` int(11) NOT NULL,
  `factor_id` int(11) NOT NULL,
  `name` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `star` int(11) NOT NULL DEFAULT '5',
  `room_count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hotel_room`
--

CREATE TABLE IF NOT EXISTS `hotel_room` (
`id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `extra_service` int(11) NOT NULL,
  `extra_service_chd` int(11) NOT NULL,
  `gasht` tinyint(1) NOT NULL,
  `transfer_raft` tinyint(1) NOT NULL,
  `transfer_vasat` tinyint(1) NOT NULL,
  `transfer_bargasht` tinyint(1) NOT NULL,
  `paziraii` tinyint(1) NOT NULL,
  `raft_city` int(11) NOT NULL,
  `raft_airline` int(11) NOT NULL,
  `raft_shomare` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `raft_saat_khorooj` time NOT NULL,
  `raft_saat_vorood` time NOT NULL,
  `vasat_city` int(11) NOT NULL,
  `vasat_airline` int(11) NOT NULL,
  `vasat_shomare` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `vasat_saat_khorooj` time NOT NULL,
  `vasat_saat_vorood` time NOT NULL,
  `bargasht_city` int(11) NOT NULL,
  `bargasht_airline` int(11) NOT NULL,
  `bargasht_shomare` int(11) NOT NULL,
  `bargasht_saat_khorooj` time NOT NULL,
  `bargasht_saat_vorood` time NOT NULL,
  `hotel_id` int(11) NOT NULL,
  `khadamat_factor_id` int(11) NOT NULL,
  `factor_id` int(11) NOT NULL,
  `adl` int(11) NOT NULL,
  `chd` int(11) NOT NULL,
  `inf` int(11) NOT NULL,
  `zarfiat` int(11) NOT NULL,
  `tmp` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `khadamat`
--

CREATE TABLE IF NOT EXISTS `khadamat` (
`id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `toz` mediumtext COLLATE utf8_persian_ci NOT NULL,
  `typ` int(11) NOT NULL DEFAULT '1' COMMENT 'یک پرواز ، دو هتل ، سه تور ، چهار کدملی و پنج شماره پاسپورت',
  `ordering` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `khadamat`
--

INSERT INTO `khadamat` (`id`, `name`, `toz`, `typ`, `ordering`) VALUES
(1, 'بلیت هواپیما داخلی', '', 1, 0),
(2, 'هتل داخلی', '', 2, 0),
(3, 'تور داخلی', '', 3, 0),
(4, 'ویزای شینگن', '', 4, 0),
(5, 'ویزای آمریکا', '', 5, 0),
(6, 'ویزای دبی', '', 5, 0),
(7, 'ویزای چین', '', 1, 0),
(8, 'ویزای تایلند', '', 1, 0),
(9, 'ویزای مالزی', '', 1, 0),
(10, 'ویزای ارمنستان', '', 1, 0),
(11, 'ویزای تاجیکستان', '', 1, 0),
(12, 'ویزای آذربایجان', '', 1, 0),
(13, 'ویزای مسکو', '', 1, 0),
(14, 'ویزای قزاقستان', '', 1, 0),
(15, 'ویزای ترکمنستان', '', 1, 0),
(16, 'ویزای هند', '', 1, 0),
(17, 'ویزای سنگاپور', '', 1, 0),
(18, 'تور خارجی', '', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `khadamat_factor`
--

CREATE TABLE IF NOT EXISTS `khadamat_factor` (
`id` int(11) NOT NULL,
  `factor_id` int(11) NOT NULL,
  `khadamat_id` int(11) NOT NULL,
  `mablagh` int(11) NOT NULL DEFAULT '0',
  `comission` int(11) NOT NULL DEFAULT '0',
  `jayeze` int(11) NOT NULL DEFAULT '0',
  `jayeze_code` varchar(200) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `khadamat_factor`
--

INSERT INTO `khadamat_factor` (`id`, `factor_id`, `khadamat_id`, `mablagh`, `comission`, `jayeze`, `jayeze_code`) VALUES
(1, 1, 1, 4000000, 1000000, 0, ''),
(2, 1, 6, 4500000, 500000, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `khadamat_tamin`
--

CREATE TABLE IF NOT EXISTS `khadamat_tamin` (
`id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `toz` mediumtext COLLATE utf8_persian_ci NOT NULL,
  `khadamat_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `khadamat_tamin`
--

INSERT INTO `khadamat_tamin` (`id`, `name`, `toz`, `khadamat_id`) VALUES
(1, 'رفت', '', 1),
(2, 'هتل داخلی', '', 2),
(3, 'تور داخلی', '', 3),
(4, 'ویزای شینگن', '', 4),
(5, 'ویزای آمریکا', '', 5),
(6, 'برگشت', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE IF NOT EXISTS `log` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `regdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `page` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `toz` mediumtext COLLATE utf8_persian_ci NOT NULL,
  `extra` mediumtext COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mosafer`
--

CREATE TABLE IF NOT EXISTS `mosafer` (
`id` int(11) NOT NULL,
  `fname` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `lname` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `code_melli` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `passport` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `passport_engheza` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `gender` int(11) NOT NULL DEFAULT '1',
  `age` varchar(4) COLLATE utf8_persian_ci NOT NULL DEFAULT 'adl',
  `tarikh_tavalod` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `khadamat_factor_id` int(11) NOT NULL,
  `ticket_number` varchar(15) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `mosafer`
--

INSERT INTO `mosafer` (`id`, `fname`, `lname`, `code_melli`, `passport`, `passport_engheza`, `gender`, `age`, `tarikh_tavalod`, `khadamat_factor_id`, `ticket_number`) VALUES
(49, 'رقیه', 'عباسی', '0940033968', '', '0000-00-00 00:00:00', 0, 'adl', '1984-06-24 00:00:00', 1, ''),
(50, 'ملیحه', 'ناصحی', '0944650813', '', '0000-00-00 00:00:00', 0, 'adl', '1985-06-25 00:00:00', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `paper_attach_type`
--

CREATE TABLE IF NOT EXISTS `paper_attach_type` (
`id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `extention` varchar(10) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `paper_attach_type`
--

INSERT INTO `paper_attach_type` (`id`, `name`, `extention`) VALUES
(1, 'pdf', 'pdf'),
(2, 'word', 'doc'),
(3, 'pic', 'img');

-- --------------------------------------------------------

--
-- Table structure for table `paper_history`
--

CREATE TABLE IF NOT EXISTS `paper_history` (
`id` int(11) NOT NULL,
  `letter_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_sender_id` int(11) NOT NULL,
  `tarikh` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `in_cartable` tinyint(1) NOT NULL DEFAULT '1',
  `vaziat` int(11) NOT NULL DEFAULT '1' COMMENT 'وضعیت یک خوانده نشده و دو خوانده شده و ۳ ارجاع شده۴ یعنی آرشیو',
  `is_roonevesht` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `paper_history`
--

INSERT INTO `paper_history` (`id`, `letter_id`, `user_id`, `user_sender_id`, `tarikh`, `in_cartable`, `vaziat`, `is_roonevesht`) VALUES
(1, 1, 20, 18, '2015-04-15 00:00:00', 0, 2, 0),
(2, 1, 19, 18, '2015-04-15 00:00:00', 1, 2, 0),
(3, 1, 21, 18, '2015-04-15 00:00:00', 1, 1, 1),
(5, 1, 18, 20, '2015-05-06 00:00:00', 0, 3, 0),
(6, 1, 20, 18, '2015-05-06 00:00:00', 0, 2, 0),
(7, 1, 18, 20, '2015-05-06 00:00:00', 0, 3, 1),
(8, 1, 20, 18, '2015-05-06 00:00:00', 0, 2, 1),
(9, 1, 19, 20, '2015-05-06 00:00:00', 1, 2, 0),
(10, 1, 18, 20, '2015-05-06 00:00:00', 0, 3, 1),
(11, 1, 20, 18, '2015-05-06 00:00:00', 0, 2, 0),
(12, 1, 19, 18, '2015-05-06 00:00:00', 1, 2, 1),
(13, 1, 18, 20, '2015-05-06 00:00:00', 0, 3, 0),
(14, 1, 20, 18, '2015-05-06 00:00:00', 0, 2, 0),
(15, 1, 18, 20, '2015-05-06 00:00:00', 0, 3, 1),
(16, 2, 20, 18, '2015-05-06 00:00:00', 1, 4, 0),
(17, 2, 19, 18, '2015-05-06 00:00:00', 1, 2, 1),
(18, 5, 20, 18, '2015-05-07 00:00:00', 1, 2, 0),
(19, 6, 19, 18, '2015-05-07 00:00:00', 1, 2, 0),
(20, 7, 20, 18, '2015-05-07 00:00:00', 1, 2, 0),
(21, 8, 20, 18, '2015-05-07 00:00:00', 1, 2, 0),
(22, 9, 20, 18, '2015-05-07 00:00:00', 1, 2, 0),
(23, 10, 20, 18, '2015-05-07 00:00:00', 1, 2, 0),
(24, 10, 19, 18, '2015-05-07 00:00:00', 1, 2, 1),
(25, 14, 19, 18, '2015-05-10 00:00:00', 1, 1, 0),
(26, 15, 19, 18, '2015-05-10 00:00:00', 1, 1, 0),
(27, 17, 19, 18, '2015-05-10 00:00:00', 1, 2, 0),
(28, 24, 19, 18, '2015-05-10 00:00:00', 1, 1, 0),
(29, 24, 21, 18, '2015-05-10 00:00:00', 1, 1, 0),
(30, 25, 18, 19, '2015-05-10 00:00:00', 0, 2, 0),
(31, 25, 19, 18, '2015-05-10 00:00:00', 0, 3, 0),
(32, 25, 20, 18, '2015-05-10 00:00:00', 1, 1, 1),
(33, 25, 18, 19, '2015-05-10 00:00:00', 1, 2, 0),
(34, 25, 18, 19, '2015-05-10 00:00:00', 1, 2, 0),
(35, 26, 18, 19, '2015-05-12 00:00:00', 1, 2, 0),
(36, 26, 18, 19, '2015-05-12 00:00:00', 1, 2, 0),
(37, 26, 20, 19, '2015-05-12 00:00:00', 1, 1, 0),
(38, 27, 33, 42, '2015-06-13 00:00:00', 1, 2, 0),
(39, 27, 28, 42, '2015-06-13 00:00:00', 1, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `paper_letter`
--

CREATE TABLE IF NOT EXISTS `paper_letter` (
`id` int(11) NOT NULL,
  `mozoo` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `shomare` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `user_creator_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `paper_letter`
--

INSERT INTO `paper_letter` (`id`, `mozoo`, `shomare`, `user_creator_id`, `type_id`) VALUES
(1, 'موضوع یک', '1562', 18, 4),
(2, 'new', '12345678', 18, 3),
(3, 'غر غر های عبدی', '156325', 18, 2),
(4, 'غر غر های عبدی', '234567', 20, 4),
(5, 'معرفی نرم افزار آساد', '۱۲۳۴', 18, 4),
(6, 'wwasdsa', '156325df', 18, 3),
(7, 'پ۱۱', '5456465', 18, 2),
(8, 'm12', '2131323', 18, 1),
(9, 'fgdgf', '3243434', 18, 3),
(10, 'hgfhgfhgf', '67435454', 18, 2),
(11, 'تستس', '15633', 20, 3),
(12, 'wwasdsa', '15623', 19, 4),
(13, 'gfhgfh', '345454', 18, 3),
(14, 'موضوع یک', '1', 18, 3),
(15, 'asdad', '2', 18, 3),
(16, 'غر غر های عبدی', '156322', 18, 4),
(17, 'موضوع دو', '159951', 18, 3),
(18, 'موضوع سه', '15963', 19, 3),
(19, 'dfsafsad', '32423434', 18, 3),
(20, 'xwadsd', '898089', 18, 3),
(21, 'ghghfgh', '86932876543', 18, 3),
(22, 'fjcdfbjmcbv', '1239989', 18, 3),
(23, ', .bn,v,mbm', '5414123434', 18, 3),
(24, 'sdfdsfd', '22132132', 18, 3),
(25, 'سلام', '2222', 19, 3),
(26, 'مرخصی', '1366', 19, 1),
(27, 'عادی', '4567', 42, 3);

-- --------------------------------------------------------

--
-- Table structure for table `paper_letter_det`
--

CREATE TABLE IF NOT EXISTS `paper_letter_det` (
`id` int(11) NOT NULL,
  `letter_id` int(11) NOT NULL,
  `user_creator_id` int(11) NOT NULL,
  `tarikh` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `matn` mediumtext COLLATE utf8_persian_ci NOT NULL,
  `emza` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'امضا شده است یا خیر',
  `is_pishnevis` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `paper_letter_det`
--

INSERT INTO `paper_letter_det` (`id`, `letter_id`, `user_creator_id`, `tarikh`, `matn`, `emza`, `is_pishnevis`) VALUES
(1, 1, 18, '2015-04-15 00:00:00', '<p>dxddd</p>\r\n', 0, 0),
(5, 1, 20, '2015-05-06 00:00:00', '<p>dsssssssss</p>\r\n', 0, 0),
(6, 1, 18, '2015-05-06 00:00:00', '<p>تو حاج میرزایی</p>\r\n', 1, 0),
(7, 1, 20, '2015-05-06 00:00:00', '<p>تو هم شاک.....ری عی</p><p>ها ها ....<img alt="wink" src="http://192.168.2.80/paper/assets/js/ckeditor/plugins/smiley/images/wink_smile.png" style="height:23px; width:23px" title="wink" /></p>', 1, 0),
(8, 1, 18, '2015-05-06 00:00:00', '<p>asdasdasdsdasdas</p>\r\n', 0, 0),
(9, 1, 20, '2015-05-06 00:00:00', '<p dir="RTL">جمعی از معلمان سراسر کشور پیش از ظهر امروز با رهبر معظم انقلاب اسلامی دیدار می&zwnj;کنند.</p>\r\n\r\n<p dir="RTL">به گزارش &laquo;تابناک&raquo;، به نقل از پایگاه اطلاع&zwnj;رسانی دفتر حفظ و نشر آثار حضرت آیت&zwnj;الله&zwnj;&zwnj;العظمی خامنه&zwnj;ای، جمعی از معلمان سراسر کشور پیش از ظهر امروز با رهبر معظم انقلاب اسلامی دیدار می&zwnj;کنند.</p>\r\n\r\n<p dir="RTL">مهم&zwnj;ترین فرازهای بیانات رهبر انقلاب به قرار زیر است:</p>\r\n\r\n<p dir="RTL">* هیبت ملت و نظام اسلامی باید محفوظ بماند/ این چند روز 2 مقام رسمی سیاسی امریکا تهدید نظامی کردند/ مذاکره زیر شبح تهدید چه معنایی دارد/ ملت مذاکره در سایه تهدید را بر نمی&zwnj;تابد/ چرا غلط زیادی و تهدید به حمله نظامی می&zwnj;کنند/ زمان رئیس&zwnj;جمهور قبلی امریکا گفتم دوران بزن در رو تمام شده/ پایتان گیر می&zwnj;افتد/ ملت ایران متعرض را رها نمی&zwnj;کند</p>\r\n\r\n<p dir="RTL">* آمریکا به مذاکرات کمتر از ما احتیاج ندارد تا بگوید ایران را پای میز مذاکره آوردیم و فلان مطلب را به او تحمیل کردیم/ با مذاکرات در زیر شبح تهدید موافق نیستم/ مذاکره&zwnj;کنندگان ما بروند با رعایت خطوط اصلی مذاکره کنند اما تحمیل، تحقیر و تهدید را هرگز تحمل نکنند</p>\r\n\r\n<p dir="RTL">&nbsp;</p>\r\n\r\n<p dir="RTL">* امریکا از جنایت عظیم سعودی در یمن حمایت می&zwnj;کند و به آنها اطلاعات نظامی و سلاح می&zwnj;دهد/ بی&zwnj;آبرویی از این بیشتر؟/ یک ملت را محاصره غذایی دارویی و انرژی کرده&zwnj;اید و می&zwnj;گویید کسی کمک نکند؟</p>\r\n\r\n<p dir="RTL">* آموزش و پرورش کانون اساسی برای خلق دنیای آینده است/ هرچه برای این دستگاه هزینه کنیم هزینه نیست سرمایه&zwnj;گذاری است/ مسئولان باید معیشت معلمان را مورد توجه ویژه و جزء مسائل درجه یک قرار دهند.</p>\r\n\r\n<p><br />\r\n<img alt="heart" src="http://192.168.2.80/paper/assets/js/ckeditor/plugins/smiley/images/heart.png" style="height:23px; width:23px" title="heart" /></p>\r\n\r\n<p dir="RTL">&nbsp;</p>\r\n\r\n<p dir="RTL">این خبر در حال تکمیل است</p>\r\n\r\n<p><img alt="cheeky" src="http://192.168.2.80/paper/assets/js/ckeditor/plugins/smiley/images/tongue_smile.png" style="height:23px; width:23px" title="cheeky" /></p>\r\n', 0, 0),
(10, 1, 18, '2015-05-06 00:00:00', '<p style="text-align:justify">الیاس نادران نماینده مردم تهران در مجلس شورای اسلامی در گفت&zwnj;وگو با خبرنگار پارلمانی<a href="http://www.farsnews.com/" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(176, 37, 37);">خبرگزاری فارس</a>، با اشاره به پیگیری سؤال از وزیر نفت و عدم دریافت هرگونه پاسخی از سوی زنگنه، گفت: پرونده کرسنت از ناحیه طرف ایرانی هیچ پیشرفتی نداشته است.</p>\r\n\r\n<p style="text-align:justify">وی با یادآوری محکوم شدن ایران در داوری لاهه اظهار داشت: مسئله اساسی درباره کرسنت این است که آنهایی که این فساد را انجام داده و در تخلف دخیل بوده&zwnj;اند نه تنها محاکمه نشدند بلکه از سوی وزیر به سمت&zwnj;هایی نیز منصوب شدند.</p>\r\n\r\n<p style="text-align:justify">نادران یکی از دلایل محکومیت ایران در دادگاه لاهه را اعاده به کار مدیران متخلف در زمینه کرسنت خواند و گفت: وزارت نفت در این باره پاسخ روشنی نداشت.</p>\r\n\r\n<p style="text-align:justify">وی افراد موثر در پرونده&zwnj;های کرسنت، استات&zwnj;اویل و چند پرونده دیگر را مشترک ذکر کرد و خاطرنشان کرد: این افراد اکنون در دولت و غیردولت سمت داشته و مشغول به کارند.</p>\r\n\r\n<p style="text-align:justify">نماینده مردم تهران در مجلس شورای اسلامی گفت: در مورد موضوع کرسنت عدم اعلام وصول سؤال ناشی از هیات رئیسه مجلس نیست چرا که شورای عالی امنیت ملی روال کار را معین کرده اما ایراد به هیات رئیسه مجلس این است که از شورای عالی امنیت ملی مطالبه به جریان انداختن پرونده را نمی&zwnj;کند.</p>\r\n', 1, 0),
(11, 1, 20, '2015-05-06 00:00:00', '<p>gfhfdhhgh</p>\r\n', 0, 0),
(12, 1, 18, '2015-05-06 00:00:00', '<p>asdsadsadasdsadasdsadsadasd</p>\r\n\r\n<p>asdsadasdsadsadsa</p>\r\n\r\n<p>dsadsa</p>\r\n\r\n<p>d</p>\r\n\r\n<p>sadas</p>\r\n\r\n<p>dasd</p>\r\n\r\n<p>sa</p>\r\n', 0, 0),
(13, 1, 20, '2015-05-06 00:00:00', '<p>sasdsadsd</p>\r\n', 0, 0),
(14, 2, 18, '2015-05-06 00:00:00', '<p>hghghghghghg</p>\r\n', 0, 0),
(15, 1, 18, '2015-05-07 00:00:00', '<p>نزن آغا ...</p>\r\n\r\n<p>عه....</p>\r\n\r\n<p><img alt="devil" src="http://192.168.3.80/paper/assets/js/ckeditor/plugins/smiley/images/devil_smile.png" style="height:23px; width:23px" title="devil" /></p>\r\n', 0, 0),
(16, 3, 18, '2015-05-07 00:00:00', '<p>با سلام&nbsp;</p>\r\n\r\n<p>محسن جان این حمید کشت مارو<img alt="angry" src="http://192.168.3.80/paper/assets/js/ckeditor/plugins/smiley/images/angry_smile.png" style="height:23px; width:23px" title="angry" /></p>\r\n', 0, 0),
(17, 4, 20, '2015-05-07 00:00:00', '<p>sdfdsdsfdsfsdsdfsdfsd</p>\r\n', 0, 1),
(18, 5, 18, '2015-05-07 00:00:00', '', 0, 0),
(19, 6, 18, '2015-05-07 00:00:00', '<p>تاریخ اولیه از 1 روز بعد باشد. ولی امروز را بتواند انتخاب کند اما روز قبل کمتر از امروز نشود و امکان جستجو در قبل را هم نداشته باشد</p>\r\n\r\n<p>در عکس تاریخ پرواز Nan/Nan خورده است.</p>\r\n\r\n<p>زمانی که در صفحه ورود اطلاعات هستیم و صفحه برای ورود نام یا نام خانوادگی عوض می شود نام فیلد ورودی هم بیاید.</p>\r\n\r\n<p><a id="asdcasdas" name="asdcasdas"></a></p>\r\n', 0, 0),
(20, 7, 18, '2015-05-07 00:00:00', '', 0, 0),
(21, 8, 18, '2015-05-07 00:00:00', '', 0, 0),
(22, 9, 18, '2015-05-07 00:00:00', '<p>gfhgfhgfhfg</p>\r\n\r\n<p>fghfg</p>\r\n\r\n<p>fghfgh</p>\r\n\r\n<p>fghfg</p>\r\n\r\n<p>gfhfgh</p>\r\n\r\n<p>&nbsp;</p>\r\n', 0, 0),
(23, 10, 18, '2015-05-07 00:00:00', '<p>hkghjfh</p>\r\n', 0, 0),
(24, 11, 20, '2015-05-07 00:00:00', '<p>سیبسیبسیب</p>\r\n', 0, 0),
(25, 12, 19, '2015-05-10 00:00:00', '<p>czsczxczxc</p>\r\n', 0, 0),
(26, 13, 18, '2015-05-10 00:00:00', '<p>3453454</p>\r\n\r\n<p>drgfgdf</p>\r\n', 0, 1),
(27, 14, 18, '2015-05-10 00:00:00', '<p>ssss</p>\r\n', 0, 0),
(28, 15, 18, '2015-05-10 00:00:00', '<p>asdasd</p>\r\n', 0, 0),
(29, 16, 18, '2015-05-10 00:00:00', '<p>سلام</p>\r\n', 1, 1),
(30, 17, 18, '2015-05-10 00:00:00', '<p>تست&nbsp;</p>\r\n', 0, 0),
(31, 18, 19, '2015-05-10 00:00:00', '<p>سشیب</p>\r\n', 0, 1),
(32, 19, 18, '2015-05-10 00:00:00', '<p>dfgfdg</p>\r\n', 0, 1),
(33, 20, 18, '2015-05-10 00:00:00', '<p>sadsad</p>\r\n', 1, 1),
(34, 21, 18, '2015-05-10 00:00:00', '<p>321213kjkmgdds</p>\r\n', 0, 1),
(35, 22, 18, '2015-05-10 00:00:00', '<p>cbnbhnfghfggfhgfxhg</p>\r\n', 0, 1),
(36, 23, 18, '2015-05-10 00:00:00', '<p>fdhnbvnbnvb</p>\r\n', 0, 0),
(37, 24, 18, '2015-05-10 00:00:00', '<p>cgxbv</p>\r\n\r\n<p>gvhf</p>\r\n', 0, 0),
(38, 25, 19, '2015-05-10 00:00:00', '<p>سلام خوبی</p>\r\n', 0, 0),
(39, 25, 18, '2015-05-10 00:00:00', '<p>hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii</p>\r\n', 0, 0),
(40, 25, 19, '2015-05-10 00:00:00', '<p>slm azize delam</p>\r\n', 0, 0),
(41, 25, 19, '2015-05-10 00:00:00', '<p>ششششششششششششششششششششششششششششششش</p>\r\n', 0, 0),
(42, 26, 19, '2015-05-12 00:00:00', '<p>تقاضای درخواست مرخصی دارم.</p>\r\n', 0, 0),
(43, 26, 19, '2015-05-12 00:00:00', '<p>تاریخ 2/25</p>\r\n', 0, 0),
(44, 26, 19, '2015-05-12 00:00:00', '<p>فردا</p>\r\n', 0, 0),
(45, 27, 42, '2015-06-13 00:00:00', '<p>سلام</p>\r\n', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `paper_letter_det_attach`
--

CREATE TABLE IF NOT EXISTS `paper_letter_det_attach` (
`id` int(11) NOT NULL,
  `letter_det_id` int(11) NOT NULL,
  `attach_type_id` int(11) NOT NULL,
  `addr` varchar(1000) COLLATE utf8_persian_ci NOT NULL,
  `toz` mediumtext COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `paper_letter_det_attach`
--

INSERT INTO `paper_letter_det_attach` (`id`, `letter_det_id`, `attach_type_id`, `addr`, `toz`) VALUES
(1, 1, 2, '2015-04-15-04-19-11.jpg', 'تو ۱'),
(2, 1, 1, '2015-04-15-04-19-111.jpg', 'تو ۲'),
(3, 1, 2, '2015-04-15-04-19-112.jpg', 'تو ۳'),
(4, 2, 3, '2015-04-15-04-51-56.jpg', ''),
(5, 1, 3, '2015-04-15-05-17-42.jpg', ''),
(6, 1, 3, '2015-04-15-05-17-42.png', ''),
(7, 5, 1, '2015-05-06-11-54-22.pdf', ''),
(8, 6, 1, '2015-05-06-11-58-07.pdf', 'ندارد'),
(9, 7, 3, '2015-05-06-11-59-37.jpg', 'خودم'),
(10, 8, 1, '2015-05-06-12-06-17.pdf', ''),
(11, 9, 3, '2015-05-06-12-20-31.jpg', 'fgfdgff'),
(12, 10, 1, '2015-05-06-12-23-30.jpg', ''),
(13, 14, 3, '2015-05-06-13-03-20.png', ''),
(14, 15, 3, '2015-05-07-10-16-05.jpg', 'من خوشتیپ'),
(15, 18, 1, '2015-05-07-16-38-51.png', ''),
(16, 19, 3, '2015-05-07-19-41-57.jpg', ''),
(17, 30, 1, '2015-05-10-10-16-57.jpg', ''),
(23, 38, 3, '2015-05-10-14-03-11.jpg', 'ندارد'),
(24, 39, 3, '2015-05-10-14-10-30.png', 'admin'),
(25, 40, 3, '2015-05-10-14-15-09.jpg', 'نداااااااااااارد'),
(26, 41, 3, '2015-05-10-14-32-34.jpg', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `paper_type`
--

CREATE TABLE IF NOT EXISTS `paper_type` (
`id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `paper_type`
--

INSERT INTO `paper_type` (`id`, `name`) VALUES
(1, 'درخواست'),
(2, 'شکواییه'),
(3, 'پیشنهاد'),
(4, 'عادی');

-- --------------------------------------------------------

--
-- Table structure for table `parvaz`
--

CREATE TABLE IF NOT EXISTS `parvaz` (
`id` int(11) NOT NULL,
  `mabda_id` int(11) NOT NULL,
  `maghsad_id` int(11) NOT NULL,
  `airline` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `tarikh` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `saat` time NOT NULL DEFAULT '00:00:00',
  `khadamat_factor_id` int(11) NOT NULL,
  `gohar_voucher_id` int(11) NOT NULL DEFAULT '-1',
  `adl` int(11) NOT NULL,
  `chd` int(11) NOT NULL,
  `inf` int(11) NOT NULL,
  `factor_id` int(11) NOT NULL,
  `is_bargasht` tinyint(1) NOT NULL DEFAULT '0',
  `class_parvaz` varchar(10) COLLATE utf8_persian_ci NOT NULL,
  `saat_vorood` time NOT NULL DEFAULT '00:00:00',
  `airplain` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `shomare` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `ticket_type` int(11) NOT NULL COMMENT 'یک داخلی ، دو خارجی ، سه زیارتی'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `parvaz`
--

INSERT INTO `parvaz` (`id`, `mabda_id`, `maghsad_id`, `airline`, `tarikh`, `saat`, `khadamat_factor_id`, `gohar_voucher_id`, `adl`, `chd`, `inf`, `factor_id`, `is_bargasht`, `class_parvaz`, `saat_vorood`, `airplain`, `shomare`, `ticket_type`) VALUES
(1, 1, 14, '12', '2015-06-26 00:00:00', '11:00:00', 1, 11111, 2, 0, 0, 1, 0, 'y', '00:00:00', 'ایرباس', '1363', 0),
(2, 14, 1, '-1', '2015-06-26 00:00:00', '00:00:00', 1, 11111, 2, 0, 0, 1, 1, '', '00:00:00', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `print_factor`
--

CREATE TABLE IF NOT EXISTS `print_factor` (
`id` int(11) NOT NULL,
  `print_theme_id` int(11) NOT NULL,
  `factor_id` int(11) NOT NULL,
  `tarikh` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(11) NOT NULL,
  `data` mediumtext COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `print_factor`
--

INSERT INTO `print_factor` (`id`, `print_theme_id`, `factor_id`, `tarikh`, `user_id`, `data`) VALUES
(9, 1, 10, '2015-05-20 16:49:25', 23, '{"visa_country":" u0622u0644u0645u0627u0646","visa_type":" u0634u06ccu0646u06afu0646","visa_time":" u06f5 u0647u0641u062au0647","visa_number":"123587","visa_tarikh":"1393/03/16","visa_address":"u0645u0634u0647u062f u0627u06ccu0646u0627","visa_tel":"37648023","visa_jaddress":"u062au0647u0631u0627u0646 u0627u06ccu0646u0627","visa_jtel":"736982525","visa_hazine_mosafer":["fgfgf","878798798787","98798798798798"],"visa_kasr_sefarat":"787979879878","visa_ghimat_nafar":"654654654654","visa_ajancy":"u0644u0627u0641u063au0641u0642u0627u0628u0627u0644u0628u0644u0628"}'),
(10, 1, 10, '2015-05-20 16:54:13', 23, '{"visa_country":" u0622u0644u0645u0627u0646","visa_type":" u0634u06ccu0646u06afu0646","visa_time":" u06f5 u0647u0641u062au0647","visa_number":"123587","visa_tarikh":"1393/03/16","visa_address":"u0645u0634u0647u062f u0627u06ccu0646u0627","visa_tel":"37648023","visa_jaddress":"u062au0647u0631u0627u0646 u0627u06ccu0646u0627","visa_jtel":"777","visa_hazine_mosafer":["1fgfgf","878798798787","98798798798798"],"visa_kasr_sefarat":"787979879878","visa_ghimat_nafar":"654654654654","visa_ajancy":"u0644u0627u0641u063au0641u0642u0627u0628u0627u0644u0628u0644u0628"}'),
(11, 1, 10, '2015-05-20 16:56:16', 23, '{"visa_country":" u0622u0644u0645u0627u0646","visa_type":" u0634u06ccu0646u06afu0646","visa_time":" u06f5 u0647u0641u062au0647","visa_number":"123587","visa_tarikh":"1393/03/16","visa_address":"u0645u0634u0647u062f u0627u06ccu0646u0627","visa_tel":"37648023","visa_jaddress":"u062au0647u0631u0627u0646 u0627u06ccu0646u0627","visa_jtel":"777","visa_hazine_mosafer":["1fgfg45454","878798798787","98798798798798"],"visa_kasr_sefarat":"787979879878","visa_ghimat_nafar":"654654654654","visa_ajancy":"u0644u0627u0641u063au0641u0642u0627u0628u0627u0644u0628u0644u0628"}'),
(12, 1, 10, '2015-05-20 16:56:26', 23, '{"visa_country":" u0622u0644u0645u0627u0646","visa_type":" u0634u06ccu0646u06afu0646","visa_time":" u06f5 u0647u0641u062au0647","visa_number":"123587","visa_tarikh":"1393/03/16","visa_address":"u0645u0634u0647u062f u0627u06ccu0646u0627","visa_tel":"37648023","visa_jaddress":"u062au0647u0631u0627u0646 u0627u06ccu0646u0627","visa_jtel":"777","visa_hazine_mosafer":["1fgfg45454","g","98798798798798"],"visa_kasr_sefarat":"787979879878","visa_ghimat_nafar":"654654654654","visa_ajancy":"u0644u0627u0641u063au0641u0642u0627u0628u0627u0644u0628u0644u0628"}'),
(13, 1, 10, '2015-05-20 16:57:04', 23, '{"visa_country":" u0622u0644u0645u0627u0646","visa_type":" u0634u06ccu0646u06afu0646","visa_time":" u06f5 u0647u0641u062au0647","visa_number":"123587","visa_tarikh":"1393/03/16","visa_address":"u0645u0634u0647u062f u0627u06ccu0646u0627","visa_tel":"37648023","visa_jaddress":"u062au0647u0631u0627u0646 u0627u06ccu0646u0627","visa_jtel":"8888888","visa_hazine_mosafer":["1fgfg45454","g","98798798798798"],"visa_kasr_sefarat":"787979879878","visa_ghimat_nafar":"654654654654","visa_ajancy":"u0644u0627u0641u063au0641u0642u0627u0628u0627u0644u0628u0644u0628"}'),
(14, 1, 10, '2015-05-20 16:57:33', 23, '{"visa_country":" u0622u0644u0645u0627u0646","visa_type":" u0634u06ccu0646u06afu0646","visa_time":" u06f5 u0647u0641u062au0647","visa_number":"123587","visa_tarikh":"1393/03/16","visa_address":"u0645u0634u0647u062f u0627u06ccu0646u0627","visa_tel":"37648023","visa_jaddress":"u062au0647u0631u0627u0646 u0627u06ccu0646u0627","visa_jtel":"8888888","visa_hazine_mosafer":["1fgfg45454","g","7"],"visa_kasr_sefarat":"787979879878","visa_ghimat_nafar":"654654654654","visa_ajancy":"u0644u0627u0641u063au0641u0642u0627u0628u0627u0644u0628u0644u0628"}'),
(19, 2, 11, '2015-05-20 17:50:10', 18, '{"gasht_fathername":"u0639u0644u06cc","gasht_shomare_shenasnameh":"","gasht_tarikh_tavalod":"","gasht_addr":"","gasht_tel_sabet":"","gasht_mob":"","gasht_edad":"","gasht_tarikh":"","gasht_saate":"","gasht_rahnama":"","gasht_rahnama_fathername":"","gasht_card":"","gasht_tour_khadamat":"","gasht_shab":"","gasht_aztarikh_fa":"","gasht_aztarikh_mi":"","gasht_tatarikh_fa":"","gasht_tatarikh_mi":"","gasht_vasile":"","gasht_sherkat":"","gasht_daraje":"","gasht_mabda_terminal":"","gasht_karmozd":"","gasht_ghimat_nafar_rial":"","gasht_ghimat_nafar_toman":""}'),
(20, 2, 11, '2015-05-20 18:29:04', 18, '{"gasht_fathername":"علی","gasht_shomare_shenasnameh":"","gasht_tarikh_tavalod":"","gasht_addr":"","gasht_tel_sabet":"","gasht_mob":"","gasht_edad":"","gasht_tarikh":"","gasht_saate":"","gasht_rahnama":"","gasht_rahnama_fathername":"","gasht_card":"","gasht_tour_khadamat":"","gasht_shab":"","gasht_aztarikh_fa":"","gasht_aztarikh_mi":"","gasht_tatarikh_fa":"","gasht_tatarikh_mi":"","gasht_vasile":"","gasht_sherkat":"","gasht_daraje":"","gasht_mabda_terminal":"","gasht_karmozd":"","gasht_ghimat_nafar_rial":"","gasht_ghimat_nafar_toman":""}'),
(21, 2, 11, '2015-05-20 18:29:14', 18, '{"gasht_fathername":"علی","gasht_shomare_shenasnameh":"","gasht_tarikh_tavalod":"","gasht_addr":"","gasht_tel_sabet":"","gasht_mob":"","gasht_edad":"","gasht_tarikh":"","gasht_saate":"","gasht_rahnama":"","gasht_rahnama_fathername":"","gasht_card":"","gasht_tour_khadamat":"","gasht_shab":"","gasht_aztarikh_fa":"","gasht_aztarikh_mi":"","gasht_tatarikh_fa":"","gasht_tatarikh_mi":"","gasht_vasile":"","gasht_sherkat":"","gasht_daraje":"","gasht_mabda_terminal":"","gasht_karmozd":"","gasht_ghimat_nafar_rial":"","gasht_ghimat_nafar_toman":""}'),
(22, 2, 11, '2015-05-20 18:31:12', 18, '{"gasht_fathername":"علی","gasht_shomare_shenasnameh":"155554","gasht_tarikh_tavalod":"","gasht_addr":"","gasht_tel_sabet":"","gasht_mob":"","gasht_edad":"","gasht_tarikh":"","gasht_saate":"","gasht_rahnama":"","gasht_rahnama_fathername":"","gasht_card":"","gasht_tour_khadamat":"","gasht_shab":"","gasht_aztarikh_fa":"","gasht_aztarikh_mi":"","gasht_tatarikh_fa":"","gasht_tatarikh_mi":"","gasht_vasile":"","gasht_sherkat":"","gasht_daraje":"","gasht_mabda_terminal":"","gasht_karmozd":"","gasht_ghimat_nafar_rial":"","gasht_ghimat_nafar_toman":""}'),
(23, 2, 11, '2015-05-20 18:32:04', 18, '{"gasht_fathername":"علی","gasht_shomare_shenasnameh":"155554","gasht_tarikh_tavalod":"","gasht_addr":"خیابان خاکی","gasht_tel_sabet":"","gasht_mob":"","gasht_edad":"","gasht_tarikh":"","gasht_saate":"","gasht_rahnama":"","gasht_rahnama_fathername":"","gasht_card":"","gasht_tour_khadamat":"","gasht_shab":"","gasht_aztarikh_fa":"","gasht_aztarikh_mi":"","gasht_tatarikh_fa":"","gasht_tatarikh_mi":"","gasht_vasile":"","gasht_sherkat":"","gasht_daraje":"","gasht_mabda_terminal":"","gasht_karmozd":"","gasht_ghimat_nafar_rial":"","gasht_ghimat_nafar_toman":""}'),
(24, 2, 11, '2015-05-20 18:35:03', 18, '{"gasht_fathername":"علی","gasht_shomare_shenasnameh":"155554","gasht_tarikh_tavalod":"","gasht_addr":"خیابان خاکی","gasht_tel_sabet":"","gasht_mob":"09153068145","gasht_edad":"","gasht_tarikh":"","gasht_saate":"","gasht_rahnama":"","gasht_rahnama_fathername":"","gasht_card":"","gasht_tour_khadamat":"","gasht_shab":"","gasht_aztarikh_fa":"","gasht_aztarikh_mi":"","gasht_tatarikh_fa":"","gasht_tatarikh_mi":"","gasht_vasile":"","gasht_sherkat":"","gasht_daraje":"","gasht_mabda_terminal":"","gasht_karmozd":"","gasht_ghimat_nafar_rial":"","gasht_ghimat_nafar_toman":""}'),
(25, 2, 11, '2015-05-20 18:35:43', 18, '{"gasht_fathername":"علی","gasht_shomare_shenasnameh":"155554","gasht_tarikh_tavalod":"1361/2/25","gasht_addr":"خیابان خاکی","gasht_tel_sabet":"","gasht_mob":"09153068145","gasht_edad":"","gasht_tarikh":"","gasht_saate":"","gasht_rahnama":"","gasht_rahnama_fathername":"","gasht_card":"","gasht_tour_khadamat":"","gasht_shab":"","gasht_aztarikh_fa":"","gasht_aztarikh_mi":"","gasht_tatarikh_fa":"","gasht_tatarikh_mi":"","gasht_vasile":"","gasht_sherkat":"","gasht_daraje":"","gasht_mabda_terminal":"","gasht_karmozd":"","gasht_ghimat_nafar_rial":"","gasht_ghimat_nafar_toman":""}'),
(26, 2, 11, '2015-05-20 18:38:08', 18, '{"gasht_fathername":"علی","gasht_shomare_shenasnameh":"155554","gasht_tarikh_tavalod":"1361/2/25","gasht_addr":"خیابان خاکی","gasht_tel_sabet":"","gasht_mob":"09153068145","gasht_edad":"","gasht_tarikh":"","gasht_saate":"","gasht_rahnama":"","gasht_rahnama_fathername":"قلی خان","gasht_card":"","gasht_tour_khadamat":"","gasht_shab":"","gasht_aztarikh_fa":"","gasht_aztarikh_mi":"","gasht_tatarikh_fa":"","gasht_tatarikh_mi":"","gasht_vasile":"","gasht_sherkat":"","gasht_daraje":"","gasht_mabda_terminal":"","gasht_karmozd":"","gasht_ghimat_nafar_rial":"","gasht_ghimat_nafar_toman":""}'),
(27, 1, 10, '2015-05-20 18:39:59', 23, '{"visa_country":" ایران","visa_type":" u0634u06ccu0646u06afu0646","visa_time":" u06f5 u0647u0641u062au0647","visa_number":"123587","visa_tarikh":"1393/03/16","visa_address":"u0645u0634u0647u062f u0627u06ccu0646u0627","visa_tel":"37648023","visa_jaddress":"u062au0647u0631u0627u0646 u0627u06ccu0646u0627","visa_jtel":"8888888","visa_hazine_mosafer":["1fgfg45454","g","7"],"visa_kasr_sefarat":"787979879878","visa_ghimat_nafar":"654654654654","visa_ajancy":"u0644u0627u0641u063au0641u0642u0627u0628u0627u0644u0628u0644u0628"}'),
(28, 1, 10, '2015-05-20 18:50:24', 23, '{"visa_country":" ایران","visa_type":" شینگن","visa_time":" ۵ هفته","visa_number":"123587","visa_tarikh":"1393/03/16","visa_address_tel":"مشهد بلوار فردوسی 37648024","visa_jaddress_jtel":"ندارم","visa_hazine_mosafer":["1.000.000","200.000","1.202.000"],"visa_kasr_sefarat":"2.202.500","visa_ghimat_nafar":"5.000","visa_ajancy":"حسن سیر"}'),
(29, 1, 10, '2015-05-20 18:53:11', 23, '{"visa_country":" ایران","visa_type":" شینگن","visa_time":" ۵ هفته","visa_number":"123587","visa_tarikh":"1393/03/16","visa_address_tel":"مشهد بلوار فردوسی 37648024","visa_jaddress_jtel":"ندارم","visa_pedar":["حسن علی","مهدی","محمد"],"visa_hazine_mosafer":["1.000.000","200.000","1.202.000"],"visa_kasr_sefarat":"2.202.500","visa_ghimat_nafar":"5.000","visa_ajancy":"حسن سیر"}'),
(30, 2, 11, '2015-05-20 18:59:26', 18, '{"gasht_fathername":"علی","gasht_shomare_shenasnameh":"155554","gasht_tarikh_tavalod":["92/2/12","3","6"],"gasht_addr":"خیابان خاکی","gasht_tel_sabet":"","gasht_mob":"09153068145","gasht_edad":"","gasht_tarikh":"","gasht_saate":"","gasht_rahnama":"","gasht_rahnama_fathername":"قلی خان","gasht_card":"","gasht_hazine_mosafer":["","",""],"gasht_code_melli":["","",""],"gasht_nesbat":["","",""],"gasht_tour_khadamat":"","gasht_shab":"","gasht_aztarikh_fa":"","gasht_aztarikh_mi":"","gasht_tatarikh_fa":"","gasht_tatarikh_mi":"","gasht_vasile":"","gasht_sherkat":"","gasht_daraje":"","gasht_mabda_terminal":"","gasht_karmozd":"","gasht_ghimat_nafar_rial":"","gasht_ghimat_nafar_toman":""}'),
(31, 2, 11, '2015-05-20 19:02:41', 18, '{"gasht_fathername":"علی","gasht_shomare_shenasnameh":"155554","gasht_tarikh_tavalod":"Array","gasht_addr":"خیابان خاکی","gasht_tel_sabet":"","gasht_mob":"09153068145","gasht_edad":"","gasht_tarikh":"","gasht_saate":"","gasht_rahnama":"","gasht_rahnama_fathername":"قلی خان","gasht_card":"","gasht_hazine_mosafer":["","",""],"gasht_code_melli":["","",""],"gasht_tarikh_tavalod_frm":["92/25/9","",""],"gasht_nesbat":["","",""],"gasht_tour_khadamat":"","gasht_shab":"","gasht_aztarikh_fa":"","gasht_aztarikh_mi":"","gasht_tatarikh_fa":"","gasht_tatarikh_mi":"","gasht_vasile":"","gasht_sherkat":"","gasht_daraje":"","gasht_mabda_terminal":"","gasht_karmozd":"","gasht_ghimat_nafar_rial":"","gasht_ghimat_nafar_toman":""}'),
(32, 2, 11, '2015-05-20 19:08:52', 18, '{"gasht_fathername":"علی","gasht_shomare_shenasnameh":"155554","gasht_tarikh_tavalod":"1361/2/12","gasht_addr":"خیابان خاکی","gasht_tel_sabet":"","gasht_mob":"09153068145","gasht_edad":"","gasht_tarikh":"","gasht_saate":"","gasht_rahnama":"","gasht_rahnama_fathername":"قلی خان","gasht_card":"","gasht_name":"","gasht_pedar":"","gasht_passport":"","gasht_hazine_mosafer":["","",""],"gasht_code_melli":["","",""],"gasht_tarikh_tavalod_frm":["92/25/9","",""],"gasht_nesbat":["","",""],"gasht_tour_khadamat":"","gasht_shab":"","gasht_aztarikh_fa":"","gasht_aztarikh_mi":"","gasht_tatarikh_fa":"","gasht_tatarikh_mi":"","gasht_vasile":"","gasht_sherkat":"","gasht_daraje":"","gasht_mabda_terminal":"","gasht_karmozd":"","gasht_ghimat_nafar_rial":"","gasht_ghimat_nafar_toman":""}'),
(33, 1, 10, '2015-05-20 19:18:07', 23, '{"visa_country":" ایران","visa_type":" شینگن","visa_time":" ۷ هفته","visa_number":"123587","visa_tarikh":"1393/03/16","visa_address_tel":"مشهد بلوار فردوسی 37648024","visa_jaddress_jtel":"ندارم","visa_pedar":["حسن علی","مهدی","محمد"],"visa_hazine_mosafer":["1.000.000","200.000","1.202.000"],"visa_kasr_sefarat":"2.202.500","visa_ghimat_nafar":"5.000","visa_ajancy":"حسن سیر"}'),
(34, 2, 10, '2015-05-20 19:54:14', 18, '{"gasht_fathername":"","gasht_shomare_shenasnameh":"","gasht_tarikh_tavalod":"","gasht_addr":"","gasht_tel_sabet":"","gasht_mob":"","gasht_edad":"","gasht_tarikh":"","gasht_saate":"","gasht_rahnama":"","gasht_rahnama_fathername":"","gasht_card":"","gasht_name":"fghfg","gasht_pedar":"ggggghf","gasht_passport":"hfghfg","gasht_hazine_mosafer":["hfghfghfgh","gfh","سیبیسب"],"gasht_code_melli":["fgh","fhgfh",""],"gasht_tarikh_tavalod_frm":["gfhfghgfhg","hgfhg",""],"gasht_nesbat":["fhfghf","ghfg",""],"gasht_tour_khadamat":"","gasht_shab":"","gasht_aztarikh_fa":"","gasht_aztarikh_mi":"","gasht_tatarikh_fa":"","gasht_tatarikh_mi":"","gasht_vasile":"","gasht_sherkat":"","gasht_daraje":"","gasht_mabda_terminal":"","gasht_karmozd":"","gasht_ghimat_nafar_rial":"","gasht_ghimat_nafar_toman":""}'),
(35, 2, 10, '2015-05-20 19:57:40', 18, '{"gasht_fathername":"میر عبدالله","gasht_shomare_shenasnameh":"","gasht_tarikh_tavalod":"","gasht_addr":"","gasht_tel_sabet":"","gasht_mob":"","gasht_edad":"","gasht_tarikh":"","gasht_saate":"","gasht_rahnama":"","gasht_rahnama_fathername":"","gasht_card":"","gasht_name":"fghfg","gasht_pedar":"ggggghf","gasht_passport":"hfghfg","gasht_hazine_mosafer":["hfghfghfgh","gfh","سیبیسب"],"gasht_code_melli":["fgh","fhgfh",""],"gasht_tarikh_tavalod_frm":["gfhfghgfhg","hgfhg",""],"gasht_nesbat":["fhfghf","ghfg",""],"gasht_tour_khadamat":"","gasht_shab":"","gasht_aztarikh_fa":"","gasht_aztarikh_mi":"","gasht_tatarikh_fa":"","gasht_tatarikh_mi":"","gasht_vasile":"","gasht_sherkat":"","gasht_daraje":"","gasht_mabda_terminal":"","gasht_karmozd":"","gasht_ghimat_nafar_rial":"","gasht_ghimat_nafar_toman":""}'),
(36, 2, 10, '2015-05-20 20:02:23', 18, '{"gasht_fathername":"میر عبدالله","gasht_shomare_shenasnameh":"","gasht_tarikh_tavalod":"","gasht_addr":"","gasht_tel_sabet":"","gasht_mob":"","gasht_edad":"","gasht_tarikh":"","gasht_saate":"","gasht_rahnama":"","gasht_rahnama_fathername":"","gasht_card":"","gasht_name":"fghfg","gasht_pedar":"ggggghf","gasht_passport":"hfghfg","gasht_hazine_mosafer":["hfghfghfgh","gfh","سیبیسب"],"gasht_code_melli":["fgh","fhgfh",""],"gasht_tarikh_tavalod_frm":["gfhfghgfhg","hgfhg",""],"gasht_nesbat":["fhfghf","ghfg",""],"gasht_tour_khadamat":"","gasht_shab":"","gasht_aztarikh_fa":"","gasht_aztarikh_mi":"","gasht_tatarikh_fa":"","gasht_tatarikh_mi":"","gasht_vasile":"","gasht_sherkat":"","gasht_daraje":"","gasht_mabda_terminal":"","gasht_karmozd":"","gasht_ghimat_nafar_rial":"","gasht_ghimat_nafar_toman":""}'),
(37, 2, 10, '2015-05-20 20:20:48', 18, '{"gasht_fathername":"میر عبدالله","gasht_shomare_shenasnameh":"","gasht_tarikh_tavalod":"","gasht_addr":"","gasht_tel_sabet":"","gasht_mob":"","gasht_edad":"","gasht_tarikh":"","gasht_saate":"","gasht_rahnama":"","gasht_rahnama_fathername":"","gasht_card":"","gasht_name":"fghfg","gasht_pedar":"ggggghf","gasht_passport":"hfghfg","gasht_hazine_mosafer":["hfghfghfgh","gfh","سیبیسب"],"gasht_code_melli":["fgh","fhgfh",""],"gasht_tarikh_tavalod_frm":["gfhfghgfhg","hgfhg",""],"gasht_nesbat":["fhfghf","ghfg",""],"gasht_tour_khadamat":"","gasht_shab":"","gasht_aztarikh_fa":"","gasht_aztarikh_mi":"","gasht_tatarikh_fa":"","gasht_tatarikh_mi":"","gasht_vasile":"","gasht_sherkat":"","gasht_daraje":"","gasht_mabda_terminal":"","gasht_maghsad_terminal":"","gasht_karmozd":"","gasht_ghimat_nafar_rial":"","gasht_ghimat_nafar_toman":"","gasht_leader_rial":"","gasht_leader_toman":"","gasht_ghimat_adl_kharej":"","gasht_ghimat_adl_rial":""}'),
(38, 2, 10, '2015-05-20 20:21:45', 18, '{"gasht_fathername":"میر عبدالله","gasht_shomare_shenasnameh":"","gasht_tarikh_tavalod":"","gasht_addr":"","gasht_tel_sabet":"","gasht_mob":"","gasht_edad":"","gasht_tarikh":"","gasht_saate":"","gasht_rahnama":"","gasht_rahnama_fathername":"","gasht_card":"","gasht_name":"fghfg","gasht_pedar":"ggggghf","gasht_passport":"hfghfg","gasht_hazine_mosafer":["hfghfghfgh","gfh","سیبیسب"],"gasht_code_melli":["fgh","fhgfh",""],"gasht_tarikh_tavalod_frm":["gfhfghgfhg","hgfhg",""],"gasht_nesbat":["fhfghf","ghfg",""],"gasht_tour_khadamat":"","gasht_shab":"","gasht_aztarikh_fa":"","gasht_aztarikh_mi":"","gasht_tatarikh_fa":"","gasht_tatarikh_mi":"","gasht_vasile":"","gasht_sherkat":"","gasht_daraje":"","gasht_mabda_terminal":"","gasht_maghsad_terminal":"","gasht_karmozd":"","gasht_ghimat_nafar_rial":"","gasht_ghimat_nafar_toman":"","gasht_leader_rial":"","gasht_leader_toman":"","gasht_ghimat_adl_kharej":"","gasht_ghimat_adl_rial":""}'),
(39, 1, 10, '2015-05-20 20:51:46', 23, '{"visa__country":"ایران","visa_type":" شینگن","visa_time":" ۷ هفته","visa_number":"123587","visa_tarikh":"1393/03/16","visa_address_tel":"مشهد بلوار فردوسی 37648024","visa_jaddress_jtel":"ندارم","visa_pedar":["حسن علی","مهدی","محمد"],"visa_hazine_mosafer":["1.000.000","200.000","1.202.000"],"visa_kasr_sefarat":"2.202.500","visa_ghimat_nafar":"5.000","visa_ajancy":"حسن سیر"}'),
(40, 1, 10, '2015-05-20 20:53:12', 23, '{"visa_country":"ایران","visa_type":" شینگن","visa_time":" ۷ هفته","visa_number":"123587","visa_tarikh":"1393/03/16","visa_address_tel":"مشهد بلوار فردوسی 37648024","visa_jaddress_jtel":"ندارم","visa_pedar":["حسن علی","مهدی","محمد"],"visa_hazine_mosafer":["1.000.000","200.000","1.202.000"],"visa_kasr_sefarat":"2.202.500","visa_ghimat_nafar":"5.000","visa_ajancy":"حسن سیر"}'),
(41, 1, 10, '2015-05-20 21:06:08', 23, '{"visa_country":"ترکیه","visa_type":" شینگن","visa_time":" ۷ هفته","visa_number":"123587","visa_tarikh":"1393/03/16","visa_address_tel":"مشهد بلوار فردوسی 37648024","visa_jaddress_jtel":"ندارم","visa_pedar":["حسن علی","مهدی","محمد"],"visa_hazine_mosafer":["1.000.000","200.000","1.202.000"],"visa_kasr_sefarat":"2.202.500","visa_ghimat_nafar":"5.000","visa_ajancy":"حسن سیر"}'),
(42, 1, 10, '2015-05-20 21:06:26', 23, '{"visa_country":"ایتالیا","visa_type":" شینگن","visa_time":" ۷ هفته","visa_number":"123587","visa_tarikh":"1393/03/16","visa_address_tel":"مشهد بلوار فردوسی 37648024","visa_jaddress_jtel":"ندارم","visa_pedar":["حسن علی","مهدی","محمد"],"visa_hazine_mosafer":["1.000.000","200.000","1.202.000"],"visa_kasr_sefarat":"2.202.500","visa_ghimat_nafar":"5.000","visa_ajancy":"حسن سیر"}'),
(43, 4, 10, '2015-05-20 23:47:01', 23, '[]'),
(44, 2, 10, '2015-05-20 23:54:09', 18, '{"gasht_fathername":"میر عبدالله","gasht_shomare_shenasnameh":"","gasht_tarikh_tavalod":"","gasht_addr":"","gasht_tel_sabet":"","gasht_mob":"","gasht_edad":"","gasht_tarikh":"","gasht_saate":"","gasht_rahnama":"","gasht_rahnama_fathername":"","gasht_card":"","gasht_name":"fghfg","gasht_pedar":"ggggghf","gasht_passport":"hfghfg","gasht_hazine_mosafer":["hfghfghfgh","gfh","سیبیسب"],"gasht_code_melli":["fgh","fhgfh",""],"gasht_tarikh_tavalod_frm":["gfhfghgfhg","hgfhg",""],"gasht_nesbat":["fhfghf","ghfg",""],"gasht__tour_khadamat":"","gasht_shab":"","gasht_aztarikh_fa":"","gasht_aztarikh_mi":"","gasht_tatarikh_fa":"","gasht_tatarikh_mi":"","gasht_vasile":"","gasht_sherkat":"","gasht_daraje":"","gasht_mabda_terminal":"","gasht_maghsad_terminal":"","gasht_karmozd":"","gasht_ghimat_nafar_rial":"","gasht_ghimat_nafar_toman":"","gasht_leader_rial":"","gasht_leader_toman":"","gasht_ghimat_adl_kharej":"","gasht_ghimat_adl_rial":""}'),
(45, 4, 10, '2015-05-21 00:03:26', 23, '[]'),
(46, 3, 10, '2015-05-21 00:46:57', 18, '{"gasht_shomare":"","gasht_tarikh":"","gasht_agancy_name":"","gasht_shomare_kargozari":"","gasht_addr":"","gasht_modir":"","gasht_tel":"","gasht_father_name":"","gasht_tarikh_1":"","gasht_istgah":"","gasht_madine":"","gasht_make":"","gasht_shab":"","gasht_mablagh":"2500000"}'),
(47, 3, 10, '2015-05-21 00:47:22', 18, '{"gasht_shomare":"","gasht_tarikh":"","gasht_agancy_name":"","gasht_shomare_kargozari":"","gasht_addr":"","gasht_modir":"","gasht_tel":"","gasht_father_name":"","gasht_tarikh_1":"","gasht_istgah":"","gasht_madine":"","gasht_make":"","gasht_shab":"","gasht_mablagh":""}'),
(48, 3, 10, '2015-05-21 01:00:52', 18, '{"gasht_shomare":"","gasht_tarikh":"","gasht_agancy_name":"","gasht_shomare_kargozari":"","gasht_addr":"","gasht_modir":"","gasht_tel":"","gasht_father_name":"","gasht_name":["sdfds","sdfsd","شسیبسی"],"gasht_shomare_shenasname":["سیب","سیبسی",""],"gasht_tarikh_tavalod_frm":["","",""],"gasht_jander":["","",""],"gasht_shomare_seporde":["","",""],"gasht_code_melli":["","",""],"gasht_is_hamrah":["","",""],"gasht_sen":["","",""],"gasht_nesbat":["","",""],"gasht_tarikh_1":"","gasht_istgah":"","gasht_madine":"","gasht_make":"","gasht_shab":"","gasht_mablagh":""}'),
(49, 1, 24, '2015-06-08 13:59:29', 18, '{"visa_country":" gdgdfg","visa_type":" dfgfg","visa_time":"rdgdfgdfg","visa_number":"3245","visa_tarikh":"42324324324","visa_address_tel":"","visa_jaddress_jtel":"","visa_pedar":["",""],"visa_hazine_mosafer":["",""],"visa_kasr_sefarat":"","visa_ghimat_nafar":"","visa_ajancy":""}'),
(50, 2, 10, '2015-06-08 14:32:48', 18, '{"gasht_fathername":"میر عبدالله","gasht_shomare_shenasnameh":"","gasht_tarikh_tavalod":"","gasht_addr":"","gasht_tel_sabet":"","gasht_mob":"","gasht_edad":"","gasht_tarikh":"","gasht_saate":"","gasht_rahnama":"","gasht_rahnama_fathername":"","gasht_card":"","gasht_name":["f","g","h"],"gasht_pedar":["g","g","g"],"gasht_passport":["h","f","g"],"gasht_hazine_mosafer":["hfghfghfgh","gfh","سیبیسب"],"gasht_code_melli":["fgh","fhgfh",""],"gasht_tarikh_tavalod_frm":["gfhfghgfhg","hgfhg",""],"gasht_nesbat":["fhfghf","ghfg",""],"gasht__tour_khadamat":"","gasht_shab":"","gasht_aztarikh_fa":"","gasht_aztarikh_mi":"","gasht_tatarikh_fa":"","gasht_tatarikh_mi":"","gasht_vasile":"","gasht_sherkat":"","gasht_daraje":"","gasht_mabda_terminal":"","gasht_maghsad_terminal":"","gasht_karmozd":"","gasht_ghimat_nafar_rial":"","gasht_ghimat_nafar_toman":"","gasht_leader_rial":"","gasht_leader_toman":"","gasht_ghimat_adl_kharej":"","gasht_ghimat_adl_rial":""}'),
(51, 11, 37, '2015-06-11 14:19:19', 24, '{"gasht_fathername":"","gasht_shomare_shenasnameh":"","gasht_tarikh_tavalod":"","gasht_addr":"","gasht_tel_sabet":"","gasht_mob":"","gasht_edad":"","gasht_tarikh":"","gasht_saate":"","gasht_rahnama":"","gasht_rahnama_fathername":"","gasht_card":"","gasht_name":["","","",""],"gasht_pedar":["","","",""],"gasht_passport":["","","",""],"gasht_hazine_mosafer":["","","",""],"gasht_code_melli":["","","",""],"gasht_tarikh_tavalod_frm":["","","",""],"gasht_nesbat":["","","",""],"gasht_raft_tarikh":"","gasht_raft_saat":"","gasht_bargasht_tarikh":"","gasht_bargasht_saat":"","gasht_vasile":"","gasht_airline":"","gasht_shab":"","gasht_hotel_tarikh":"","gasht_city":"","gasht_hotel":"","gasht_star":"","gasht_room_typ":"","gasht_sobhane":"","gasht_nahar":"","gasht_sham":"","gasht_transfer":"","gasht_sayer":"","gasht__toz":""}'),
(52, 11, 37, '2015-06-11 14:19:35', 24, '{"gasht_fathername":"","gasht_shomare_shenasnameh":"","gasht_tarikh_tavalod":"","gasht_addr":"","gasht_tel_sabet":"","gasht_mob":"","gasht_edad":"","gasht_tarikh":"","gasht_saate":"","gasht_rahnama":"","gasht_rahnama_fathername":"","gasht_card":"","gasht_name":["","","",""],"gasht_pedar":["","","",""],"gasht_passport":["","","",""],"gasht_hazine_mosafer":["","","",""],"gasht_code_melli":["","","",""],"gasht_tarikh_tavalod_frm":["","","",""],"gasht_nesbat":["","","",""],"gasht_raft_tarikh":"","gasht_raft_saat":"","gasht_bargasht_tarikh":"","gasht_bargasht_saat":"","gasht_vasile":"","gasht_airline":"","gasht_shab":"","gasht_hotel_tarikh":"","gasht_city":"","gasht_hotel":"","gasht_star":"","gasht_room_typ":"","gasht_sobhane":"","gasht_nahar":"","gasht_sham":"","gasht_transfer":"","gasht_sayer":"","gasht__toz":""}');

-- --------------------------------------------------------

--
-- Table structure for table `print_theme`
--

CREATE TABLE IF NOT EXISTS `print_theme` (
`id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `matn` mediumtext COLLATE utf8_persian_ci NOT NULL,
  `matn2` mediumtext COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `print_theme`
--

INSERT INTO `print_theme` (`id`, `name`, `matn`, `matn2`) VALUES
(1, 'ویزای انفرادی شینگن ', '        <div style="text-align: center;"><strong>به نام خدا</strong></div>        <div style="float: left;"><img src="#logo#" width="152" height="128" /></div>        <p dir="rtl" align="right"><strong><span lang="ar-SA"><span lang="fa-IR">كشـور</span></span>:#visa_country#</strong></p>        <p dir="rtl" align="right"><strong><span lang="ar-SA"><span lang="fa-IR">نوع</span> <span lang="fa-IR">ويزا</span></span>:#visa_type#</strong></p>        <p dir="rtl" align="right"><strong><span lang="ar-SA"><span lang="fa-IR">مدت</span> <span lang="fa-IR">ويزا</span> </span>:#visa_time#</strong></p>        <p dir="rtl" style="text-align: left;" align="right"> </p>        <p> </p>        <div>        <p dir="rtl" style="text-align: left;" align="right"><strong><span lang="ar-SA"><span lang="fa-IR">شماره</span> </span>:#visa_number#</strong></p>        <p dir="rtl" style="text-align: left;" align="right"><strong><span lang="ar-SA"><span lang="fa-IR">تاريخ</span> </span>:#visa_tarikh#</strong></p>        <p dir="rtl" align="center"> </p>        <p dir="rtl" align="center"><span style="font-size: 14pt;"><strong>( <span lang="ar-SA"><span lang="fa-IR">توافقنـامه</span></span>)</strong></span></p>        <p dir="rtl" align="right"> </p>        <p dir="rtl" align="center"><strong><span lang="fa-IR">جهت اخذ رواديد </span>/<span lang="fa-IR">توافقنامه به صورت عادي فوري ،ترانزيت ،توريستي،تجاري</span></strong></p>        <p dir="rtl" align="center"><strong><span lang="ar-SA"><span lang="fa-IR">لطفا</span></span>"<span lang="ar-SA"><span lang="fa-IR">قبل</span> <span lang="fa-IR">از</span> <span lang="fa-IR">تقاضاي</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">متن</span> <span lang="fa-IR">توافقنامه</span> <span lang="fa-IR">و</span> <span lang="fa-IR">شرايط</span> <span lang="fa-IR">آن</span> <span lang="fa-IR">را</span> <span lang="fa-IR">مطالعه</span> <span lang="fa-IR">نمائيد</span> </span>.</strong></p>        <p dir="rtl" align="right"><strong><span lang="ar-SA"><span lang="fa-IR">اين</span> <span lang="fa-IR">توافقنامه</span> <span lang="fa-IR">بين</span> <span lang="fa-IR">متقاضي</span> <span lang="fa-IR">و</span> <span lang="fa-IR">يانماينده</span> <span lang="fa-IR">ايشان</span> <span lang="fa-IR">و</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">درخواست</span> <span lang="fa-IR">كننده</span> <span lang="fa-IR">دعوت</span> <span lang="fa-IR">نامه</span> <span lang="fa-IR">با</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">كه</span> <span lang="fa-IR">منبعد</span> <span lang="fa-IR">متقاضي</span> <span lang="fa-IR">ناميده</span> <span lang="fa-IR">ميشود</span> <span lang="fa-IR">از</span> <span lang="fa-IR">يك</span> <span lang="fa-IR">طرف</span> <span lang="fa-IR">و</span> <span lang="fa-IR">دفتر</span> <span lang="fa-IR">خدمات</span> <span lang="fa-IR">مسافرتي</span> <span lang="fa-IR">دنيا</span> <span lang="fa-IR">سير</span> <span lang="fa-IR">كه</span> <span lang="fa-IR">منبعد</span> <span lang="fa-IR">دفتر</span> <span lang="fa-IR">ناميده</span> <span lang="fa-IR">ميشود</span> <span lang="fa-IR">به</span> <span lang="fa-IR">شرح</span> <span lang="fa-IR">زير</span> <span lang="fa-IR">و</span> <span lang="fa-IR">ادامه</span> <span lang="fa-IR">آن</span> <span lang="fa-IR">در</span> <span lang="fa-IR">پشت</span> <span lang="fa-IR">اين</span> <span lang="fa-IR">برگ</span> <span lang="fa-IR">منعقدمي</span> <span lang="fa-IR">گردد</span></span>:</strong></p>        <p dir="rtl" align="right"><strong><span lang="ar-SA"><span lang="fa-IR">آدرس</span> <span lang="fa-IR">و</span> <span lang="fa-IR">تلفن</span> <span lang="fa-IR">محل</span> <span lang="fa-IR">سكونت</span> </span>:#address# #tel#</strong></p>        <p dir="rtl" align="right"><strong><span lang="ar-SA"><span lang="fa-IR">آدرس</span> <span lang="fa-IR">و</span> <span lang="fa-IR">تلفن</span> <span lang="fa-IR">محل</span> <span lang="fa-IR">كار</span></span>:#visa_jaddress_jtel#</strong></p>        <p dir="rtl" align="right"> </p>        <p dir="rtl" align="right"> </p>        <p dir="rtl" align="right"><strong><span lang="ar-SA"><span lang="fa-IR">تقاضا</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">دعوت</span> <span lang="fa-IR">نامه</span> <span lang="fa-IR">جهت</span> <span lang="fa-IR">خودم</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">همراه</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">همراهان</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">افراد</span> <span lang="fa-IR">ديگربه</span> <span lang="fa-IR">شرح</span> <span lang="fa-IR">زير</span> <span lang="fa-IR">دريك</span> <span lang="fa-IR">پاسپورت</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">در</span> <span lang="fa-IR">پاسپورتهاي</span> <span lang="fa-IR">جداگانه</span> <span lang="fa-IR">رادارم</span></span>: </strong></p>        <p dir="rtl" align="right"> </p>        <table dir="rtl" style="width: 100%; margin-left: auto; margin-right: auto;" width="594" cellspacing="1" cellpadding="7">        <tbody>        <tr valign="top">        <td bgcolor="#e0e0e0" width="25" height="13">        <p align="center"><strong><span lang="fa-IR">رديف</span></strong></p>        </td>        <td bgcolor="#e0e0e0" width="124">        <p align="center"><strong><span lang="fa-IR">نام ونام خانوادگي</span></strong></p>        </td>        <td bgcolor="#e0e0e0" width="69">        <p align="center"><strong><span lang="fa-IR">نام پدر</span></strong></p>        </td>        <td bgcolor="#e0e0e0" width="88">        <p align="center"><strong><span lang="fa-IR">شماره پاسپورت</span></strong></p>        </td>        <td bgcolor="#e0e0e0" width="210">        <p align="center"><strong><span lang="fa-IR">هزينه ويزا</span></strong></p>        </td>        </tr>        #hamrahan#        </tbody>        </table>        <p dir="rtl" align="right"> </p>        <p dir="rtl" align="right"><strong>1-<span lang="ar-SA"><span lang="fa-IR">اينجانب #fname1# #lname1# </span></span><span lang="ar-SA"><span lang="fa-IR">به</span> <span lang="fa-IR">عنوان</span> <span lang="fa-IR">درخواست</span> <span lang="fa-IR">كننده</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">دعوت</span> <span lang="fa-IR">نامه</span> <span lang="fa-IR">به</span> <span lang="fa-IR">عنوان</span> <span lang="fa-IR">متقاضي</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">نماينده</span> <span lang="fa-IR">متقاضي</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">دعوت</span> <span lang="fa-IR">نامه</span> <span lang="fa-IR">شناخته</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">گردم</span></span>.</strong></p>        <p dir="rtl" align="right"><strong>2-<span lang="ar-SA"><span lang="fa-IR">متقاضي</span> <span lang="fa-IR">متعهد</span> <span lang="fa-IR">ميگردد</span> <span lang="fa-IR">كه</span> <span lang="fa-IR">خودش</span> <span lang="fa-IR">و</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">افرادي</span> <span lang="fa-IR">كه</span> <span lang="fa-IR">برايشان</span> <span lang="fa-IR">تقاضاي</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">گردد</span> <span lang="fa-IR">پيش</span> <span lang="fa-IR">از</span> <span lang="fa-IR">انقضاءمدت</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">از</span> <span lang="fa-IR">كشور</span> <span lang="fa-IR">مقصد</span> <span lang="fa-IR">خارج</span> <span lang="fa-IR">گردد</span> <span lang="fa-IR">و</span> <span lang="fa-IR">در</span> <span lang="fa-IR">غير</span> <span lang="fa-IR">اينصورت</span> <span lang="fa-IR">مسئوليت</span> <span lang="fa-IR">هرگونه</span> <span lang="fa-IR">ضرر</span> <span lang="fa-IR">و</span> <span lang="fa-IR">زيان</span> <span lang="fa-IR">ناشي</span> <span lang="fa-IR">از</span> <span lang="fa-IR">آن</span> <span lang="fa-IR">را</span> <span lang="fa-IR">متقاضي</span> <span lang="fa-IR">شخصا</span></span>"<span lang="ar-SA"><span lang="fa-IR">بعهده</span> <span lang="fa-IR">خواهد</span> <span lang="fa-IR">داشت</span> </span>.</strong></p>        <p dir="rtl" align="right"><strong>3-<span lang="ar-SA"><span lang="fa-IR">هرگونه</span> <span lang="fa-IR">جرائم</span> <span lang="fa-IR">و</span> <span lang="fa-IR">هزينه</span> <span lang="fa-IR">هاي</span> <span lang="fa-IR">مالي</span> <span lang="fa-IR">ناشي</span> <span lang="fa-IR">از</span> <span lang="fa-IR">اقامت</span> <span lang="fa-IR">غيرمجاز</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">ناشي</span> <span lang="fa-IR">از</span> <span lang="fa-IR">اعمال</span> <span lang="fa-IR">غير</span> <span lang="fa-IR">مجاز</span> <span lang="fa-IR">به</span> <span lang="fa-IR">عهده</span> <span lang="fa-IR">متقاضي</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">باشد</span> <span lang="fa-IR">كه</span> <span lang="fa-IR">ملزم</span> <span lang="fa-IR">به</span> <span lang="fa-IR">جبران</span> <span lang="fa-IR">و</span> <span lang="fa-IR">پرداخت</span> <span lang="fa-IR">آن</span> <span lang="fa-IR">ميباشد</span> <span lang="fa-IR">و</span> <span lang="fa-IR">چنانچه</span> <span lang="fa-IR">اين</span> <span lang="fa-IR">دفتر</span> <span lang="fa-IR">نيزهزينه</span> <span lang="fa-IR">هايي</span> <span lang="fa-IR">را</span> <span lang="fa-IR">پرداخت</span> <span lang="fa-IR">نمايد</span> <span lang="fa-IR">متقاضي</span> <span lang="fa-IR">ملزم</span> <span lang="fa-IR">به</span> <span lang="fa-IR">جبران</span> <span lang="fa-IR">آن</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">باشد</span> </span></strong></p>        <p dir="rtl" align="right"><strong>4-<span lang="ar-SA"><span lang="fa-IR">درخواست</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">دعوت</span> <span lang="fa-IR">نامه</span> <span lang="fa-IR">با</span> <span lang="fa-IR">ارائه</span> <span lang="fa-IR">اصل</span> <span lang="fa-IR">پاسپورت</span> <span lang="fa-IR">وپرداخت</span> <span lang="fa-IR">تمام</span> <span lang="fa-IR">وجه</span> <span lang="fa-IR">الزامي</span> <span lang="fa-IR">است</span> </span>.</strong></p>        <p dir="rtl" align="right"><strong>5- <span lang="ar-SA"><span lang="fa-IR">در</span> <span lang="fa-IR">صورت</span> <span lang="fa-IR">تقاضاي</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">گروه</span> <span lang="fa-IR">بيش</span> <span lang="fa-IR">از</span> <span lang="fa-IR">يك</span> <span lang="fa-IR">نفر</span> <span lang="fa-IR">يا</span> </span>(<span lang="ar-SA"><span lang="fa-IR">چند</span> <span lang="fa-IR">نفر</span> <span lang="fa-IR">با</span> <span lang="fa-IR">يكديگر</span> </span>)<span lang="ar-SA"><span lang="fa-IR">شخص</span> <span lang="fa-IR">متقاضي</span> <span lang="fa-IR">و</span> <span lang="fa-IR">پرداخت</span> <span lang="fa-IR">كننده</span> <span lang="fa-IR">وجه</span> <span lang="fa-IR">نماينده</span> <span lang="fa-IR">ساير</span> <span lang="fa-IR">ين</span> <span lang="fa-IR">شناخته</span> <span lang="fa-IR">ميشود</span> </span>. <span lang="ar-SA"><span lang="fa-IR">اين</span> <span lang="fa-IR">دفتر</span> <span lang="fa-IR">صرفا</span></span>"<span lang="ar-SA"><span lang="fa-IR">به</span> <span lang="fa-IR">همان</span> <span lang="fa-IR">شخص</span> <span lang="fa-IR">ارائه</span> <span lang="fa-IR">خدمات</span> <span lang="fa-IR">و</span> <span lang="fa-IR">پاسخگويي</span> <span lang="fa-IR">خواهد</span> <span lang="fa-IR">نمود</span> <span lang="fa-IR">و</span> <span lang="fa-IR">با</span> <span lang="fa-IR">امضاءاين</span> <span lang="fa-IR">قرارداد</span> <span lang="fa-IR">تمامي</span> <span lang="fa-IR">مفادآن</span> <span lang="fa-IR">و</span> <span lang="fa-IR">مسئوليتها</span> <span lang="fa-IR">را</span> <span lang="fa-IR">از</span> <span lang="fa-IR">جانب</span> <span lang="fa-IR">خود</span> <span lang="fa-IR">و</span> <span lang="fa-IR">همراهان</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">پذيرد</span></span>.</strong></p>        <p dir="rtl" align="right"><strong>6-<span lang="ar-SA"><span lang="fa-IR">در</span> <span lang="fa-IR">صورت</span> <span lang="fa-IR">تقاضاي</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">بيش</span> <span lang="fa-IR">از</span> <span lang="fa-IR">يك</span> <span lang="fa-IR">نفر</span> <span lang="fa-IR">با</span> <span lang="fa-IR">پاسپورت</span> <span lang="fa-IR">جداگانه</span> <span lang="fa-IR">در</span> <span lang="fa-IR">آن</span> <span lang="fa-IR">واحد</span> </span>(<span lang="ar-SA"><span lang="fa-IR">مانند</span> <span lang="fa-IR">يك</span> <span lang="fa-IR">زوج</span> <span lang="fa-IR">با</span> <span lang="fa-IR">پاسپورتهاي</span> <span lang="fa-IR">جداگانه</span> <span lang="fa-IR">–</span> <span lang="fa-IR">يك</span> <span lang="fa-IR">خانواده</span> <span lang="fa-IR">با</span> <span lang="fa-IR">پاسپورتهاي</span> <span lang="fa-IR">جداگانه</span> <span lang="fa-IR">–</span> <span lang="fa-IR">چند</span> <span lang="fa-IR">نفر</span> <span lang="fa-IR">همراه</span> <span lang="fa-IR">و</span> <span lang="fa-IR">آشنا</span> <span lang="fa-IR">و</span> <span lang="fa-IR">غيره</span> </span>)<span lang="ar-SA"><span lang="fa-IR">در</span> <span lang="fa-IR">صورت</span> <span lang="fa-IR">مرفوض</span> <span lang="fa-IR">شدن</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">عدم</span> <span lang="fa-IR">صدور</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">براي</span> <span lang="fa-IR">بعضي</span> <span lang="fa-IR">از</span> <span lang="fa-IR">ايشان</span> <span lang="fa-IR">اين</span> <span lang="fa-IR">دفتر</span> <span lang="fa-IR">هيچگونه</span> <span lang="fa-IR">مسئوليتي</span> <span lang="fa-IR">را</span> <span lang="fa-IR">نمي</span> <span lang="fa-IR">پذيرد</span> <span lang="fa-IR">و</span> <span lang="fa-IR">منوط</span> <span lang="fa-IR">نمودن</span> <span lang="fa-IR">صدور</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">به</span> <span lang="fa-IR">يكديگر</span> <span lang="fa-IR">از</span> <span lang="fa-IR">نظر</span> <span lang="fa-IR">مقامات</span> <span lang="fa-IR">آن</span> <span lang="fa-IR">كشور</span> <span lang="fa-IR">اعتباري</span> <span lang="fa-IR">ندارد</span></span>.</strong></p>        <p dir="rtl" align="right"><strong>7-<span lang="ar-SA"><span lang="fa-IR">اين</span> <span lang="fa-IR">دفتر</span> <span lang="fa-IR">جهت</span> <span lang="fa-IR">تامين</span> <span lang="fa-IR">جاي</span> <span lang="fa-IR">پرواز</span> <span lang="fa-IR">تلاش</span> <span lang="fa-IR">خود</span> <span lang="fa-IR">را</span> <span lang="fa-IR">معطوف</span> <span lang="fa-IR">ميدارد</span> <span lang="fa-IR">ولي</span> <span lang="fa-IR">هيچگونه</span> <span lang="fa-IR">تعهد</span> <span lang="fa-IR">و</span> <span lang="fa-IR">مسئوليتي</span> <span lang="fa-IR">را</span> <span lang="fa-IR">نمي</span> <span lang="fa-IR">پذيرد</span> <span lang="fa-IR">،منوط</span> <span lang="fa-IR">نمودن</span> <span lang="fa-IR">رواديدبه</span> <span lang="fa-IR">تاريخ</span> <span lang="fa-IR">پرواز</span> <span lang="fa-IR">به</span> <span lang="fa-IR">اين</span> <span lang="fa-IR">دفتر</span> <span lang="fa-IR">ارتباطي</span> <span lang="fa-IR">نخواهد</span> <span lang="fa-IR">داشت</span> </span>.</strong></p>        <p dir="rtl" align="right"><strong>8- <span lang="ar-SA"><span lang="fa-IR">مدت</span> <span lang="fa-IR">اعتبار</span> <span lang="fa-IR">استفاده</span> <span lang="fa-IR">ازويزا</span> <span lang="fa-IR">و</span> <span lang="fa-IR">مدت</span> <span lang="fa-IR">اقامت</span> <span lang="fa-IR">در</span> <span lang="fa-IR">كشور</span> <span lang="fa-IR">مقصد</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">نقطه</span> <span lang="fa-IR">ترانزيت</span> <span lang="fa-IR">بسته</span> <span lang="fa-IR">به</span> <span lang="fa-IR">نوع</span> <span lang="fa-IR">درخواست</span> <span lang="fa-IR">و</span> <span lang="fa-IR">موافقت</span> <span lang="fa-IR">ويزاي</span> <span lang="fa-IR">صادره</span> <span lang="fa-IR">از</span> <span lang="fa-IR">طرف</span> <span lang="fa-IR">مقامات</span> <span lang="fa-IR">كشور</span> <span lang="fa-IR">مورد</span> <span lang="fa-IR">نظر</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">باشد</span> </span>.</strong></p>        <p dir="rtl" align="right"><strong>9-<span lang="ar-SA"><span lang="fa-IR">متقاضي</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">پذيرد</span> <span lang="fa-IR">صدور</span> <span lang="fa-IR">رواديد</span> </span>/<span lang="ar-SA"><span lang="fa-IR">دعوت</span> <span lang="fa-IR">نامه</span> <span lang="fa-IR">و</span> <span lang="fa-IR">مدت</span> <span lang="fa-IR">اقامت</span> <span lang="fa-IR">بستگي</span> <span lang="fa-IR">به</span> <span lang="fa-IR">مقامات</span> <span lang="fa-IR">كشور</span> <span lang="fa-IR">مورد</span> <span lang="fa-IR">نظر</span> <span lang="fa-IR">دارد</span> <span lang="fa-IR">لذا</span> <span lang="fa-IR">عدم</span> <span lang="fa-IR">صدور</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">دعوت</span> <span lang="fa-IR">نامه</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">صدور</span> <span lang="fa-IR">با</span> <span lang="fa-IR">تاريخ</span> <span lang="fa-IR">اعتبار</span> <span lang="fa-IR">متفاوت</span> <span lang="fa-IR">بستگي</span> <span lang="fa-IR">به</span> <span lang="fa-IR">كشور</span> <span lang="fa-IR">مربوطه</span> <span lang="fa-IR">دارد</span> <span lang="fa-IR">و</span> <span lang="fa-IR">حتي</span> <span lang="fa-IR">گاهي</span> <span lang="fa-IR">اوقات</span> <span lang="fa-IR">با</span> <span lang="fa-IR">وجود</span> <span lang="fa-IR">صدور</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">از</span> <span lang="fa-IR">ورود</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">عبور</span> <span lang="fa-IR">متقاضي</span> <span lang="fa-IR">به</span> <span lang="fa-IR">كشور</span> <span lang="fa-IR">مربوطه</span> <span lang="fa-IR">ممانعت</span> <span lang="fa-IR">به</span> <span lang="fa-IR">عمل</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">آيدكه</span> <span lang="fa-IR">اين</span> <span lang="fa-IR">امرصرفا</span></span>"<span lang="ar-SA"><span lang="fa-IR">به</span> <span lang="fa-IR">كشور</span> <span lang="fa-IR">مربوطه</span> <span lang="fa-IR">بستگي</span> <span lang="fa-IR">دارد</span> <span lang="fa-IR">و</span> <span lang="fa-IR">از</span> <span lang="fa-IR">حيطه</span> <span lang="fa-IR">عمل</span> <span lang="fa-IR">اين</span> <span lang="fa-IR">دفتر</span> <span lang="fa-IR">خارج</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">باشد</span> <span lang="fa-IR">،لذا</span> <span lang="fa-IR">اين</span> <span lang="fa-IR">دفتر</span> <span lang="fa-IR">هيچگونه</span> <span lang="fa-IR">مسئوليتي</span> <span lang="fa-IR">در</span> <span lang="fa-IR">قبال</span> <span lang="fa-IR">اهداف</span> <span lang="fa-IR">سفر</span> <span lang="fa-IR">مانند</span> <span lang="fa-IR">وقت</span> <span lang="fa-IR">سفارت</span> <span lang="fa-IR">،آزمون</span> <span lang="fa-IR">و</span> <span lang="fa-IR">مسائل</span> <span lang="fa-IR">كاري</span> <span lang="fa-IR">،مسائل</span> <span lang="fa-IR">مالي</span> <span lang="fa-IR">نمي</span> <span lang="fa-IR">تواند</span> <span lang="fa-IR">عهده</span> <span lang="fa-IR">دار</span> <span lang="fa-IR">باشد</span></span>.</strong></p>        <p dir="rtl" align="right"><strong>10-<span lang="ar-SA"><span lang="fa-IR">حداكثر</span> <span lang="fa-IR">مدت</span> <span lang="fa-IR">اخذ</span> <span lang="fa-IR">رواديد</span></span>30 <span lang="ar-SA"><span lang="fa-IR">مي</span> <span lang="fa-IR">باشد</span> <span lang="fa-IR">و</span> <span lang="fa-IR">پس</span> <span lang="fa-IR">از</span> <span lang="fa-IR">اين</span> <span lang="fa-IR">مدت</span> <span lang="fa-IR">در</span> <span lang="fa-IR">صورت</span> <span lang="fa-IR">عدم</span> <span lang="fa-IR">صدور</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">تمام</span> <span lang="fa-IR">وجه</span> <span lang="fa-IR">پرداختي</span> <span lang="fa-IR">پس</span> <span lang="fa-IR">از</span> <span lang="fa-IR">كسر</span> <span lang="fa-IR">هزينه</span> <span lang="fa-IR">هاي</span> <span lang="fa-IR">مربو</span> <span lang="fa-IR">طه</span> <span lang="fa-IR">استرداد</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">گردد</span></span>. <span lang="ar-SA"><span lang="fa-IR">هزينه</span> <span lang="fa-IR">كسري</span> <span lang="fa-IR">درصورت</span> <span lang="fa-IR">عدم</span> <span lang="fa-IR">صدور</span> <span lang="fa-IR">ويزا</span> <span lang="fa-IR">از</span> <span lang="fa-IR">سوي</span> <span lang="fa-IR">سفارت</span> <span lang="fa-IR">مربوطه</span> <span lang="fa-IR">مبلغ</span> <span lang="fa-IR">جمعاً</span> #visa_kasr_sefarat#</span> <span lang="ar-SA"><span lang="fa-IR">ريال</span></span> <span lang="fa-IR">به</span> <span lang="fa-IR">ازاي</span> <span lang="fa-IR">هر</span> <span lang="fa-IR">نفر</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">باشد</span>.</strong></p>        <p dir="rtl" align="right"><strong>11-<span lang="fa-IR">پس از درخواست دعوتنامه </span>/ <span lang="fa-IR">رواديد استرداد وجه امكان پذير نمي باشد و دلايل بيماري ،فوت ،اشكال در پاسپورت انصراف ممنوعيت خروج از كشور و غيره قابل قبول نخواهد بود</span>.</strong></p>        <p dir="rtl" align="right"><strong>12- <span lang="fa-IR">متقاضي توجه و قبول مي نمايد كه گاهي اوقات صدور رواديد منوط به تاييد مقامات امنيتي كشور مربوطه مي باشد كه اين امر ممكن است تا </span>40 <span lang="fa-IR">روز طول بكشد.</span></strong></p>        <p dir="rtl" align="right"><strong>13- <span lang="ar-SA"><span lang="fa-IR">از</span> <span lang="fa-IR">متقاضي</span> <span lang="fa-IR">درخواست</span> <span lang="fa-IR">ميگردد</span> <span lang="fa-IR">در</span> <span lang="fa-IR">هنگام</span> <span lang="fa-IR">دريافت</span> <span lang="fa-IR">دعوت</span> <span lang="fa-IR">نامه</span> </span>/<span lang="ar-SA"><span lang="fa-IR">رواديد</span> <span lang="fa-IR">مشخصات</span> <span lang="fa-IR">پاسپورت</span> <span lang="fa-IR">خود</span> <span lang="fa-IR">و</span> <span lang="fa-IR">همراهان</span> <span lang="fa-IR">تطبيق</span> <span lang="fa-IR">دهد</span> <span lang="fa-IR">و</span> <span lang="fa-IR">هرگونه</span> <span lang="fa-IR">اشتباه</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">اختلاف</span> <span lang="fa-IR">مشخصات</span> <span lang="fa-IR">ر</span> <span lang="fa-IR">ا</span> <span lang="fa-IR">اطلاع</span> <span lang="fa-IR">دهد</span> <span lang="fa-IR">در</span> <span lang="fa-IR">غير</span> <span lang="fa-IR">اينصورت</span> <span lang="fa-IR">دفتر</span> <span lang="fa-IR">مسئوليتي</span> <span lang="fa-IR">را</span> <span lang="fa-IR">نمي</span> <span lang="fa-IR">پذيرد</span> </span>.</strong></p>        <p dir="rtl" align="right"><strong>14-<span lang="fa-IR">ممنوع الخروج يا ممنوع الورود بودن متقاضي از كشور مبداءبه مقصد و يا بالعكس به اين دفتر ارتباطي نداشته و وظيفه اين دفترانجام شده تلقي مي گردد</span>.</strong></p>        <p dir="rtl" align="right"><strong>15-<span lang="fa-IR">اشتباهات و اشكالات مندرج در پاسپورت به عهد ه متقاضي مي باشد</span>.</strong></p>        <p dir="rtl" align="right"><strong>16-<span lang="ar-SA"><span lang="fa-IR">در</span> <span lang="fa-IR">مورد</span> <span lang="fa-IR">ويزاهاي</span> <span lang="fa-IR">گروهي</span> <span lang="fa-IR">چين</span> <span lang="fa-IR">حداقل</span> <span lang="fa-IR">نفرات</span> </span>5 <span lang="ar-SA"><span lang="fa-IR">نفر</span> <span lang="fa-IR">و</span> <span lang="fa-IR">ورود</span> <span lang="fa-IR">و</span> <span lang="fa-IR">خروج</span> <span lang="fa-IR">از</span> <span lang="fa-IR">مرزها</span> <span lang="fa-IR">نيزبايد</span> <span lang="fa-IR">با</span> <span lang="fa-IR">هم</span> <span lang="fa-IR">باشد</span> <span lang="fa-IR">و</span> <span lang="fa-IR">حداكثر</span> <span lang="fa-IR">زمان</span> <span lang="fa-IR">تهيه</span> <span lang="fa-IR">ويزا</span> </span>15<span lang="ar-SA"><span lang="fa-IR">تا</span> </span>20 <span lang="ar-SA"><span lang="fa-IR">روز</span> <span lang="fa-IR">كاري</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">باشد</span> <span lang="fa-IR">و</span> <span lang="fa-IR">در</span> <span lang="fa-IR">صورت</span> <span lang="fa-IR">رد</span> <span lang="fa-IR">شدن</span> <span lang="fa-IR">هر</span> <span lang="fa-IR">يك</span> <span lang="fa-IR">از</span> <span lang="fa-IR">نفرات</span> <span lang="fa-IR">اگرحد</span> <span lang="fa-IR">نصاب</span> <span lang="fa-IR">گروه</span> <span lang="fa-IR">به</span> <span lang="fa-IR">كمتر</span> <span lang="fa-IR">از</span> </span>5 <span lang="ar-SA"><span lang="fa-IR">نفر</span> <span lang="fa-IR">برسد</span> <span lang="fa-IR">ويزاي</span> <span lang="fa-IR">گروهي</span> <span lang="fa-IR">صادر</span> <span lang="fa-IR">نخواهد</span> <span lang="fa-IR">شد</span> <span lang="fa-IR">و</span> <span lang="fa-IR">اين</span> <span lang="fa-IR">شركت</span> <span lang="fa-IR">هيچگونه</span> <span lang="fa-IR">مسئوليتي</span> <span lang="fa-IR">دراين</span> <span lang="fa-IR">قبال</span> <span lang="fa-IR">نخواهد</span> <span lang="fa-IR">داشت</span> <span lang="fa-IR">وجه</span> <span lang="fa-IR">دعوتنامه</span> <span lang="fa-IR">كسر</span> <span lang="fa-IR">شده</span> <span lang="fa-IR">و</span> <span lang="fa-IR">باقيمانده</span> <span lang="fa-IR">به</span> <span lang="fa-IR">مسافر</span> <span lang="fa-IR">برگردانده</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">شود</span> </span>.</strong></p>        <p dir="rtl" align="right"><strong>17- <span lang="ar-SA"><span lang="fa-IR">مبلغ</span> #visa_ghimat_nafar#</span> <span lang="ar-SA"><span lang="fa-IR">در</span> <span lang="fa-IR">ازاي</span> <span lang="fa-IR">هر</span> <span lang="fa-IR">نفر</span> <span lang="fa-IR">تحويل</span> <span lang="fa-IR">مسئول</span> <span lang="fa-IR">ويزاي</span> <span lang="fa-IR">شركت</span> <span lang="fa-IR">جهانگردي</span> <span lang="fa-IR">دنياسير</span> <span lang="fa-IR">گرديد</span></span>.</strong></p>        <p dir="rtl" align="right"><strong>18-<span lang="fa-IR">مسئوليت صدور بليط و رزرو هتل و</span>....<span lang="fa-IR">قبل از صدور ويزا به عهده مسافر ميباشدو اين آژانس هيچگونه مسئوليتي ندارد</span>.</strong></p>        <p dir="rtl" align="right"><strong>19-<span lang="ar-SA"><span lang="fa-IR">شركت</span> <span lang="fa-IR">دنيا</span> <span lang="fa-IR">سير</span> <span lang="fa-IR">صرفا</span></span>" <span lang="ar-SA"><span lang="fa-IR">اقدام</span> <span lang="fa-IR">كننده</span> <span lang="fa-IR">جهت</span> <span lang="fa-IR">ويزا</span> <span lang="fa-IR">ميباشد</span> <span lang="fa-IR">نه</span> <span lang="fa-IR">صادر</span> <span lang="fa-IR">كننده</span> <span lang="fa-IR">ويزا</span></span></strong></p>        <p dir="rtl" align="right"><strong>20- <span lang="ar-SA"><span lang="fa-IR">آژانس #visa_ajancy#</span></span> <span lang="ar-SA"><span lang="fa-IR">يا</span> <span lang="fa-IR">جناب</span> #fname1# #lname1#</span> <span lang="ar-SA"><span lang="fa-IR">متعهد</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">گردد</span> <span lang="fa-IR">كه</span> <span lang="fa-IR">كليه</span> <span lang="fa-IR">مفاد</span> <span lang="fa-IR">اين</span> <span lang="fa-IR">توافقنامه</span> <span lang="fa-IR">را</span> <span lang="fa-IR">بطور</span> <span lang="fa-IR">كامل</span> <span lang="fa-IR">مطالعه</span> <span lang="fa-IR">كرده</span> <span lang="fa-IR">و</span> <span lang="fa-IR">بعد</span> <span lang="fa-IR">تصميم</span> <span lang="fa-IR">به</span> <span lang="fa-IR">عقد</span> <span lang="fa-IR">اين</span> <span lang="fa-IR">توافقنامه</span> <span lang="fa-IR">گرفته</span> <span lang="fa-IR">اند</span></span>.</strong></p>        <p dir="rtl" align="right"> </p>        <table style="height: 59px; width: 100%; margin-left: auto; margin-right: auto;" width="789">        <tbody>        <tr>        <td style="text-align: right; vertical-align: middle;"><span style="font-size: 12pt;"><strong><span lang="fa-IR">مهر</span> <span lang="fa-IR">و</span> <span lang="fa-IR">امضاءمسئول</span> <span lang="fa-IR">بخش</span> <span lang="fa-IR">ويزا</span> </strong></span></td>        <td style="text-align: left; vertical-align: middle;"><span style="font-size: 12pt;"><strong><span lang="fa-IR">نام</span> <span lang="fa-IR">ونام</span> <span lang="fa-IR">خانوادگي</span> <span lang="fa-IR">مسافر</span></strong></span></td>        </tr>        <tr style="text-align: center;">        <td style="text-align: right; vertical-align: middle;"><span style="font-size: 12pt;"><strong><span lang="fa-IR">آژانس</span> <span lang="fa-IR">دنيا</span> <span lang="fa-IR">سير</span> </strong></span></td>        <td style="text-align: left; vertical-align: middle;"><span style="font-size: 12pt;"><strong>امضاء</strong></span></td>        </tr>        </tbody>        </table>        <p dir="rtl" style="text-align: right;" align="right"> </p>        <p dir="rtl" style="text-align: right;" align="right"> </p>        <p dir="rtl" align="right"> </p>        </div>', '    <tr valign="top">        <td width="25" height="2">        <p align="center"><strong>#index#</strong></p>        </td>        <td width="124">        <p align="center">#name#</p>        </td>        <td width="69">        <p align="center"> #visa_pedar[]# </p>        </td>        <td width="88">        <p dir="ltr" align="center">#passport#</p>        </td>        <td width="210">        <p align="center"> #visa_hazine_mosafer[]# </p>        </td>    </tr>'),
(2, 'قرارداد گشتهای خارج از کشور', '<div style="float: left;"><img src="/crm/assets/img/donya_logo.jpg" width="152" height="90"></div><div style="float: right;"><img src="/crm/assets/img/donya_logo_fa.jpg"  height="90"></div><p style="text-align: center;"><strong>بسمه تعالی</strong></p><p style="text-align: center;">اوفوا بالعهد ان العهد کان مسئولاً</p><p style="text-align: center;"><span style="font-size: 14pt;"><strong> قرارداد گشتهای خارج از کشور</strong></span></p><p style="text-align: right;"><span style="font-size: 10pt;">ثبت نام کننده: #user_sabti#<br />این قرارداد فی مابین خانم/آقای #fname1# #lname1#  فرزند : #pedar_name# به شماره شناسنامه: #gasht_shomare_shenasnameh#  تاریخ تولد: #tarikh_tavalod# آدرس: #address# تلفن: #tell# و همراه: #mob# منفرداً یا به نمایندگی تام الاختیار از سوی افراد زیر جمعاً به تعداد #gasht_edad# نفر که از این پس مسافر نامیده می شود از یک طرف و دفتر / شرکت خدمات گردشگری: دنیاسیر به شماره پروانه:       مورخ:      صادره از سوی اداره کل میراث فرهنگی، صنایع دستی و گردشگری استان : خراسان رضوی که از این پس کارگزار نامیده می شود از طرف دیگر، که برنامه سفر نیز در اختیار مسافر قرار گرفته است در تاریخ #gasht_tarikh#  ساعت #gasht_saate# منعقد گردید. <br />ضمناً نام راهنمای تور آقا/ خانم : #gasht_rahnama# فرزند :#gasht_rahnama_fathername# دارای کارت شناسایی : #gasht_card#  می باشد.<br />الف) مشخصات مسافر یا مسافرین تور  گروهی اروپا ( 4شب پاریس -2شب بروکسل-3شب آمستردام-3شب هامبورگ -1شب پاریس)</span></p><p style="text-align: right;"> </p><table class="list_table" style="margin-left: auto; margin-right: auto; width: 21cm;" border="1"><tbody><tr><td>ردیف</td><td>نام و نام خانوادگی -فارسی</td><td>نرخ تور</td><td>شماره گذرنامه</td><td>مدت اعتبار گذرنامه</td><td>کدملی</td><td>تاریخ تولد</td><td>نسبت</tdkharej></tr>#hamrahan#</tbody></table><p style="text-align: right;"><span style="font-size: 12pt;"><strong> تور چارتر و غیر قابل استرداد می باشد.</strong></span><br /><strong>آژانس دنياسير در زمينه تهيه ارز مسافرتي مسئوليتي نخواهد داشت.</strong><br />خدمات تور:<br/> #gasht__tour_khadamat#</p><p style="text-align: right;">#gasht_tavajoh#</p><p style="text-align: right;"><br /><strong>ب) موضوع قرارداد:</strong><br />موضوع این قرارداد تعیین حدود و وظایف و مسئولیت های طرفین قرارداد و همچنین نرخ گشت برای انجام مسافرت به طور دسته جمعی و انفرادی به شرح زیر می باشد:<br /><strong>ج) شرایط هزینه سفر:</strong></p><p style="text-align: right;">۱) مدت سفر : #gasht_shab#  ازتاریخ  شمسی:  #gasht_aztarikh_fa#  #gasht_aztarikh_mi#  لغایت  شمسی: #gasht_tatarikh_fa#  #gasht_tatarikh_mi#</p><p style="text-align: right;"><strong>تبصره 2: در اتاقهای سه تخته، تخت سوم از نوع سفری بوده و موقتاً در اتاق دو نفره گذاشته می شود.</strong><br /><strong>تبصره 3: ساعات تحویل اتاقهای هتل به هنگام ورود ساعت 14 و تخیله آن ساعت 12 می باشد.</strong></p><p style="text-align: right;"><strong>3/2- وسیله حمل و نقل:#gasht_vasile#شرکت: #gasht_sherkat# درجه: #gasht_daraje#  نام پایانه مبدأ: #gasht_mabda_terminal#    نام پایانه مقصد: <strong> #gasht_maghsad_terminal# </strong></strong></p><p style="text-align: right;"> هزینه برای هر نفر: <br />تبصره 1: در صورت رزرو جا در پرواز و یا صدور بلیط چنانچه مسافر به هر علتی (بیماری، انصراف، ممنوع الخروج بودن و ...) بدون اعلام قبلی موفق به پرواز نگردد موظف به پرداخت هزینه ویزا، جریمه متعلق به بلیط و هزینه یک شب هتل می باشد.<br />تبصره2: در صورت ابطال پرواز توسط شرکت هواپیمایی موضوع این قرارداد، کارگزار مساعی خود را جهت اعزام مسافرین با اولین پرواز با توافق و رضایت مسافرین بکار گرفته لذا تغییرات احتمالی در نرخ پرواز مورد نظر با پرواز ابطال شده، از سوی طرفین قابل تعدیل می باشد، بدیهی است در صورت عدم تمایل مسافرین به تغییر پرواز، کارگزار موظف به پرداخت وجوه دریافتی پس از کسر هزینه ویزا به مسافر می باشد.<br />تبصره 3: پرداخت عوارض خروجی به عهده مسافر می باشد.</p><p style="text-align: right;"> 4/2- دارای ترانسفر فرودگاهی می باشد نمی باشد <br />هزینه برای هر نفر : معادل تومان<br />5/2- کارمزد دفتر / شرکت شامل 5% کل قیمت گشت : #gasht_karmozd#هزینه برای هر نفر: #gasht_ghimat_nafar_rial# ريال معادل #gasht_ghimat_nafar_toman# تومان <br />6/2- راهنمای ایرانی مسلط به زبان و کشور هدف : هزینه برای هر نفر #gasht_leader_rial# ریال معادل #gasht_leader_toman# تومان<br />7/2- هزینه کل برای هر نفر: بزرگسال   #gasht_ghimat_adl_kharej#  +  #gasht_ghimat_adl_rial#  ريال</p><p style="text-align: right;"><strong>3) تعهدات کارگزار</strong><br />1/3- کارگزار متعهد است مقررات کشور مقصد را که دانستن آن توسط مسافر ضروری است کتباً به اطلاع مسافر رسانده و مسافر موظف به رعایت کامل آن می باشد و در صورت ارتکاب هرگونه تخلفی، کارگزار هیچگونه مسئولیتی در قبال پیامدهای آن ندارد.<br />2/3- کارگزار متعهد است برنامه سفر و گشت مورد توافق را به طور کامل و دقیق انجام دهد و در صورت وقوع هر گونه پیشامد غیر منتظره ای از قبیل جنگ، شورش، اعتصاب، شرایط جوی و مشکلاتی که از کنترل کارگزار خارج بوده و سبب ابطال و یا تغییر برنامه گشت و یا مسافرت شود مسئولیتی متوجه کارگزار نخواهد بود.<br />3/3- کارگزار متعهد است بیمه کامل مسافرتی را در مورد مسافر اعمال نماید و در صورت بروز هرگونه حادثه ای در طول سفر بر اساس شرایط بیمه تحت پوشش اقدام نماید.<br />4/3- کارگزار متعهد است در صورت بروز هرگونه اتفاقی برای مسافر یا مسافرین در کشور مقصد، سفارتخانه جمهوری اسلامی ایران در آن کشور را از موضوع مطلع سازد.<br />5/3- کارگزار متعهد است تاریخ و اعتبار گذرنامه و شرایط سنی مسافر را کنترل نماید.<br />6/3- کارگزار متعهد است برای سفر، راهنمایی متخصص، مجرب و مسلط به امور را با گشت همراه نماید.<br />7/3- کارگزار متعهد است در صورت انصراف مسافر از همراهی گشت، روادید اخذ شده برای مسافر را توسط مقامات سفارت صادرکننده ابطال نماید.<br />8/3- کارگزار متعهد است تاریخ و شماره انصراف کتبی مسافر را در دفاتر رسمی خود ثبت کند.<br />9/3- کارگزار متعهد است در صورت لغو سفر به هر دلیل بجز موارد مطروحه در بند 2/3، تا یک ماه قبل از پرواز معادل 5% هزینه دریافتی و از یک ماه تا سه هفته قبل از پرواز معادل 7% هزینه دریافتی و از سه هفته تا 72 ساعت قبل از پرواز معادل 10% هزینه دریافتی و حداکثر از 72 ساعت تا قبل از پرواز معادل 12% هزینه دریافتی را به عنوان خسارت به مسافر پرداخت نماید.<br />10/3- کارگزار متعهد است در منطقه ای هتل را جهت استقرار گشت انتخاب نماید که شئونات در آن رعایت گردد.<br />11/3- کارگزار موظف است هتلی را جهت اقامت مسافران انتخاب نماید که شئونات اسلامی در آن رعایت می گردد.<br />4) تعهدات مسافر<br />1/4- مسافر متعهد است در صورت انجام تخلف در کشور مقصد که منجر به پرداخت جریمه و خسارتی توسط کارگزار می گردد جبران نماید.<br />2/4- مسافر متعهد است در صورت ممنوع الخروج بودن مسافر یا ممنوع الورود بودن به کشور مقصد ویا انصراف کتبی از همراهی تور، تا یک ماه قبل از پرواز معادل 50% قیمت کل گشت و از یک ماه تا سه هفته قبل از پرواز معادل 70% قیمت کل گشت و از سه هفته تا 72 ساعت قبل از پرواز معادل 90% قیمت کل گشت و در کمتر از 72 ساعت قبل از پرواز معادل 100% قیمت کل گشت را به عنوان خسارت به کارگزار بپردازد.<br />3/4- مسافر متعهد است برای پیگیری امور تور فقط از طریق فردی که به نمایندگی از سوی ایشان اقدام به ثبت نام نموده پیگیری نماید.<br />4/4- حفظ چمدان ها، اموال، مدارک شخصی به عهده مسافر بوده در صورت بروز هرگونه اتفاق برای هر یک از آنها، هیچ گونه مسئولیتی متوجه کارگزار نخواهد بود. لکن راهنمای گشت موظف به همکاری با مسافر می باشد. <br />5/4- مسافر متعهد است در طول سفر شئونات اسلامی را رعایت نموده و از ایجاد مزاحمت برای مسافرین خودداری و با تور به کشور بازگردد. در غیر این صورت کارگزار موظف است به محض ورود به کشور، گزارش آن را در اختیار نیروی انتظامی قرار دهد و کلیه خسارات مادی وارده احتمالی به عهده مسافر می باشد و باید جبران نماید.<br />6/4- مسافر متعهد است در ساعات تنظیم شده در برنامه های گشت شرکت نماید در غیر این صورت هیچ مسئولیتی به عهده کارگزار نخواهد بود.<br />7/4- مسافر متعهد است پس از بازگشت از سفر جهت اخذ مدارک خود با در دست داشتن اصل گذرنامه و تصویر از صفحه مربوط به مهر ورود و خروج کشور به کارگزار مراجعه کند.<br />تبصره: مسافر متعهد است در هنگام ترک کشور مقصد، دقت نماید تا گذرنامه اش به مهر ورود و خروج ممهور گردد.<br />8/4- مسافر متعهد است تضمینی را بر اساس توافق طرفین تعیین و در قبال اخذ رسید به صورت ودیعه نزد کارگزار بسپارد تا در صورت بروز هر گونه تخلفی از سوی مسافر، به عنوان خسارت و یا جریمه طبق این قرارداد توسط کارگزار مورد بهره برداری قرار گیرد.<br />تبصره: مسافر متعهد است ظرف مدت 10 روز پس از بازگشت از سفر، جهت اخذ تضمین به کارگزار مراجعه نماید.<br />10/4- مسافر متعهد است هزینه ارزی خود را تأمین نماید.<br />5) مسافر و کارگزار، اداره میراث فرهنگی، صنایع دستی و گردشگری را به عنوان حکم مرضی الطرفین تعیین تا در صورت بروز هرگونه اختلاف دررابطه با این قرارداد اعلام نظر نماید.</p><p style="text-align: right;"><strong>بدیهی است نظر این اداره کل قطعی و برای طرفین لازم الاجراست.</strong><br /><strong>نام و نام خانوادگی مسافر و یا نماینده مسافر                              نام و نام خانوادگی مدیرعامل/ مدیر/ مدیر فنی شرکت / دفتر خدمات مسافری مهر و امضا مهر و امضا</strong></p><p style="text-align: right;"> </p><p style="text-align: right;"> </p><p style="text-align: right;"> </p><p style="text-align: right;"> </p><p style="text-align: right;"> </p>', '<tr valign="top">         <td width="25" height="2"> <p align="center"><strong>#index#</strong></p></td>        <td width="">         <p align="center"> #gasht_name[]# </p>         </td>		<td width="">         <p align="center"> #gasht_pedar[]# </p>         </td>		<td width="">         <p dir="ltr" align="center"> #gasht_passport[]# </p>         </td>		<td width="">         <p align="center"> #gasht_hazine_mosafer[]# </p>         </td>		<td width="">         <p align="center"> #gasht_code_melli[]# </p>         </td>		<td width="">         <p align="center"> #gasht_tarikh_tavalod_frm[]# </p>         </td>		<td width="">         <p align="center"> #gasht_nesbat[]# </p>         </td></tr>');
INSERT INTO `print_theme` (`id`, `name`, `matn`, `matn2`) VALUES
(3, 'قرارداد سفر زيارتی عمره', '<p style="text-align: center;"><span style="font-size: 14pt;">قرارداد سفر زيارتی عمره</span></p><p style="text-align: right;"> </p><table style="margin-left: auto; margin-right: auto; width: 100%;"><tbody><tr><td>شماره: #gasht_shomare#</td><td style="text-align: left;" >تاریخ: #gasht_tarikh#</td></tr></tbody></table><p> اين قرارداد بين دفتر / شركت خدمات زيارتي /دفتر مسافرتي و جهانگردي #gasht_agancy_name# به شماره كارگذاري #gasht_shomare_kargozari# به نشاني  : #gasht_addr# تلفن : #gasht_modir# و به مديريت #gasht_tel# كه در اين قرارداد كارگذار ناميده شده به نمايندگي از طرف سازمان حج و زيارت از يك سو و آقاي / خانم #name# فرزند #pedar_name# با كد ملي #codemelli# به شماره گذرنامه #passport#  نشاني :  #address# و تلفن #mob# اصالتا" و به نمايندگي از طرف زائرين مشروحه زير :</p><table class="list_table" style="width: 100%; margin-left: auto; margin-right: auto;" border="1"><tbody><tr><td>ردیف</td><td>نام و نام خانوادگی</td><td>شماره شناسنامه محل صدور</td><td>تاریخ تولد</td><td>جنسیت</td><td>شماره سپرده علی الحساب</td><td>کدملی</td><td>اصل یا همراه</td><td>گروه سنی</td><td>نسبت</td></tr>#hamrahan#</tbody></table><p>كه در اين قرارداد زائر ناميده ميشود از سوي ديگر با شرايط زير منعقد ميگردد.<br />ماده يك موضوع قرارداد : <br />موضوع قرارداد عبارتست از پذيرش ارائه كامل خدمات و انجام امور اعزام نامبردگان فوق به سفر زيارتي عمره در تاريخ #gasht_tarikh_1# از ايستگاه پروازي #gasht_istgah# به مقصد جده مدينه با گروه قيمتي : و اسكان در هتل هاي مدينه منوره #gasht_madine# و مكه مكرمه #gasht_make# به مدت #gasht_shab# روز از تاريخ و ساعت پرواز رفت مندرج در بليط تا تاريخ و ساعت پرواز برگشت مندرج در بليط با حدود 12 ساعت كاهش يا افزايش كه بستگي به شرايط پرواز دارد .<br />ماده 2 – مبلغ قرارداد :<br />1-2- كل هزينه سفر زائرين مشروحه در اين قرارداد با توجه به جداول تعيين شده از سوي سازمان حج و زيارت مبلغ #gasht_mablagh# ريال مي باشد .<br />تبصره : با توجه به نوسان نرخ ارز در صورت افزايش نرخ ارز قبل پرواز نسبت به دريافت ما به التفاوت ( بخش ارزي هزينه سفر ) و بنا به نياز ما به التفاوت بهاي بليط هواپيمايي ( در صورت تغيير نرخ بليط )بر اساس نرخي كه از سوي سازمان حج و زيارت اعلام ميشود اقدام خواهد شد .<br />2-2- تهيه ارز براي هزينه هاي شخصي به عهده زائرين بوده و هيچ گونه پيش بيني براي پرداخت ارز به زائرين در هزينه سفر صورت نگرفته است .<br />3-2- هزينه هاي : 1- تلفن در ايران و عربستان 2- اضافه بار 3- اياب و ذهاب خارج از برنامه و ساير هزينه هاي شخصي به عهده خود زائرين ميباشد .<br />ماده 3 – تسهيلات و خدمات سفر عمره : 1- 3- ايجاد پوشش بيمه اي زائر و با ر همراه ، در طول مدت سفر به تناسب حق بيمه پرداختي به شركت بيمه و بر اساس قراردادي است كه زائر از مفاد آن مطلع ميباشد . تذكر 1 : چنانچه زائر پوشش بيمه اي فوق را كافي نداند ميتواند راسا" نسبت به تكميل آن اقدام نموده و سازمان حج و زيارت هيچ گونه مسئوليتي در اين خصوص نخواهد داشت . تذكر 2 : اشياء قيمتي همانند طلا و ... و وجه نقد مشمول بيمه نميباشد . <br />2- 3- تامين سه وعده غذا شامل : صبحانه ، ناهار و شام در عربستان . 3-3- تامين حمل و نقل هوايي از ايران به عربستان و بالعكس و حمل و نقل بين شهري در مسير هاي جده ، مدينه ، مكه و پذيرايي در مسيرها و زيارت دوره 4- 3- تامين محل اسكان در مدينه منوره و مكه مكرمه .<br />تذكر 3 : درجه بندي هتل در عربستان و توجه به مقررات وزارت تجارت عربستان ميباشد . 5- 3- ارائه امكانات اوليه پزشكي در عربستان <br />ماده چهار- تعهدات زائرين : 1- 4 – تحويل اصل و كپي فيش سپرده علي الحساب هزينه سفر به كارگزار . 2- 4- پرداخت ما به التفاوت هزينه هاي سفر مطابق فيش تنظيم شده از طرف كار گزار ، و ارائه فيش پرفراژ شده به كارگزار ثبت نام كننده و اخذ رسيد ظرف مدت 72 ساعت از دريافت فيش از كارگزار . تذكر 1 : چنانچه زائر فيش پرفراژ شده را در مدت مذكور به كارگزار ثبت نام كننده تحويل ندهد منصرف از ثبت نام تلقي ميشود . تذكر 2: پرداخت مبالغ افزايش هزينه سفر ناشي از افزايش قيمت ارز در زمان اعلام شده از طرف سازمان حج و زيارت 3- 4- تحويل گذرنامه بين المللي معتبر ( داراي 7 ماه اعتبار از تاريخ پرواز ) و كپي كارت ملي و مدارك مورد نياز در موقع پذيرش و اخذ رسيد 4-4- ارتباط مستمر با كارگزار و ارائه شماره تلفن هاي پاسخگو 5- 4- شركت در دوره هاي آموزشي و توجيحي 6- 4- انجام واكسيناسيون مطابق با برنامه پيشنهادي كارگزار و انجام آزمايشات مورد نياز به تشخيص مركز پزشكي و ارائه آن 7- 4 – گواهي سلامت از پزشك دائر بر اجازه سفر عمره براي بيماران خاص و همراه داشتن داروهاي ضروري مورد نياز براي زائريني كه داراي بيماري خاص هستند و تاييد نسخه مربوطه به مهر پزشك معالج به زبان انگليسي 8-4- حضور به موقع در فرودگاه يا محل اعلام شده توسط كارگزار جهت عزيمت به فرودگاه 9-4- رعايت حجاب اسلامي ( پوشش چادر براي بانوان الزامي است ) و احترام و پايبندي به اخلاق اجتماعي 10- 4- رعايت مقررات و قوانين مربوط به سفر عمره كه از سوي جمهوري اسلامي ايران و عربستان وضع شده است . 11- 4- پذيرش دستورالعملهاي ابلاغ شده به كارگزار در خصوص انصراف و يا انتقال و يا ثبت نام در ليست انتظار 12- 4- اعلام مراتب انصراف به كارگزار و تكميل فرم انصراف و تعيين تكليف وضعيت باقي مانده وجوه خود حد اكثر ظرف يكماه 13-4- پرداخت خسارتهاي ناشي از انصراف و يا عدم حضور در پرواز به دليل نرسيدن يا ممنوع الخروج بودن .14- 4- مطالعه و قبول موارد مطرح شده در اين قرارداد و مطالعه و رعايت مطالب كتابها و بروشورها ي ارائه شده توسط كار گزار .15- 4- رعايت كامل مقررات گروهي و حضور به موقع در برنامه هاي اعلام شده از طرف مدير گروه 16-4- واريز هزينه عوارض خروج از كشور قبل از اعزام 17- 4- معرفي سرپرست متقاضي تشرف داراي الويت براي زائرين زير 17 سال 18- 4- معرفي محرم متقاضي تشرف داري الويت براي زائرين زن زير 45 سال .19- 4- در صورت عدم تمايل به اعزام پس از پرداخت قبض ما به التفاوت بايستي با هماهنگي كارگزار حد اكثر تا تاريخ پرواز قيد شده در فيش ما به التفاوت نسبت به ابطال فيش و پايدار كردن سند خود براي تشرف در سنوات بعدي يا انصراف دائم اقدام نمايد . 20- 4- در صورتي كه مرتكب اعمال مجرمانه در طول سفر گردم سازمان حج و زيارت ميتواند اينجانب حسب مورد بازگردانده و يا محدوديت هايي را براي سفرهاي زيارتي خارج از كشور بعدي برايم ايجاد نمايد و از اين بابت اعتراضي نخواهم داشت .<br />ماده 5- تعهدات كارگزار : 1- 5- اعلام تاريخ و شرايط پرواز به زائرين در زمان مقتضي . 2- 5- تنظيم فيش براي پرداخت هزينه هاي سفر زائرين و ثبت دقيق و صحيح اطلاعات زائرين در سيستم رايانه اي خود . 3- 5- دريافت و كنترل مدارك مورد نياز و ارائه رسيد به زائرين . 4- 5- اخذ رواديد و بليط هواپيما براي بليط زائرين و كنترل و بررسي و احراز صحت مفاد آنها 5- 5- انتخاب روحاني ، مدير راهنما و معاون ( با توجه به دستورالعمل مربوطه ) 6- 5- تنظيم برنامه آموزشي توجيهي در ايران حد اقل سه جلسه شامل يك جلسه متمركز استاني و دو جلسه كارواني براي زائرين با حضور مدير راهنما ، معاون و روحاني گروه برابر دستور العمل هاي ابلاغي استان 7- 5- تكميل توزيع كارت شناسايي و .... 8- 5- توزيع كتابچه ها و بروشورها و هرگونه مطالب و مكتوبات ويژه زائرين در زمان تعيين شده .9- 5- تكميل پلان اسكان و اعلام شماره اتاق و تلفن هتل به زائرين حد اكثر 72 ساعت قبل از پرواز .<br />ماده 6- مدت قرارداد :مدت اين قرارداد از زمان امضاء تا پايان سفر زيارتي عمره متقاضي تشرف ميباشد . <br />ماده 7 – انصراف زائر 1- 7- در صورتيكه بعد از ثبت نام منصرف از تشرف گردم پرداخت هزينه هاي انصراف به شرح دستورالعمل مالي كه كاملا" از مفاد آن مطلع شده ام را متقبل شده و سازمان ميتواند از محل وجوه پرداختي به نفع خود برداشت و باقيمانده را به اينجانب پرداخت نمايد . 2- 7- هرگونه خسارت به دليل غيبت زائر از پرواز مگر در موارد موجه بر اساس دستورالعمل غائبين از پرواز كه زائر كاملا" از مفاد آن مطلع ميباشد محاسبه و دريافت خواهد شد .<br />ماده 8 – موارد غير مترقبه : عليرغم اين كه برنامه ريزي جامعي به منظور اجراي دقيق تمامي مراحل اجرايي عمره انجام شده است و به خواست خداوند متعال و تلاش و همات تمامي دست اندركاران عمره انشا ء ا... طبق برنامه انجام خواهد شد . با اين حال ممكن است عواملي خارج از اراده و حوزه اختيارات و كنترل سازمان حج و زيارت و شركت هاي مجري عمره از جمله بحران هاي منطقه اي و پيامد هاي ناشي از آن در برخي از برنامه ها تاثير هر چند ناچيز داشته باشد و به هر حال بر روند اجراي عمليات تاثير گذار باشد لذا در ادامه به برخي از احتمالات و راهكارهاي اجرايي آن اشاره ميشود و به هرحال در صورت بروز اين گونه موارد مراحل عمليات منطبق با شرايط پيش آمده اعلام و انجام خواهد شد . 1- 8- احتمال عدم امكان پرواز از ايستگاه پروازي مورد نظر و انتقال نا گزير زائرين به ايستگاههاي مجاور 2- 8- احتمال طولاني تر شدن زمان پرواز به دليل ايجاد امنيت پروازي . 3- 8- احتمال ايجاد وقفه تغيير و يا تاخير در عمليات اعزام يا انجام پروازها . 4- 8- امكان تغيير هتل و نوع گروه قيمتي آن . 5- 8- احتمال ايجاد اختلال در روند صدور ويزا و در نتيجه به هم خوردن جداول زمان بندي پروازها و اعزام زائرين . 6- 8- احتمال عدم امكان انجام پرواز به مقصد ذكر شده در ابتداي سفر و تغيير مقصد از مدينه به جده و يا بالعكس . 7- 8- احتمال نوسان نرخ برابري ريال و دلار كه منجر به افزايش هزينه ارزي عمليات عمره ميشود بر اين اساس نرخ قطعي هزينه عمره تا دو هفته قبل از پرواز اعلام و ما به التفاوت توسط كارگزاران اخذ خواهد شد .<br />ماده 9- ساير شرايط : 1- 9- ثبت نام قطعي زائرين منوط به پرداخت هزينه سفر ، تحويل به موقع فيش بانكي ، گذرنامه و ساير مدارك لازم به كارگزار ميباشد . 2- 9- در صورتيكه در هر مرحله از ثبت نام اعزام عدم الويت فيش زائر اثبات گردد ثبت نام و اعزام زائر كان لم يكن تلقي شده و زائر ضمن تعهد به پرداخت خسارت مربوط حق هرگونه ادعايي را از خود و همراهان حسب مورد سلب ميكند . 3- 9- چنانچه در هنگام پرواز ، زائر به هر دليلي ( بجز تشابه اسمي ) ممنوع الخروج باشد ، تمام مسئوليت و عواقب ناشي از آن صرفا" متوجه زائر است . 4- 9- زائرين به هيچ عنوان حق جداشدن از كاروان و اقامت در محلي غير از محل اقامت كاروان را نداشته و سازمان حج و زيارت هيچگونه مسئوليتي در قبال زائريني كه خود سرانه اقدام به تردد به شهرهاي غير زيارتي همچون جده مينمايند ، نداشته و تبعات جدا شدن از كاروان به عهده خود زائر خواهد بود .5- 9- در صورت عدم رعايت حجاب اسلامي ( پوشش چادر براي بانوان ) و تائيد آن از سوي افراد مسئول ، سازمان حج و زيارت اين اختيار را دارد زائر مورد نظر را در هر مرحله اي از سفر به ايران بازگرداند .6-9- در صورتي كه زائري داراي بيماري خاص از جمله روحي و رواني بوده و امكان درمان و نگهداري آن در عربستان مقدور نباشد ، سازمان حج و زيارت اختيار دارد زائر مذكور را در هر مرحله اي از سفر به ايران بازگرداند . 7- 9- زائر در طول سفر عمره حق مطالبه گذرنامه را از مدير كاروان نداشته و گذرنامه صرفا" بر مبادي خروجي و ورودي كشور ميزبان و مهمان و براي انجام تشريفات اداري و گذرنامه اي در اختيار زائر قرار خواهد گرفت . 8- 9- در صورتي كه زائر زن زير 45 سال و فاقد محرم باشد سازمان حج و زيارت امكان اعزام وي را بربر قوانين موجود در كشور عربستان نخواهد داشت . 9- 9- با عنايت به اينكه نگهداري و حمل مواد مخدر و نيز اعتياد بدان به موجب قوانين جمهوري اسلامي ايران و عربستان صعودي ممنوع ميباشد ، چنانچه از رائري مواد مخدر كشف شود و يا به تشخيص پزشك معتمد ابتلاء وي به مواد مخدر احراز گرد د سازمان حج و زيارت ميتواند اجراي تعهدات خود در قبال زائر به ويژه اعزام وي را بدوا" به حالت تعليق درآورده و عنداللزوم و بدون آنكه نيازمند مراجعه به مقامات قضايي باشد قرارداد را فسخ نموده و اقدامات لازم را جهت ابطال ويزاي زيارتي فرد و يا افراد متخلف را به عمل آورد و از اين بابت زائر و يا زائرين مورد اشاره هيچگونه ادعايي نداشته و حق هرگونه اعتراضي را از خود سلب و ساقط مينمايند و خسارات ناشي از عدم تشرف بعهده زائر متخلف است .10-9- با توجه به ممنوعيت حمل داروهاي جايگزين مواد مخدر مانند قرص و شربت متادون در كشور عربستان زائرين اجازه حمل اين دارو ها را نداشته و در صورت كشف آن در مبادي خروجي كشور و عدم ارائه مجوز پزشكي دال بر مصرف آن امكان اعزام اين افراد ميسر نبوده و با آنان همانند حاملين مواد مخدر برخورد خواهد شد لكن در صورت دارا بودن مجوز پزشكي و همراه داشتن آن پليس فرود گاه ضمن توقيف داروي ممنوعه با اعزام زائر بدون داروي مذكور موافقت خواهد نمود . 11- 9- در صورت بروز موارد غير مترقبه مندرج در ماده 8 قرارداد ، سازمان حج و زيارت ميتواند نسبت به تغيير برنامه هاي اعزام و موارد ديگر اقدام نموده و زائر از اين بابت اعتراضي نخواهد داشت . 12- 9- اين قرارداد تابع قوانين جمهوري اسلامي ايران ميباشد . 13- 9- اين قرارداد در 9 ماده و يك تبصره و در 2 نسخه تنظيم و به امضاي طرفين رسيده و هر نسخه حكم واحد را دارد .<br />اينجانب ..................... اصالتا" و به نمايندگي زائرين مندرج در صفحه اول قرارداد كليه مفاد اين قرارداد را مطالعه و با قبول شرايط آن نسبت به امضاي آن اقدام نمودم .</p><p>نام و نام خانوادگي زائر                                                                     نام و نام خانوادگي مدير آژانس ( كارگزار )</p><p>امضاء و تاريخ                                                                                  مهر و امضاء</p>', '<tr valign="top"><td> <p align="center"><strong>#index#</strong></p></td><td>         <p align="center"> #gasht_name[]# </p>         </td><td>         <p align="center"> #gasht_shomare_shenasname[]# </p>         </td><td>         <p dir="ltr" align="center"> #gasht_tarikh_tavalod_frm[]# </p>         </td><td>         <p align="center"> #gasht_jander[]# </p>         </td><td>         <p align="center"> #gasht_shomare_seporde[]# </p>         </td><td>         <p align="center"> #gasht_code_melli[]# </p>         </td><td>         <p align="center"> #gasht_is_hamrah[]# </p>         </td><td>         <p align="center"> #gasht_sen[]# </p>         </td><td>         <p align="center"> #gasht_nesbat[]# </p>         </td></tr>'),
(4, 'روادید سوئد', '<p><strong>مدارك لازم جهت اخذ ويزا از سفارت سوئد در تهران:</strong></p> <p>1- فرم شنگن</p> <p>2- فرم اطلاعات خانواده</p> <p>3- اصل دعوتنامه از سوئد با امضاء و ذكر تاريخ و مدت زمان اقامت مهمان</p> <p>4- گواهي اقامت شخص دعوت كننده با اعتبار 3 ماهه</p> <p>5- كپي از كارت شناسائي دعوت كننده</p> <p>6- دو قطعه عكس رنگي جديد زمينه سفيد 4*6</p> <p>7- رواديد درخواست بانكيرسيد– پاسارگاد: بانك در سفارت حساب شماره</p> <p>8- بيمه نامه و كپي از صفحه اول آن بر اساس تعداد روزهاي درخواستي مسافر براي اقامت</p> <p>9- پرينت3 كه صورتي (در لاتين زبان به حساب معدل گواهي همراه به بانكي اخير ماهه</p> <p>و نموده تهيه پرينتي خود حساب از بايد ميكند را مسكن و ها هزينه تقبل كننده دعوتشخص</p> <p>10- حداقل با جديد گذرنامه از كپي واصل7 بودن دارا و حركت تاريخ از اعتبار ماه</p> <p>از كپي همراه به سفيد برگ دوحداقل7 شده صادر ويزاهاي تمامي و اول صفحه– گذرنامه</p> <p>2248100202020201</p> <p>حساب داراي حداقل 370 كرون به ازاي هر روز اقامت مهمان باشد.)</p> <p>هاي باطله</p> <p>11- شناسنامه و كپي از تمامي صفحات آن</p> <p>12- اصل و كپي از طلاق نامه، سند ازدواج، گواهي فوت</p> <p>13- تغييرات، آخرين آگهي و رسمي روزنامه بيمه، سوابق شغلي( مدرك از كپي واصل</p> <p>حقوقي، فيش آخرين همراه به بازنشستگي يا استخدام حكم برداري، بهره يا كسبپروانه</p> <p>و...) مطبپروانه – مرخصي با موافقت اطلاعات داراي بايد حتما كار به اشتغال نامه</p> <p>كارمند، سمت، ميزان حقوق دريافتي و مدت زمان اشتغال به كار را داشته باشد.</p>', ''),
(5, 'روادید شینگن ایتالیا', '<p><strong>مدارك لازم جهت اخذ ويزاي شنگن از سفارت ايتاليا :</strong></p>\r\n<p>1- پاسپورت امضا شده با حداقل شش ماه اعتبار از تاريخ حركت به همراه كپي از صفحه مشخصات و صفحات ويزا</p>\r\n<p>2- پاسپورت قديم در صورتيكه داراي ويزاي كشورهاي معتبر باشد به همراه كپي از صفحه مشخصات و صفحات ويزا</p>\r\n<p>3- اصل شناسنامه به همراه ترجمه و كپي از صفحات آن</p>\r\n<p>4- اصل مدرك شغلي به همراه ترجمه و كپي (روزنامه رسمي + آگهي آخرين تغييرات، استعلام سوابق بيمه + ليست</p>\r\n<p>بيمه 6 ماهه اخير، پروانه بهره برداري، جواز كسب، پروانه مطب، حكم كارگزيني + آخرين فيش حقوقي، حكم</p>\r\n<p>بازنشستگي + آخرين فيش حقوقي، كارت بازرگاني)</p>\r\n<p>5- اصل اسناد مالكيت به همراه ترجمه</p>\r\n<p>6- پرينت لاتين گردش حساب 6 ماهه اخير بانكي</p>\r\n<p>7- دو قطعه عكس 4 × 3</p>\r\n<p>8- اصل گواهي تحصيلي فرزندان به همراه ترجمه</p>\r\n<p>9- مبلغ 60 يورو بابت بررسي رواديد براي هر نفر در سفارت</p>\r\n<p>تنها با مهر دارالترجمه</p>', ''),
(6, 'روادید شینگن پرتغال', '<p><strong>مدارك لازم جهت اخذ ويزاي شنگن از سفارت پرتغال :</strong></p>\r\n<p>1- پاسپورت امضا شده با حداقل شش ماه اعتبار از تاريخ حركت به همراه كپي از صفحه مشخصات و صفحات ويزا</p>\r\n<p>2- پاسپورت قديم در صورتيكه داراي ويزاي كشورهاي معتبر باشد به همراه كپي از صفحه مشخصات و صفحات ويزا</p>\r\n<p>3- اصل شناسنامه به همراه ترجمه و كپي از صفحات آن</p>\r\n<p>4- اصل مدرك شغلي به همراه ترجمه و كپي (روزنامه رسمي،آگهي آخرين تغييرات-حكم كارگزيني،آخرين فيش حقوقي-</p>\r\n<p>جواز كسب، پروانه مهندسي، پروانه مطب...)</p>\r\n<p>5- ليست بيمه شش ماهه اخير به همراه ترجمه (درصورتي كه در جائي كارمند هستيد)</p>\r\n<p>6- اصل اسناد مالكيت به همراه ترجمه</p>\r\n<p>7- پرينت لاتين گردش حساب 6 ماهه اخير بانكي</p>\r\n<p>8- دو قطعه عكس 4 × 3</p>\r\n<p>9- اصل گواهي تحصيلي فرزندان به همراه ترجمه ( درصورت همراهي فرزرندان )</p>\r\n<p>مدارك مي بايست به تأييد وزارت دادگستري و وزارت امور خارجه نيز برسند.</p>', ''),
(7, 'روادید شینگن فرانسه', 'مدارك لازم جهت اخذ ويزاي شنگن از سفارت فرانسه :\r\n\r\n1- پاسپورت امضا شده با حداقل شش ماه اعتبار از تاريخ حركت به همراه كپي از صفحه مشخصات و صفحات ويزا\r\n\r\n2- پاسپورت قديم در صورتيكه داراي ويزاي كشورهاي معتبر باشد به همراه كپي از صفحه مشخصات و صفحات ويزا\r\n\r\n3- اصل شناسنامه به همراه كپي از صفحات آن\r\n\r\n4- اصل مدرك شغلي به همراه كپي\r\n\r\n5- ليست بيمه شش ماهه اخير \r\n\r\n6- اصل اسناد مالكيت به همراه كپي\r\n\r\n7- پرينت گردش حساب 6 ماهه اخير بانكي\r\n\r\n8- دو قطعه عكس5/4 × 5/3\r\n\r\n9- برگه اشتغال به تحصيل از سوي دانشجو ترجيحاً به نام سفارت فرانسه در تهران\r\n\r\n10- مبلغ 60 يورو در سفارت به ازاي هر نفر', ''),
(8, 'روادید شینگن فنلاند', '<p><strong>مدارك لازم جهت اخذ ويزاي شنگن از سفارت فنلاند :</strong></p>\r\n<p>1- پاسپورت امضا شده با حداقل شش ماه اعتبار از تاريخ حركت به همراه كپي از صفحه مشخصات و صفحات ويزا</p>\r\n<p>2- پاسپورت قديم در صورتيكه داراي ويزاي كشورهاي معتبر باشد به همراه كپي از صفحه مشخصات و صفحات ويزا</p>\r\n<p>3- اصل شناسنامه به همراه ترجمه و كپي از صفحات آن</p>\r\n<p>4- اصل مدرك شغلي به همراه ترجمه و كپي (روزنامه رسمي،آگهي آخرين تغييرات-حكم كارگزيني،آخرين فيش حقوقي-</p>\r\n<p>جواز كسب، پروانه مهندسي، پروانه مطب...)</p>\r\n<p>5- ليست بيمه شش ماهه اخير به همراه ترجمه (درصورتي كه در جائي كارمند هستيد)</p>\r\n<p>6- اصل اسناد مالكيت به همراه ترجمه</p>\r\n<p>7- پرينت لاتين گردش حساب 6 ماهه اخير بانكي</p>\r\n<p>8- دو قطعه عكس 4 × 6</p>\r\n<p>9- اصل گواهي تحصيلي فرزندان به همراه ترجمه ( درصورت همراهي فرزرندان )</p>\r\n<p>مدارك مي بايست به تأييد وزارت دادگستري نيز برسند.</p>', ''),
(9, 'روادید شینگن مجارستان', '<p><strong>مدارك لازم جهت اخذ ويزاي شنگن از سفارت مجارستان :</strong></p>\r\n<p>1- پاسپورت امضا شده با حداقل شش ماه اعتبار از تاريخ حركت به همراه كپي از صفحه مشخصات و صفحات ويزا</p>\r\n<p>2- پاسپورت قديم در صورتيكه داراي ويزاي كشورهاي معتبر باشد به همراه كپي از صفحه مشخصات و صفحات ويزا</p>\r\n<p>3- اصل شناسنامه به همراه ترجمه و كپي از صفحات آن</p>\r\n<p>4- اصل مدرك شغلي به همراه ترجمه و كپي (روزنامه رسمي + آگهي آخرين تغييرات، استعلام سوابق بيمه + ليست</p>\r\n<p>بيمه 6 ماهه اخير، پروانه بهره برداري، جواز كسب، پروانه مطب، حكم كارگزيني + آخرين فيش حقوقي، حكم</p>\r\n<p>بازنشستگي + آخرين فيش حقوقي، كارت بازرگاني)</p>\r\n<p>5- اصل اسناد مالكيت به همراه ترجمه</p>\r\n<p>6- پرينت لاتين گردش حساب 3 ماهه اخير بانكي</p>\r\n<p>7- دو قطعه عكس 4 × 3 جدید رنگی زمینه سفید</p>\r\n<p>8- اصل گواهي تحصيلي فرزندان به همراه ترجمه</p>\r\n<p>9- مبلغ 60 يورو بابت بررسي رواديد براي هر نفر در سفارت</p>\r\n<p>مدارک ترجمه شده می بایست به تأیید دادگستری و وزارت امور خارجه نیز برسد.</p>', ''),
(10, 'روادید شینگن هلند', '<p><strong>مدارك لازم جهت اخذ ويزاي شنگن از سفارت هلند :</strong></p>\r\n<p>1- پاسپورت امضا شده با حداقل شش ماه اعتبار از تاريخ حركت به همراه كپي از صفحه مشخصات و صفحات ويزا</p>\r\n<p>2- پاسپورت قديم در صورتيكه داراي ويزاي كشورهاي معتبر باشد به همراه كپي از صفحه مشخصات و صفحات ويزا</p>\r\n<p>3- اصل شناسنامه به همراه ترجمه و كپي از صفحات آن</p>\r\n<p>4- اصل مدرك شغلي به همراه ترجمه و كپي (روزنامه رسمي،آگهي آخرين تغييرات-حكم كارگزيني،آخرين فيش حقوقي-</p>\r\n<p>جواز كسب، پروانه مهندسي، پروانه مطب...)</p>\r\n<p>5- ليست بيمه شش ماهه اخير به همراه ترجمه (درصورتي كه در جائي كارمند هستيد)</p>\r\n<p>6- اصل اسناد مالكيت به همراه ترجمه</p>\r\n<p>7- پرينت لاتين گردش حساب 6 ماهه اخير بانكي</p>\r\n<p>8- دو قطعه عكس 4 × 5*3</p>\r\n<p>9- اصل گواهي تحصيلي فرزندان به همراه ترجمه ( درصورت همراهي فرزرندان )</p>\r\n<p>مدارك مي بايست به تأييد وزارت دادگستري و امور خارجه نيز برسند.</p>', ''),
(11, 'قرارداد گشتهای داخل کشور', '<div style="float: left;"><img src="/crm/assets/img/donya_logo.jpg" alt="" width="152" height="90" /></div><div style="float: right;"><img src="/crm/assets/img/donya_logo_fa.jpg" alt="" height="90" /></div><p style="text-align: center;"><strong>بسمه تعالی</strong></p><p style="text-align: center;">اوفوا بالعهد ان العهد کان مسئولاً</p><p style="text-align: center;"><span style="font-size: 14pt;"><strong> قرارداد گشتهای داخل کشور</strong></span></p><p style="text-align: right;"><span style="font-size: 10pt;">ثبت نام کننده: #user_sabti#<br />این قرارداد فی مابین خانم/آقای #fname1# #lname1#  فرزند : #pedar_name# به شماره شناسنامه: #gasht_shomare_shenasnameh#  تاریخ تولد: #tarikh_tavalod# آدرس: #address# تلفن: #tell# و همراه: #mob# منفرداً یا به نمایندگی تام الاختیار از سوی افراد زیر جمعاً به تعداد #gasht_edad# نفر که از این پس مسافر نامیده می شود از یک طرف و دفتر / شرکت خدمات گردشگری: دنیاسیر به شماره پروانه:       مورخ:      صادره از سوی اداره کل میراث فرهنگی، صنایع دستی و گردشگری استان : خراسان رضوی که از این پس کارگزار نامیده می شود از طرف دیگر، که برنامه سفر نیز در اختیار مسافر قرار گرفته است در تاریخ #gasht_tarikh#  ساعت #gasht_saate# منعقد گردید. <br />ضمناً نام راهنمای تور آقا/ خانم : #gasht_rahnama# فرزند :#gasht_rahnama_fathername# دارای کارت شناسایی : #gasht_card#  می باشد.<br /><strong>الف) مشخصات مسافر یا مسافرین</strong> </span></p><p style="text-align: right;"> </p><table class="list_table" style="margin-left: auto; margin-right: auto; width: 21cm;" border="1"><tbody><tr><td>ردیف</td><td>نام و نام خانوادگی -فارسی</td><td>نرخ تور</td><td>شماره گذرنامه</td><td>مدت اعتبار گذرنامه</td><td>کدملی</td><td>تاریخ‌تولد</td><td>نسبت</td></tr>#hamrahan#</tbody></table><p style="text-align: right;"><span style="font-size: 10pt;"><strong>ب) برنامه گشت</strong></span></p><table class="list_table" style="margin-left: auto; margin-right: auto; width: 21cm;" border="1" ><tbody><tr><td>تاریخ رفت</td><td>ساعت</td><td>تاریخ برگشت</td><td>ساعت</td><td>وسیله حمل و نقل</td><td>ایرلاین</td><td>تعداد شبهای اقامت</td></tr><tr><td> #gasht_raft_tarikh#</td><td> #gasht_raft_saat# </td><td> #gasht_bargasht_tarikh# </td><td> #gasht_bargasht_saat# </td><td> #gasht_vasile# </td><td> #gasht_airline# </td><td> #gasht_shab# </td></tr></tbody></table><table class="list_table hs-margin-up-down" style="margin-left: auto; margin-right: auto; width: 21cm;" border="1" ><tbody><tr><td rowspan="2" bgcolor="#eeece1" width="20"><p  align="center"><span style=""><span style="font-size: small;"><span lang="fa-IR"><b>ردیف</b></span></span></span></p></td><td colspan="2" bgcolor="#eeece1" width="117"><p  align="center"><span ><span style="font-size: small;"><span lang="fa-IR"><b><span style="">شهرهای</span> <span style="">مورد</span> <span style="">بازدید</span></b></span></span></span></p></td><td colspan="7" bgcolor="#eeece1" width="347"><p  align="center"><span ><span style="font-size: small;"><span lang="fa-IR"><b><span style="">هتل،</span> <span style="">خدمات</span> <span style="">و</span> <span style="">پذیرایی</span></b></span></span></span></p></td><td rowspan="2" bgcolor="#eeece1" width="156"><p  align="center"><span ><span style="font-size: small;"><span lang="fa-IR"><b><span style="">سایر</span> <span style="">خدمات</span></b></span></span></span></p></td></tr><tr><td width="52"><p  align="center"><span ><span style="font-size: small;"><span lang="fa-IR"><b><span style="">تاریخ</span> </b></span></span></span></p></td><td width="52"><p  align="center"><span ><span style="font-size: small;"><span lang="fa-IR"><b><span style="">نام</span> <span style="">شهر</span></b></span></span></span></p></td><td width="38"><p  align="center"><span ><span style="font-size: small;"><span lang="fa-IR"><b><span style="">نام</span> <span style="">هتل</span></b></span></span></span></p></td><td width="38"><p  align="center"><span style=""><span style="font-size: small;"><span lang="fa-IR"><b>ستاره</b></span></span></span></p></td><td width="38"><p  align="center"><span ><span style="font-size: small;"><span lang="fa-IR"><b><span style="">نوع</span> <span style="">اتاق</span></b></span></span></span></p></td><td width="38"><p  align="center"><span style=""><span style="font-size: small;"><span lang="fa-IR"><b>صبحانه</b></span></span></span></p></td><td width="38"><p  align="center"><span style=""><span style="font-size: small;"><span lang="fa-IR"><b>ناهار</b></span></span></span></p></td><td width="38"><p  align="center"><span style=""><span style="font-size: small;"><span lang="fa-IR"><b>شام</b></span></span></span></p></td><td width="38"><p  align="center"><span style=""><span style="font-size: small;"><span lang="fa-IR"><b>ترانسفر</b></span></span></span></p></td></tr><tr><td width="20" height="26"><p  align="center"> 1 </p></td><td width="52"> #gasht_hotel_tarikh# </td><td width="52"> #gasht_city# </td><td width="52"> #gasht_hotel# </td><td width="38"> #gasht_star# </td><td width="38"> #gasht_room_typ# </td><td width="38"> #gasht_sobhane# </td><td width="38"> #gasht_nahar# </td><td width="38"> #gasht_sham#</td><td width="38"> #gasht_transfer#</td><td width="156"> #gasht_sayer#</td></tr></tbody></table><p style="text-align: right;"><strong>ج) توضیحات</strong> </p> #gasht__toz# <p style="text-align: right;"><span style="font-size: 12pt;"><strong> تور چارتر و غیر قابل استرداد می باشد.</strong></span></p><p><strong>موضوع قرارداد:</strong><br />موضوع این قرارداد تعیین حدود و وظایف و مسئولیت های طرفین قرارداد و همچنین نرخ گشت برای انجام مسافرت به طور دسته جمعی و انفرادی می باشد:<br />توضیح: گشت هاي نوروزي گشت هائی است که درفاصله زمانی 28 اسفند لغایت 15 فروردین سال بعد برگزار می گردد.<br />گشتهاي یکروزه از شمول مورد فوق مثتثنی می باشد.</p><p><img src="/crm/assets/img/frm_11.jpg" alt="" width="100%" /></p><p><strong>1) تعهدات کارگزار:</strong></p><p>1.1) کارگزار متعهد است ضمن استفاده از وسیله ویژه توریستی بصورت دربست در گشت هاي زمینی، تقدم جا را در ا توبوس برحسب تاریخ ثبت نام تعیین نماید.<br />1.2) کارگزار متعهد است کل برنامه هاي خدمات گشت را بصورت بروشور و یا کتباً به مسافر تقدیم و رسید دریافت دارد.<br />1.3) کارگزار متعهد است برنامه سفر و گشت مورد توافق رابطور کامل و دقیق انجام دهد.<br />تبصره1: در صورت وقوع هرگونه پیشامد غیر منتظره از قبیل شرایط فوق العاده جوي و مشکلاتی که از کنترل کارگزار خارج بوده وسبب ابطال و یا تغییر برنامه مسافرت شود مسئولیتی متوجه کارگزار نخواهد بود.<br />تبصره2: در صورت تغییر برنامه گشت و مسافرت و یا افزایش قیمت بهر دلیلی مسافر در همراهی با تور مخیراست.<br />1.4) کارگزار متعهد است درصورت ابطال گشت (بجز موارد مطروحۀ درتبصره1 بند 3) ضمن استرداد کلیه وجوه دریافتی به مسافر 20 % کل هزینه را بعنوان خسارت به مسافر بپردازد.<br />1.5) کارگزار متعهد است بیمه کامل مسافرتی را در مورد مسافر اعمال نماید و در صورت بروز هرگونه حادثه اي در طول سفر همکاري و مساعدت لازم را بعمل آورد.<br />1.6) کارگزار متعهد است نسبت به تنظیم قرارداد اقدام و یک نسخه ازآنرادرقبال اخذ رسید به مسافر ارائه دهد.<br /><strong>2) تعهدات مسافر:</strong><br />2.1) مسافرمتعهد است شئونات اسلامی را درطول سفر کاملا رعایت نماید.<br />2.2) مسافر متعهداست شناسنامه عکسدار و کارت ملی براي کلیه گشتها بهمراه داشته باشد.<br />2.3) مسافر متعهد است درساعات اعلام شده دربر نامه گشت شرکت نماید درغیراینصورت هیچ مسئولیتی بعهده کارگزار نخواهد بود.<br />2.4) مسافر متعهد است هزینه هاي اضافی خارج از برنامه راخود بپردازد.<br />2.5) مسافر متعهداست درخواست انصراف ازسفر خودرا حضوري و یا توسط نماینده رسمی و به صورت کتبی به کارگزار اعلام و رسید دریافت نماید.<br />2.6) مسافر متعهد است 50 ٪ هزینه گشت را درهنگام عقد قرارداد ومابقی را 48 ساعت قبل از انجام سفر بهمراه کلیه مدارك ، درقبال اخذرسید تحویل کارگزار نماید.</p><p>3) مسافر و کارگزار ، اداره کل میراث فرهنگی ، صنایع دستی و گردشگري را بعنوان حکم مرض الطرفین تعیین ، تا درصورت بروز هرگونه اختلافی دررابطه با این قرار داد اعلام نظر نماید. بدیهی است نظر ایشان قطعی وبراي طرفین لازم الاجراست.</p><p style="text-align: right;"><strong>نام و نام خانوادگی مسافر و یا نماینده مسافر                              نام و نام خانوادگی مدیرعامل/ مدیر/ مدیر فنی شرکت / دفتر خدمات مسافری مهر و امضا مهر و امضا</strong></p><p style="text-align: right;"> </p><p style="text-align: right;"> </p><p style="text-align: right;">  </p><p style="text-align: right;"> </p>', '<tr valign="top">         <td width="25" height="2"> <p align="center"><strong>#index#</strong></p></td>        <td width="">         <p align="center"> #name# </p>         </td>		<td width="">         <p align="center"> #gasht_pedar[]# </p>         </td>		<td width="">         <p dir="ltr" align="center"> #passport# </p>         </td>		<td width="">         <p align="center"> #gasht_hazine_mosafer[]# </p>         </td>		<td width="">         <p align="center"> #code_melli# </p>         </td>		<td width="">         <p align="center"> #tarikh_tavalod# </p>         </td>		<td width="">         <p align="center"> #gasht_nesbat[]# </p>         </td></tr>a');

-- --------------------------------------------------------

--
-- Table structure for table `reshte`
--

CREATE TABLE IF NOT EXISTS `reshte` (
`id` int(11) NOT NULL,
  `name` varchar(500) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `session`
--

CREATE TABLE IF NOT EXISTS `session` (
`pid` int(11) NOT NULL,
  `id` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `data` mediumtext COLLATE utf8_persian_ci NOT NULL,
  `firstTime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastUpdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shekl`
--

CREATE TABLE IF NOT EXISTS `shekl` (
`id` int(11) NOT NULL,
  `name` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `pic` varchar(200) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shoghl`
--

CREATE TABLE IF NOT EXISTS `shoghl` (
`id` int(11) NOT NULL,
  `name` varchar(500) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `shoghl`
--

INSERT INTO `shoghl` (`id`, `name`) VALUES
(1, 'آزاد'),
(2, 'بیکار'),
(3, 'کارمند');

-- --------------------------------------------------------

--
-- Table structure for table `tahsilat`
--

CREATE TABLE IF NOT EXISTS `tahsilat` (
`id` int(11) NOT NULL,
  `name` varchar(500) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `tahsilat`
--

INSERT INTO `tahsilat` (`id`, `name`) VALUES
(1, 'بی سواد'),
(2, 'سیکل'),
(3, 'دیپلم'),
(4, 'کاردانی'),
(5, 'کارشناسی'),
(6, 'کارشناسی ارشد'),
(7, 'دکترای عمومی'),
(8, 'Phd');

-- --------------------------------------------------------

--
-- Table structure for table `taminkonande`
--

CREATE TABLE IF NOT EXISTS `taminkonande` (
`id` int(11) NOT NULL,
  `name` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `toz` mediumtext COLLATE utf8_persian_ci NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `taminkonande`
--

INSERT INTO `taminkonande` (`id`, `name`, `toz`, `ordering`) VALUES
(1, 'رسپینا', '', 0),
(2, 'مارکو پلو', '', 0),
(3, 'امیرتوس', '', 0),
(4, 'ره بال آسمان', '', 0),
(5, 'هتل قصر', '', 0),
(6, 'هتل درویشی', '', 0),
(7, 'داخلی-دنیاسیر', '', 1),
(8, 'صدف', '', 0),
(9, 'پالم بیچ', '006626356207', 0),
(10, 'هماتور', '006622377194', 0),
(11, 'آریا گراپ', 'ariagrap.amini@gmail.com ', 0),
(12, 'ثریا تور', '02188206000', 0),
(13, 'پرشیا تور', '007964342-84-86      ', 0),
(14, 'گرین کانتینت', '0048537482798', 0),
(15, 'بلو بل', 'info@bbtravel.ir', 0),
(16, 'سرزمین جنوبی', '0027214619991', 0),
(17, 'صدف سرو', 'sahar@sadafsarv.com', 0),
(18, 'دریم دیز', 'visa.ddholidays@yahoo.com', 0),
(19, 'سهند', '0090 2122550487', 0),
(20, 'قشقایی', '0090 2423492110', 0),
(21, 'مینار', 'rkhoshamadi@yahoo.com', 0),
(22, 'اورینتال دریم', ' 86 - 10 - 85976001 ', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tamin_khadamat`
--

CREATE TABLE IF NOT EXISTS `tamin_khadamat` (
`id` int(11) NOT NULL,
  `factor_id` int(11) NOT NULL,
  `taminkonande_id` int(11) NOT NULL,
  `mablagh` int(11) NOT NULL,
  `vahed_mablagh_id` int(11) NOT NULL,
  `khadamat_tamin_id` int(11) NOT NULL,
  `khadamat_id` int(11) NOT NULL,
  `toz` mediumtext COLLATE utf8_persian_ci NOT NULL,
  `en` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `tamin_khadamat`
--

INSERT INTO `tamin_khadamat` (`id`, `factor_id`, `taminkonande_id`, `mablagh`, `vahed_mablagh_id`, `khadamat_tamin_id`, `khadamat_id`, `toz`, `en`) VALUES
(2, 11, 2, 20000, 1, 1, 1, 'توضیحات این فاکتور شماره یازده', 1),
(19, 11, 6, 10000, 4, 2, 2, 'ندارد', 1),
(20, 24, 3, 123323333, 1, 2, 2, '', 1),
(21, 24, 1, 133232, 1, 1, 1, '', 1),
(22, 10, 4, 11000, 1, 6, 1, '', 1),
(23, 37, 4, 1100000, 1, 1, 1, 'بلیط غیرقابل استرداد', 1),
(24, 37, 7, 1704000, 1, 6, 1, 'قابل استرداد', 1),
(25, 37, 2, 2000000, 1, 2, 2, 'سه ستاره قابل تغییر به چهارستاره', 1),
(26, 41, 4, 6403000, 1, 1, 1, 'غیرقابل استرداد', 1),
(27, 41, 2, 5000000, 1, 2, 2, '', 1),
(28, 47, 4, 4000000, 1, 1, 1, 'غیرقابل استرداد.عباسی', 1),
(35, 64, 3, 4000000, 2, 2, 2, '', 1),
(36, 1, 7, 3000000, 1, 1, 1, '', 1),
(37, 1, 17, 4000000, 1, 0, 6, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tour`
--

CREATE TABLE IF NOT EXISTS `tour` (
`id` int(11) NOT NULL,
  `name` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `factor_id` int(11) NOT NULL,
  `khadamat_factor_id` int(11) NOT NULL,
  `parvaz_id` int(11) NOT NULL,
  `hotel_id` int(11) NOT NULL,
  `tarikh` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `shab` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
`id` int(11) NOT NULL,
  `fname` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `lname` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `code_melli` varchar(30) COLLATE utf8_persian_ci NOT NULL,
  `tarikh_tavalod` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `shoghl_id` int(11) NOT NULL,
  `tahsilat_id` int(11) NOT NULL,
  `grooh_khooni_id` int(11) NOT NULL,
  `tell` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `mob` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `address` mediumtext COLLATE utf8_persian_ci NOT NULL,
  `user` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `pass` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `pass_emza` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `emza_path` varchar(1000) COLLATE utf8_persian_ci NOT NULL,
  `group_id` int(11) NOT NULL DEFAULT '-1',
  `email` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `passport` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `pic` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `pedar_name` varchar(200) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fname`, `lname`, `code_melli`, `tarikh_tavalod`, `shoghl_id`, `tahsilat_id`, `grooh_khooni_id`, `tell`, `mob`, `address`, `user`, `pass`, `pass_emza`, `emza_path`, `group_id`, `email`, `passport`, `pic`, `pedar_name`) VALUES
(18, 'عاطفه', 'اسعدی', '1', '1969-03-21 00:00:00', 1, 1, 4, '05137648023', '09332635752', 'شهرکرد خیابان امام خمینی پلاک ۵', 'admin', 'admin', '1', '', 1, 'hscomp2002@gmail.com', '', '', ''),
(24, 'سمیه', 'طبسی', '0938944429', '1982-11-30 00:00:00', 3, 6, 0, '38670214', '09351530432', 'هنرستان 23 مجتمع چمران 3 بلوک 2 طبقه دوم', '0938944429', '2437348', '', '', 2, 'yasa.tabasi@yahoo.com', '', '', ''),
(25, 'مهدی', 'کیانی ساعی', '0075760886', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '0075760886', '', '', '', 2, '', '', '', ''),
(26, 'الهه', 'سفری ', '0921993730', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '0921993730', '', '', '', 2, '', '', '', ''),
(27, 'زینب ', 'بیگله', '2002695131', '1982-07-30 00:00:00', 3, 6, 0, '35023748', '09151237938', 'بولوار دندانپزشکان - دندانپزشکان 8 پلاک 20 طبقه دوم', '2002695131', '504032', '', '', 2, 'donyaseir_bigeleh@yahoo.com', '', '', ''),
(28, 'محبوبه ', 'ناصحی', '0944650813', '1985-12-22 00:00:00', 3, 3, 0, '36180249', '0950576772', 'قاسم آباد- بلوار اندیشه - اندیشه 79', '0944650813', '2242841', '', '', 4, 'maryammo2009@yahoo.com', '', '', ''),
(29, 'فاطمه ', 'حسین زاده', '0930688171', '1968-04-20 00:00:00', 3, 3, 0, '37263023', '09155154957', 'خیابان آبکوه - تکتم شمالی - نبش تکتم 16 ', '0930688171', '20318811', '', '', 2, 'hosseinzadeh_f45@yahoo.com', '', '', ''),
(30, 'بهزاد', 'طینتی', '0941283453', '1982-08-20 00:00:00', 3, 4, 0, '38461432', '09157905200', 'خیابان رودکی 22 پلاک 138', '0941283453', '2353558', '', '', 4, 'behzad.tinati@gmail.com', '', '', ''),
(31, 'شادی', 'شهنازی فر', '0946371237', '1986-09-17 00:00:00', 3, 5, 0, '37612100', '09369200168', 'بلوار سجاد - خیابان بنفشه 11 - پلاک 78 -طبقه دوم ', '0946371237', '2147677', '', '', 2, 'shadi.shahnazifar@gmail.com', '', '', ''),
(32, 'امیر', 'مولایی', '1289065675', '1980-03-25 00:00:00', 3, 5, 0, '37632172', '09151001593', 'قاسم آباد - شریعتی 43 -حاتمی 3 ', '1289065675', '2346838', '', '', 4, 'amir.mollaei@yahoo.com', '', '', ''),
(33, 'رضا ', 'آذرنیوه', '0839563310', '1984-12-07 00:00:00', 3, 5, 0, '36041646', '09155107781', 'خیابان جلال آل احمد 54 پلاک 172  ', '0839563310', '729659', '', '', 4, 'azarniuh63@yahoo.com', '', '', ''),
(34, 'زهرا', 'شیرزاده', '0920710271', '1990-04-14 00:00:00', 3, 5, 0, '38677403', '09150280569', 'دانشجوی 4 پلاک 50 طبقه سوم', '0920710271', '1906527', '', '', 2, 'donyaseir_sh@yahoo.com', '', '', ''),
(35, 'اسمعیل', 'گنه بدرآباد', '0940650991', '1969-03-21 00:00:00', 3, 3, 0, '38650115', '09151172884', 'بلوار صیاد شیرازی 11 پلاک 37 طبقه سوم ', '0940650991', '20497576', '', '', 2, 'e.badrabadi@yahoo.com', '', '', ''),
(36, 'فاطمه ', 'غلامی ثانی', '3621141413', '1977-09-23 00:00:00', 3, 5, 0, '38822678', '09155109024', 'بلوار فکوری - بین فکوری 36-38 پلاک 374 طبقه دوم', '3621141413', '223953', '', '', 2, 'donyaseir_gholami@yahoo.com', '', '', ''),
(37, 'سروش', 'اخباری', '0941197794', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '0941197794', '', '', '', 2, '', '', '', ''),
(38, 'راضیه', 'نکاهی', '0941781585', '1963-11-27 00:00:00', 3, 3, 0, '38680567', '09155022722', 'دانشجو 34 پلاک 15 ', '0941781585', '952914', '', '', 2, 'r.nekahi2020@gmail.com', '', '', ''),
(39, 'سحر', 'فلکی', '0946821968', '1987-05-31 00:00:00', 3, 5, 0, '38476547', '09151109322', 'خیابان کوهسنگی - رودکی 34 - پلاک 14 طبقه اول', '0946821968', '2484682', '', '', 2, 'donyaseir.falaki@gmail.com', '', '', ''),
(40, 'صفورا', 'صنعتی', '0945228007', '1986-08-21 00:00:00', 3, 5, 0, '35239099', '09357166655', 'قاسم آباد - شهید رفیعی5 بلوک 47 ', '0945228007', '1627678', '', '', 2, 'donyaseir_sanati@yahoo.com', '24480525', '', ''),
(41, 'فریبا', 'شاهابادی', '1379316243', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '1379316243', '', '', '', 2, '', '', '', ''),
(42, 'رقیه', 'عباسی', '0940033968', '1984-05-12 00:00:00', 3, 5, 0, '32701708', '09367948449', 'خیابان گاز 20 متری المهدی 5 پلاک 1', '0940033968', '979547', '', '', 4, 'r_abbasi63@yahoo.com', '', '', ''),
(43, 'الناز', 'ریون شکوه', '0945300816', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '0945300816', '', '', '', 2, '', '', '', ''),
(44, 'زهره', 'عباسیان فلاحی', '09400811271', '1985-02-06 00:00:00', 3, 5, 0, '32211209', '09150086949', 'راه آهن - خیابان آیت اله بهجت 18 پلاک 149', '09400811271', '499742', '', '', 2, 'donyaseir.abasian@gmail.com', '', '', ''),
(45, 'احسان', 'رضوانی', '0939052865', '1984-08-21 00:00:00', 3, 3, 0, '36075783', '09368535696', 'آزادشهر - امامت 8 پلاک 28', '0939052865', '1558356', '', '', 2, 'ehsan007r@yahoo.com', '', '', ''),
(46, 'فریبا', 'طوسی', '0941342247', '1983-09-27 00:00:00', 3, 4, 0, '32217526', '09159116101', 'میدان شهدا - هاشمی نژاد 1 پلاک 32', '0941342247', '1655068', '', '', 2, 'f.tousi84@yahoo.com', '', '', ''),
(47, 'معصوه ', 'کامیاب', '0937953288', '1978-03-24 00:00:00', 3, 3, 0, '38533429', '09352249157', 'فدائیان اسلام 11 نبش قباد 5 پلاک 13/83 واحد 1', '0937953288', '5982500', '', '', 2, 'donyaseir.kamiab@gmail.com', '', '', ''),
(48, 'خسرو', 'صفری آهنی', '0942295056', '1971-10-20 00:00:00', 3, 5, 1, '09153320602', '09124276625', 'آژانس مسافرتی دنیا سیر', '0942295056', '1212', '0942295056', '', 1, 'khosro_p51@yahoo.com', '12065394', '', ''),
(49, 'مجید', 'یحیی شیبانی', '0839502291', '1973-09-07 00:00:00', 3, 5, 0, '3849897', '09153154955', 'ابوذر غفاری 31 پلاک 111', '0839502291', '502981', '', '', 1, 'sheibani2001@yahoo.com', '', '', ''),
(50, 'فرهاد', 'دوایی', '0937818910', '1971-08-05 00:00:00', 3, 3, 0, '38548600', '09151151632', 'فلسطین 14 پلاک 57 طبقه اول واحد 2 ', '0937817910', '7830', '', '', 1, 'f_davaei@yahoo.com', '', '', ''),
(52, 'مهناز', 'وزیری', '0933696981', '1976-08-26 00:00:00', 3, 3, 0, '35213946', '09353389196', 'قاسم آباد - شریعتی 73 پلاک 144 ', '0933696981', '1795827', '', '', 2, 'donyaseirshobeh1@yahoo.com', '', '', ''),
(53, 'شیوا ', 'چشمی', '0794903657', '1986-03-16 00:00:00', 3, 6, 0, '44670582', '09359642243', 'صیاد شیرازی 5 - پلاک 35 -طبقه اول', '0794903657', '562993', '', '', 2, 'donyaseir_cheshmy@yahoo.com', '', '', ''),
(54, 'رضا', 'ساهالی گرمرودی', '0943252571', '0000-00-00 00:00:00', 0, 0, 0, '', '', '', '094325271', '', '', '', 2, '', '', '', ''),
(55, 'نصیر', 'صحت بخش', '0933237057', '1946-02-04 00:00:00', 3, 5, 0, '38427132', '09153008700', 'ملاصدرا 18 دادگر 18 پلاک 2 طبقه 4', '0933237057', '32219', '', '', 2, 's38427132@yahoo.com', '', '', ''),
(56, 'ویدا', 'ناصری', '0939715661', '2015-06-11 00:00:00', 3, 3, 0, '38798261', '09153166559', 'رضاشهر رودکی 4 پلاک 175 واحد6', '0939715661', '62578000', '', '', 2, 'rafi_naseri@yahoo.com', '', '', ''),
(57, 'حامد ', 'شفائی', '0932548912', '1982-07-24 00:00:00', 1, 5, 0, '', '09155142081', 'آزادی 13 پلاک 71', '0932548912', '1530', '', '', 3, '', '', '', ''),
(58, 'سمیرا ', 'شاپوری', '0941234567', '1984-05-12 00:00:00', 3, 5, 0, '', '09367948449', '', '0941234567', '1234', '', '', 3, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_vip`
--

CREATE TABLE IF NOT EXISTS `user_vip` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '-1',
  `tarikh_ezdevaj` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `fname_hamsar` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `lname_hamsar` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `shoghl_hamsar_id` int(11) NOT NULL,
  `tahsilat_hamsar_id` int(11) NOT NULL,
  `reshte_id` int(11) NOT NULL,
  `reshte_hamsar_id` int(11) NOT NULL,
  `grooh_khooni_hamsar_id` int(11) NOT NULL,
  `rang_1` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `rang_2` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `nooshidani` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `address_kar` mediumtext COLLATE utf8_persian_ci NOT NULL,
  `shekl_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vahed_mablagh`
--

CREATE TABLE IF NOT EXISTS `vahed_mablagh` (
`id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `vahed_mablagh`
--

INSERT INTO `vahed_mablagh` (`id`, `name`) VALUES
(1, 'ریال ایران'),
(2, 'دلار آمریکا'),
(3, 'یورو'),
(4, 'دینار کویت');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `access`
--
ALTER TABLE `access`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `access_det`
--
ALTER TABLE `access_det`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `airline`
--
ALTER TABLE `airline`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conf`
--
ALTER TABLE `conf`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `country`
--
ALTER TABLE `country`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `factor`
--
ALTER TABLE `factor`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `grooh_khooni`
--
ALTER TABLE `grooh_khooni`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `grop`
--
ALTER TABLE `grop`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hotel`
--
ALTER TABLE `hotel`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hotel_room`
--
ALTER TABLE `hotel_room`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `khadamat`
--
ALTER TABLE `khadamat`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `khadamat_factor`
--
ALTER TABLE `khadamat_factor`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `khadamat_tamin`
--
ALTER TABLE `khadamat_tamin`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `log`
--
ALTER TABLE `log`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mosafer`
--
ALTER TABLE `mosafer`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paper_attach_type`
--
ALTER TABLE `paper_attach_type`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paper_history`
--
ALTER TABLE `paper_history`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paper_letter`
--
ALTER TABLE `paper_letter`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `shomare` (`shomare`);

--
-- Indexes for table `paper_letter_det`
--
ALTER TABLE `paper_letter_det`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paper_letter_det_attach`
--
ALTER TABLE `paper_letter_det_attach`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paper_type`
--
ALTER TABLE `paper_type`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parvaz`
--
ALTER TABLE `parvaz`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `print_factor`
--
ALTER TABLE `print_factor`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `print_theme`
--
ALTER TABLE `print_theme`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reshte`
--
ALTER TABLE `reshte`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `session`
--
ALTER TABLE `session`
 ADD PRIMARY KEY (`pid`), ADD UNIQUE KEY `id` (`id`), ADD UNIQUE KEY `pid` (`pid`), ADD KEY `pid_2` (`pid`);

--
-- Indexes for table `shekl`
--
ALTER TABLE `shekl`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shoghl`
--
ALTER TABLE `shoghl`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tahsilat`
--
ALTER TABLE `tahsilat`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `taminkonande`
--
ALTER TABLE `taminkonande`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tamin_khadamat`
--
ALTER TABLE `tamin_khadamat`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tour`
--
ALTER TABLE `tour`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_vip`
--
ALTER TABLE `user_vip`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vahed_mablagh`
--
ALTER TABLE `vahed_mablagh`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `access`
--
ALTER TABLE `access`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `access_det`
--
ALTER TABLE `access_det`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `airline`
--
ALTER TABLE `airline`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `cache`
--
ALTER TABLE `cache`
MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `conf`
--
ALTER TABLE `conf`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `country`
--
ALTER TABLE `country`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `factor`
--
ALTER TABLE `factor`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `grooh_khooni`
--
ALTER TABLE `grooh_khooni`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `grop`
--
ALTER TABLE `grop`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `hotel`
--
ALTER TABLE `hotel`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `hotel_room`
--
ALTER TABLE `hotel_room`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `khadamat`
--
ALTER TABLE `khadamat`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `khadamat_factor`
--
ALTER TABLE `khadamat_factor`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `khadamat_tamin`
--
ALTER TABLE `khadamat_tamin`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mosafer`
--
ALTER TABLE `mosafer`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `paper_attach_type`
--
ALTER TABLE `paper_attach_type`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `paper_history`
--
ALTER TABLE `paper_history`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT for table `paper_letter`
--
ALTER TABLE `paper_letter`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `paper_letter_det`
--
ALTER TABLE `paper_letter_det`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT for table `paper_letter_det_attach`
--
ALTER TABLE `paper_letter_det_attach`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `paper_type`
--
ALTER TABLE `paper_type`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `parvaz`
--
ALTER TABLE `parvaz`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `print_factor`
--
ALTER TABLE `print_factor`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=53;
--
-- AUTO_INCREMENT for table `print_theme`
--
ALTER TABLE `print_theme`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `reshte`
--
ALTER TABLE `reshte`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `session`
--
ALTER TABLE `session`
MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `shekl`
--
ALTER TABLE `shekl`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `shoghl`
--
ALTER TABLE `shoghl`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tahsilat`
--
ALTER TABLE `tahsilat`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `taminkonande`
--
ALTER TABLE `taminkonande`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `tamin_khadamat`
--
ALTER TABLE `tamin_khadamat`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `tour`
--
ALTER TABLE `tour`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=59;
--
-- AUTO_INCREMENT for table `user_vip`
--
ALTER TABLE `user_vip`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `vahed_mablagh`
--
ALTER TABLE `vahed_mablagh`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
