-- phpMyAdmin SQL Dump
-- version 4.2.9.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 18, 2015 at 07:21 PM
-- Server version: 5.5.39
-- PHP Version: 5.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `crm`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`darma_sale`@`localhost` PROCEDURE `pc_check_saghf_enteghal`(IN cards_id INT,IN TARIKHH TIMESTAMP,IN MABLAGH INT,OUT RET INT)
BEGIN
                DECLARE TAR TIMESTAMP;
                DECLARE SAGHF_KHAR INT;
                DECLARE ROOZ_KHAR INT;
                DECLARE LKHARid INT;
                DECLARE CR CURSOR FOR SELECT TARIKH,SAGHF_ENTEGHAL,ROOZ_ENTEGHAL FROM cards
                        LEFT JOIN transactions ON (transactions.id=LAST_TRANS_KHARid) WHERE cards.id=cards_id;
                DECLARE CR1 CURSOR FOR SELECT LAST_TRANS_KHARid FROM cards  WHERE cards.id=cards_id;
                OPEN CR;
                SET RET := 0;
                FETCH CR INTO TAR,SAGHF_KHAR,ROOZ_KHAR;
                IF (DATE(TAR) = DATE(TARIKHH) AND SAGHF_KHAR>=ROOZ_KHAR+MABLAGH) THEN
                        SET RET := 1;
                ELSE
                        IF (DATE(TAR) <> DATE(TARIKHH)) THEN
                                UPDATE cards SET ROOZ_ENTEGHAL = 0 WHERE id = cards_id;
                                SET RET := 1;
                        END IF;
                END IF;
                CLOSE CR;
                IF (RET = 0) THEN
                        OPEN CR1;
                        FETCH CR1 INTO LKHARid;
                        IF (LKHARid <= 0) THEN
                                SET RET := 1;
                        END IF;
                END IF;
        END$$

CREATE DEFINER=`darma_sale`@`localhost` PROCEDURE `pc_check_saghf_kharid`(IN cards_id INT,IN TARIKHH TIMESTAMP,IN MABLAGH INT,OUT RET INT)
BEGIN
                DECLARE TAR TIMESTAMP;
                DECLARE SAGHF_KHAR INT;
                DECLARE ROOZ_KHAR INT;
                DECLARE LKHARid INT;
                DECLARE CR CURSOR FOR SELECT TARIKH,SAGHF_ROOZ,ROOZ_MABLAGH FROM cards
                        LEFT JOIN transactions ON (transactions.id=LAST_TRANS_KHARid) WHERE cards.id=cards_id;
                DECLARE CR1 CURSOR FOR SELECT LAST_TRANS_KHARid FROM cards  WHERE cards.id=cards_id;
                OPEN CR;
                SET RET := 0;
                FETCH CR INTO TAR,SAGHF_KHAR,ROOZ_KHAR;
                IF (DATE(TAR) = DATE(TARIKHH) AND SAGHF_KHAR>=ROOZ_KHAR+MABLAGH) THEN
                        SET RET := 1;
                ELSE
                        IF (DATE(TAR) <> DATE(TARIKHH)) THEN
                                UPDATE cards SET ROOZ_MABLAGH = 0 WHERE id = cards_id;
                                SET RET := 1;
                        END IF;
                END IF;
                CLOSE CR;
                IF (RET = 0) THEN
                        OPEN CR1;
                        FETCH CR1 INTO LKHARid;
                        IF (LKHARid <= 0) THEN
                                SET RET := 1;
                        END IF;
                END IF;
        END$$

CREATE DEFINER=`darma_sale`@`localhost` PROCEDURE `ps_check_saghf_enteghal`(IN cards_id INT,IN TARIKHH TIMESTAMP,IN MABLAGH INT,OUT RET INT)
BEGIN
                DECLARE TAR TIMESTAMP;
                DECLARE SAGHF_KHAR INT;
                DECLARE ROOZ_KHAR INT;
                DECLARE LKHARid INT;
                DECLARE CR CURSOR FOR SELECT TARIKH,SAGHF_ENTEGHAL,ROOZ_ENTEGHAL FROM cards
                        LEFT JOIN transactions ON (transactions.id=LAST_TRANS_KHARid) WHERE cards.id=cards_id;
                DECLARE CR1 CURSOR FOR SELECT LAST_TRANS_KHARid FROM cards  WHERE cards.id=cards_id;
                OPEN CR;
                SET RET := 0;
                FETCH CR INTO TAR,SAGHF_KHAR,ROOZ_KHAR;
                IF (DATE(TAR) = DATE(TARIKHH) AND SAGHF_KHAR>=ROOZ_KHAR+MABLAGH) THEN
                        SET RET := 1;
                ELSE
                        IF (DATE(TAR) <> DATE(TARIKHH)) THEN
                                UPDATE cards SET ROOZ_ENTEGHAL = 0 WHERE id = cards_id;
                                SET RET := 1;
                        END IF;
                END IF;
                CLOSE CR;
                IF (RET = 0) THEN
                        OPEN CR1;
                        FETCH CR1 INTO LKHARid;
                        IF (LKHARid <= 0) THEN
                                SET RET := 1;
                        END IF;
                END IF;
        END$$

CREATE DEFINER=`darma_sale`@`localhost` PROCEDURE `ps_check_saghf_kharid`(IN cards_id INT,IN TARIKHH TIMESTAMP,IN MABLAGH INT,OUT RET INT)
BEGIN
                DECLARE TAR TIMESTAMP;
                DECLARE SAGHF_KHAR INT;
                DECLARE ROOZ_KHAR INT;
                DECLARE LKHARid INT;
                DECLARE CR CURSOR FOR SELECT TARIKH,SAGHF_ROOZ,ROOZ_MABLAGH FROM cards
                        LEFT JOIN transactions ON (transactions.id=LAST_TRANS_KHARid) WHERE cards.id=cards_id;
                DECLARE CR1 CURSOR FOR SELECT LAST_TRANS_KHARid FROM cards  WHERE cards.id=cards_id;
                OPEN CR;
                SET RET := 0;
                FETCH CR INTO TAR,SAGHF_KHAR,ROOZ_KHAR;
                IF (DATE(TAR) = DATE(TARIKHH) AND SAGHF_KHAR>=ROOZ_KHAR+MABLAGH) THEN
                        SET RET := 1;
                ELSE
                        IF (DATE(TAR) <> DATE(TARIKHH)) THEN
                                UPDATE cards SET ROOZ_MABLAGH = 0 WHERE id = cards_id;
                                SET RET := 1;
                        END IF;
                END IF;
                CLOSE CR;
                IF (RET = 0) THEN
                        OPEN CR1;
                        FETCH CR1 INTO LKHARid;
                        IF (LKHARid <= 0) THEN
                                SET RET := 1;
                        END IF;
                END IF;
        END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `access`
--

CREATE TABLE IF NOT EXISTS `access` (
`id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL DEFAULT '-1',
  `page_name` varchar(50) NOT NULL,
  `is_group` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `access`
--

INSERT INTO `access` (`id`, `group_id`, `page_name`, `is_group`) VALUES
(1, 1, 'home', 1);

-- --------------------------------------------------------

--
-- Table structure for table `access_det`
--

CREATE TABLE IF NOT EXISTS `access_det` (
`id` int(11) NOT NULL,
  `acc_id` int(11) NOT NULL,
  `frase` varchar(100) CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `airline`
--

CREATE TABLE IF NOT EXISTS `airline` (
`id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `airline`
--

INSERT INTO `airline` (`id`, `name`) VALUES
(1, 'آسمان'),
(2, 'ماهان');

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE IF NOT EXISTS `cache` (
`id` bigint(20) NOT NULL,
  `tableName` varchar(150) COLLATE utf8_persian_ci NOT NULL,
  `data` longtext COLLATE utf8_persian_ci NOT NULL,
  `query` mediumtext COLLATE utf8_persian_ci NOT NULL,
  `createTime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `viewCount` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE IF NOT EXISTS `city` (
`id` int(11) NOT NULL,
  `name` varchar(150) COLLATE utf8_persian_ci NOT NULL,
  `iata` varchar(10) COLLATE utf8_persian_ci NOT NULL,
  `country_id` int(11) NOT NULL DEFAULT '1',
  `typ` int(11) NOT NULL DEFAULT '1' COMMENT 'یک داخلی دو خارجی سه زیارتی'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`id`, `name`, `iata`, `country_id`, `typ`) VALUES
(1, 'مشهد', 'MHD', 1, 1),
(2, 'تهران', 'THR', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `conf`
--

CREATE TABLE IF NOT EXISTS `conf` (
`id` int(11) NOT NULL,
  `key` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `value` mediumtext COLLATE utf8_persian_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `conf`
--

INSERT INTO `conf` (`id`, `key`, `value`) VALUES
(1, 'app', 'CRM'),
(2, 'title', 'CRM'),
(3, 'sender', 'info@gohar.ir'),
(4, 'sender_name', 'CRM'),
(5, 'changepass_subject', 'تغییر رمز عبور'),
(6, 'changepass_body', 'رمز عبور شما<br/>\r\n#pass#><br/>\r\nمی باشد'),
(7, 'hasPaper', 'TRUE'),
(8, 'home_page', 'home');

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE IF NOT EXISTS `country` (
`id` int(11) NOT NULL,
  `name` varchar(500) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`id`, `name`) VALUES
(1, 'ایران'),
(2, 'ترکیه');

-- --------------------------------------------------------

--
-- Table structure for table `factor`
--

CREATE TABLE IF NOT EXISTS `factor` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tarikh` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_creator` int(11) NOT NULL,
  `marhale` varchar(100) COLLATE utf8_persian_ci NOT NULL DEFAULT 'profile',
  `is_tasfieh` int(11) NOT NULL,
  `tarikh_tasfieh` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `commision` int(11) NOT NULL,
  `takhfif` int(11) NOT NULL,
  `jaieze` int(11) NOT NULL,
  `commision_girande` int(11) NOT NULL,
  `mablagh` int(11) NOT NULL,
  `mob` varchar(15) COLLATE utf8_persian_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `factor`
--

INSERT INTO `factor` (`id`, `user_id`, `tarikh`, `user_creator`, `marhale`, `is_tasfieh`, `tarikh_tasfieh`, `commision`, `takhfif`, `jaieze`, `commision_girande`, `mablagh`, `mob`, `email`) VALUES
(1, 18, '2015-05-17 17:29:05', 18, 'profile', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '', ''),
(2, 18, '2015-05-17 17:30:08', 18, 'profile', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '', ''),
(3, 18, '2015-05-17 17:32:05', 18, 'profile', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '', ''),
(4, 18, '2015-05-17 17:32:57', 18, 'profile', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '', ''),
(5, 18, '2015-05-17 17:44:00', 18, 'profile', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '', ''),
(6, 18, '2015-05-17 17:44:02', 18, 'profile', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '', ''),
(7, 19, '2015-05-17 18:25:52', 18, 'profile', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '', ''),
(8, 19, '2015-05-17 18:41:54', 18, 'profile', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '', ''),
(9, 19, '2015-05-17 18:42:07', 18, 'profile', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '', ''),
(10, 19, '2015-05-17 18:42:36', 18, 'profile', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '09332635752', 'm.mirsamie@gmail.com'),
(11, 18, '2015-05-17 18:53:09', 18, 'profile', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '', ''),
(12, 19, '2015-05-17 21:55:40', 18, 'profile', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '', ''),
(13, 19, '2015-05-17 22:54:00', 18, 'profile', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '', ''),
(14, 19, '2015-05-18 00:41:22', 18, 'profile', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '', ''),
(15, 19, '2015-05-18 07:10:03', 18, 'profile', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '', ''),
(16, 19, '2015-05-18 11:26:10', 18, 'profile', 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 0, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `grooh_khooni`
--

CREATE TABLE IF NOT EXISTS `grooh_khooni` (
`id` int(11) NOT NULL,
  `name` varchar(10) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `grooh_khooni`
--

INSERT INTO `grooh_khooni` (`id`, `name`) VALUES
(1, 'A+'),
(2, 'B+'),
(3, 'AB+'),
(4, 'A-'),
(5, 'B-'),
(6, 'AB-'),
(7, 'O-'),
(8, 'O+');

-- --------------------------------------------------------

--
-- Table structure for table `grop`
--

CREATE TABLE IF NOT EXISTS `grop` (
`id` int(11) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `en` int(11) NOT NULL DEFAULT '1'
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grop`
--

INSERT INTO `grop` (`id`, `name`, `en`) VALUES
(1, 'ارشد', 1),
(2, 'کانتر', 1),
(3, 'مشتری', 1);

-- --------------------------------------------------------

--
-- Table structure for table `hotel`
--

CREATE TABLE IF NOT EXISTS `hotel` (
`id` int(11) NOT NULL,
  `khadamat_factor_id` int(11) NOT NULL,
  `maghsad_id` int(11) NOT NULL,
  `az_tarikh` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ta_tarikh` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `gohar_hotel_id` int(11) NOT NULL DEFAULT '-1',
  `adl` int(11) NOT NULL,
  `chd` int(11) NOT NULL,
  `inf` int(11) NOT NULL,
  `factor_id` int(11) NOT NULL,
  `name` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `star` int(11) NOT NULL DEFAULT '5',
  `room_count` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `hotel`
--

INSERT INTO `hotel` (`id`, `khadamat_factor_id`, `maghsad_id`, `az_tarikh`, `ta_tarikh`, `gohar_hotel_id`, `adl`, `chd`, `inf`, `factor_id`, `name`, `star`, `room_count`) VALUES
(1, 14, 2, '2015-05-25 19:30:00', '2015-05-27 19:30:00', -1, 2, 1, 1, 0, 'ریتانا', 5, 1),
(2, 25, 2, '2015-06-17 19:30:00', '0000-00-00 00:00:00', -1, 2, 0, 0, 16, 'هلیا', 3, 0),
(3, 25, 2, '2015-06-14 19:30:00', '0000-00-00 00:00:00', -1, 1, 1, 1, 16, 'هلیا2', 4, 0),
(4, 25, 2, '2015-06-14 19:30:00', '0000-00-00 00:00:00', -1, 1, 1, 1, 16, 'هلیا2', 4, 0),
(5, 25, 2, '2015-06-14 19:30:00', '0000-00-00 00:00:00', -1, 1, 1, 1, 16, 'هلیا2', 4, 0),
(6, 25, 2, '2015-06-14 19:30:00', '0000-00-00 00:00:00', -1, 1, 1, 1, 16, 'هلیا2', 4, 0),
(7, 25, 2, '2015-06-14 19:30:00', '0000-00-00 00:00:00', -1, 1, 1, 1, 16, 'هلیا2', 4, 0);

-- --------------------------------------------------------

--
-- Table structure for table `hotel_room`
--

CREATE TABLE IF NOT EXISTS `hotel_room` (
`id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `extra_service` int(11) NOT NULL,
  `extra_service_chd` int(11) NOT NULL,
  `gasht` tinyint(1) NOT NULL,
  `transfer_raft` tinyint(1) NOT NULL,
  `transfer_vasat` tinyint(1) NOT NULL,
  `transfer_bargasht` tinyint(1) NOT NULL,
  `paziraii` tinyint(1) NOT NULL,
  `raft_city` int(11) NOT NULL,
  `raft_airline` int(11) NOT NULL,
  `raft_shomare` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `raft_saat_khorooj` time NOT NULL,
  `raft_saat_vorood` time NOT NULL,
  `vasat_city` int(11) NOT NULL,
  `vasat_airline` int(11) NOT NULL,
  `vasat_shomare` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `vasat_saat_khorooj` time NOT NULL,
  `vasat_saat_vorood` time NOT NULL,
  `bargasht_city` int(11) NOT NULL,
  `bargasht_airline` int(11) NOT NULL,
  `bargasht_shomare` int(11) NOT NULL,
  `bargasht_saat_khorooj` time NOT NULL,
  `bargasht_saat_vorood` time NOT NULL,
  `hotel_id` int(11) NOT NULL,
  `khadamat_factor_id` int(11) NOT NULL,
  `factor_id` int(11) NOT NULL,
  `adl` int(11) NOT NULL,
  `chd` int(11) NOT NULL,
  `inf` int(11) NOT NULL,
  `zarfiat` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `hotel_room`
--

INSERT INTO `hotel_room` (`id`, `name`, `extra_service`, `extra_service_chd`, `gasht`, `transfer_raft`, `transfer_vasat`, `transfer_bargasht`, `paziraii`, `raft_city`, `raft_airline`, `raft_shomare`, `raft_saat_khorooj`, `raft_saat_vorood`, `vasat_city`, `vasat_airline`, `vasat_shomare`, `vasat_saat_khorooj`, `vasat_saat_vorood`, `bargasht_city`, `bargasht_airline`, `bargasht_shomare`, `bargasht_saat_khorooj`, `bargasht_saat_vorood`, `hotel_id`, `khadamat_factor_id`, `factor_id`, `adl`, `chd`, `inf`, `zarfiat`) VALUES
(1, 'zsfsdafsdf', 0, 0, 0, 1, 1, 0, 0, 1, 1, '2112', '00:00:34', '00:00:12', 1, 2, '1212', '00:00:34', '00:00:56', 0, 0, 0, '00:00:00', '00:00:00', 1, 14, 10, 0, 0, 0, 0),
(2, 'lklkjlkjl', 0, 2, 0, 1, 1, 1, 0, 2, 1, '888888', '00:00:23', '00:00:54', 2, 1, '77777', '00:00:03', '00:00:04', 1, 1, 1546565, '00:00:00', '00:00:00', 1, 14, 10, 0, 0, 0, 0),
(6, 'دوتخته', 0, 2, 0, 1, 0, 1, 0, 0, 0, '', '00:00:00', '00:00:00', 0, 0, '', '00:00:00', '00:00:00', 0, 0, 0, '00:00:00', '00:00:00', 0, 25, 16, 2, 2, 1, 2),
(7, 'سه تخته', 1, 0, 1, 0, 1, 0, 1, 0, 0, '', '00:00:00', '00:00:00', 0, 0, '', '00:00:00', '00:00:00', 0, 0, 0, '00:00:00', '00:00:00', 0, 25, 16, 3, 0, 0, 3);

-- --------------------------------------------------------

--
-- Table structure for table `khadamat`
--

CREATE TABLE IF NOT EXISTS `khadamat` (
`id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `toz` mediumtext COLLATE utf8_persian_ci NOT NULL,
  `typ` int(11) NOT NULL DEFAULT '1' COMMENT 'یک پرواز ، دو هتل ، سه تور ، چهار کدملی و پنج شماره پاسپورت',
  `ordering` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `khadamat`
--

INSERT INTO `khadamat` (`id`, `name`, `toz`, `typ`, `ordering`) VALUES
(1, 'بلیت هواپیما داخلی', '', 1, 0),
(2, 'هتل داخلی', '', 2, 0),
(3, 'تور داخلی', '', 3, 0),
(4, 'ویزای شینگن', '', 4, 0),
(5, 'ویزای آمریکا', '', 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `khadamat_factor`
--

CREATE TABLE IF NOT EXISTS `khadamat_factor` (
`id` int(11) NOT NULL,
  `factor_id` int(11) NOT NULL,
  `khadamat_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `khadamat_factor`
--

INSERT INTO `khadamat_factor` (`id`, `factor_id`, `khadamat_id`) VALUES
(1, 3, 4),
(2, 4, 1),
(3, 4, 2),
(4, 5, 1),
(5, 5, 2),
(6, 6, 1),
(7, 6, 2),
(8, 7, 1),
(9, 8, 1),
(10, 10, 1),
(11, 9, 4),
(14, 10, 2),
(15, 11, 1),
(18, 12, 4),
(19, 13, 1),
(20, 13, 2),
(21, 14, 1),
(23, 15, 1),
(24, 15, 2),
(25, 16, 2);

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE IF NOT EXISTS `log` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `regdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `page` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `toz` mediumtext COLLATE utf8_persian_ci NOT NULL,
  `extra` mediumtext COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mosafer`
--

CREATE TABLE IF NOT EXISTS `mosafer` (
`id` int(11) NOT NULL,
  `fname` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `lname` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `code_melli` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `passport` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `passport_engheza` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `gender` int(11) NOT NULL DEFAULT '1',
  `age` varchar(4) COLLATE utf8_persian_ci NOT NULL DEFAULT 'adl',
  `tarikh_tavalod` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `khadamat_factor_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `mosafer`
--

INSERT INTO `mosafer` (`id`, `fname`, `lname`, `code_melli`, `passport`, `passport_engheza`, `gender`, `age`, `tarikh_tavalod`, `khadamat_factor_id`) VALUES
(13, 'ممم1', 'للل1', '1223', '', '0000-00-00 00:00:00', 1, 'adl', '2015-05-17 19:30:00', 10),
(14, 'سشش1', 'مهیابلرذنتی1', '564354', '', '0000-00-00 00:00:00', 1, 'chd', '2015-05-17 19:30:00', 10),
(15, 'شششش', 'نننن', '6343541', '', '0000-00-00 00:00:00', 1, 'adl', '0000-00-00 00:00:00', 14),
(16, '', '', '', '', '0000-00-00 00:00:00', 1, 'adl', '0000-00-00 00:00:00', 14),
(17, '', '', '', '', '0000-00-00 00:00:00', 1, 'chd', '0000-00-00 00:00:00', 14),
(18, '', '', '', '', '0000-00-00 00:00:00', 1, 'inf', '0000-00-00 00:00:00', 14);

-- --------------------------------------------------------

--
-- Table structure for table `paper_attach_type`
--

CREATE TABLE IF NOT EXISTS `paper_attach_type` (
`id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `extention` varchar(10) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `paper_attach_type`
--

INSERT INTO `paper_attach_type` (`id`, `name`, `extention`) VALUES
(1, 'pdf', 'pdf'),
(2, 'word', 'doc'),
(3, 'pic', 'img');

-- --------------------------------------------------------

--
-- Table structure for table `paper_history`
--

CREATE TABLE IF NOT EXISTS `paper_history` (
`id` int(11) NOT NULL,
  `letter_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_sender_id` int(11) NOT NULL,
  `tarikh` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `in_cartable` tinyint(1) NOT NULL DEFAULT '1',
  `vaziat` int(11) NOT NULL DEFAULT '1' COMMENT 'وضعیت یک خوانده نشده و دو خوانده شده و ۳ ارجاع شده۴ یعنی آرشیو',
  `is_roonevesht` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `paper_history`
--

INSERT INTO `paper_history` (`id`, `letter_id`, `user_id`, `user_sender_id`, `tarikh`, `in_cartable`, `vaziat`, `is_roonevesht`) VALUES
(1, 1, 20, 18, '2015-04-14 19:30:00', 0, 2, 0),
(2, 1, 19, 18, '2015-04-14 19:30:00', 1, 2, 0),
(3, 1, 21, 18, '2015-04-14 19:30:00', 1, 1, 1),
(5, 1, 18, 20, '2015-05-05 19:30:00', 0, 3, 0),
(6, 1, 20, 18, '2015-05-05 19:30:00', 0, 2, 0),
(7, 1, 18, 20, '2015-05-05 19:30:00', 0, 3, 1),
(8, 1, 20, 18, '2015-05-05 19:30:00', 0, 2, 1),
(9, 1, 19, 20, '2015-05-05 19:30:00', 1, 2, 0),
(10, 1, 18, 20, '2015-05-05 19:30:00', 0, 3, 1),
(11, 1, 20, 18, '2015-05-05 19:30:00', 0, 2, 0),
(12, 1, 19, 18, '2015-05-05 19:30:00', 1, 2, 1),
(13, 1, 18, 20, '2015-05-05 19:30:00', 0, 3, 0),
(14, 1, 20, 18, '2015-05-05 19:30:00', 0, 2, 0),
(15, 1, 18, 20, '2015-05-05 19:30:00', 0, 3, 1),
(16, 2, 20, 18, '2015-05-05 19:30:00', 1, 4, 0),
(17, 2, 19, 18, '2015-05-05 19:30:00', 1, 2, 1),
(18, 5, 20, 18, '2015-05-06 19:30:00', 1, 2, 0),
(19, 6, 19, 18, '2015-05-06 19:30:00', 1, 2, 0),
(20, 7, 20, 18, '2015-05-06 19:30:00', 1, 2, 0),
(21, 8, 20, 18, '2015-05-06 19:30:00', 1, 2, 0),
(22, 9, 20, 18, '2015-05-06 19:30:00', 1, 2, 0),
(23, 10, 20, 18, '2015-05-06 19:30:00', 1, 2, 0),
(24, 10, 19, 18, '2015-05-06 19:30:00', 1, 2, 1),
(25, 14, 19, 18, '2015-05-09 19:30:00', 1, 1, 0),
(26, 15, 19, 18, '2015-05-09 19:30:00', 1, 1, 0),
(27, 17, 19, 18, '2015-05-09 19:30:00', 1, 2, 0),
(28, 24, 19, 18, '2015-05-09 19:30:00', 1, 1, 0),
(29, 24, 21, 18, '2015-05-09 19:30:00', 1, 1, 0),
(30, 25, 18, 19, '2015-05-09 19:30:00', 0, 3, 0),
(31, 25, 19, 18, '2015-05-09 19:30:00', 0, 3, 0),
(32, 25, 20, 18, '2015-05-09 19:30:00', 1, 1, 1),
(33, 25, 18, 19, '2015-05-09 19:30:00', 1, 1, 0),
(34, 25, 18, 19, '2015-05-09 19:30:00', 1, 1, 0),
(35, 26, 18, 19, '2015-05-11 19:30:00', 1, 2, 0),
(36, 26, 18, 19, '2015-05-11 19:30:00', 1, 2, 0),
(37, 26, 20, 19, '2015-05-11 19:30:00', 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `paper_letter`
--

CREATE TABLE IF NOT EXISTS `paper_letter` (
`id` int(11) NOT NULL,
  `mozoo` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `shomare` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `user_creator_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `paper_letter`
--

INSERT INTO `paper_letter` (`id`, `mozoo`, `shomare`, `user_creator_id`, `type_id`) VALUES
(1, 'موضوع یک', '1562', 18, 4),
(2, 'new', '12345678', 18, 3),
(3, 'غر غر های عبدی', '156325', 18, 2),
(4, 'غر غر های عبدی', '234567', 20, 4),
(5, 'معرفی نرم افزار آساد', '۱۲۳۴', 18, 4),
(6, 'wwasdsa', '156325df', 18, 3),
(7, 'پ۱۱', '5456465', 18, 2),
(8, 'm12', '2131323', 18, 1),
(9, 'fgdgf', '3243434', 18, 3),
(10, 'hgfhgfhgf', '67435454', 18, 2),
(11, 'تستس', '15633', 20, 3),
(12, 'wwasdsa', '15623', 19, 4),
(13, 'gfhgfh', '345454', 18, 3),
(14, 'موضوع یک', '1', 18, 3),
(15, 'asdad', '2', 18, 3),
(16, 'غر غر های عبدی', '156322', 18, 4),
(17, 'موضوع دو', '159951', 18, 3),
(18, 'موضوع سه', '15963', 19, 3),
(19, 'dfsafsad', '32423434', 18, 3),
(20, 'xwadsd', '898089', 18, 3),
(21, 'ghghfgh', '86932876543', 18, 3),
(22, 'fjcdfbjmcbv', '1239989', 18, 3),
(23, ', .bn,v,mbm', '5414123434', 18, 3),
(24, 'sdfdsfd', '22132132', 18, 3),
(25, 'سلام', '2222', 19, 3),
(26, 'مرخصی', '1366', 19, 1);

-- --------------------------------------------------------

--
-- Table structure for table `paper_letter_det`
--

CREATE TABLE IF NOT EXISTS `paper_letter_det` (
`id` int(11) NOT NULL,
  `letter_id` int(11) NOT NULL,
  `user_creator_id` int(11) NOT NULL,
  `tarikh` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `matn` mediumtext COLLATE utf8_persian_ci NOT NULL,
  `emza` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'امضا شده است یا خیر',
  `is_pishnevis` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `paper_letter_det`
--

INSERT INTO `paper_letter_det` (`id`, `letter_id`, `user_creator_id`, `tarikh`, `matn`, `emza`, `is_pishnevis`) VALUES
(1, 1, 18, '2015-04-14 19:30:00', '<p>dxddd</p>\r\n', 0, 0),
(5, 1, 20, '2015-05-05 19:30:00', '<p>dsssssssss</p>\r\n', 0, 0),
(6, 1, 18, '2015-05-05 19:30:00', '<p>تو حاج میرزایی</p>\r\n', 1, 0),
(7, 1, 20, '2015-05-05 19:30:00', '<p>تو هم شاک.....ری عی</p><p>ها ها ....<img alt="wink" src="http://192.168.2.80/paper/assets/js/ckeditor/plugins/smiley/images/wink_smile.png" style="height:23px; width:23px" title="wink" /></p>', 1, 0),
(8, 1, 18, '2015-05-05 19:30:00', '<p>asdasdasdsdasdas</p>\r\n', 0, 0),
(9, 1, 20, '2015-05-05 19:30:00', '<p dir="RTL">جمعی از معلمان سراسر کشور پیش از ظهر امروز با رهبر معظم انقلاب اسلامی دیدار می&zwnj;کنند.</p>\r\n\r\n<p dir="RTL">به گزارش &laquo;تابناک&raquo;، به نقل از پایگاه اطلاع&zwnj;رسانی دفتر حفظ و نشر آثار حضرت آیت&zwnj;الله&zwnj;&zwnj;العظمی خامنه&zwnj;ای، جمعی از معلمان سراسر کشور پیش از ظهر امروز با رهبر معظم انقلاب اسلامی دیدار می&zwnj;کنند.</p>\r\n\r\n<p dir="RTL">مهم&zwnj;ترین فرازهای بیانات رهبر انقلاب به قرار زیر است:</p>\r\n\r\n<p dir="RTL">* هیبت ملت و نظام اسلامی باید محفوظ بماند/ این چند روز 2 مقام رسمی سیاسی امریکا تهدید نظامی کردند/ مذاکره زیر شبح تهدید چه معنایی دارد/ ملت مذاکره در سایه تهدید را بر نمی&zwnj;تابد/ چرا غلط زیادی و تهدید به حمله نظامی می&zwnj;کنند/ زمان رئیس&zwnj;جمهور قبلی امریکا گفتم دوران بزن در رو تمام شده/ پایتان گیر می&zwnj;افتد/ ملت ایران متعرض را رها نمی&zwnj;کند</p>\r\n\r\n<p dir="RTL">* آمریکا به مذاکرات کمتر از ما احتیاج ندارد تا بگوید ایران را پای میز مذاکره آوردیم و فلان مطلب را به او تحمیل کردیم/ با مذاکرات در زیر شبح تهدید موافق نیستم/ مذاکره&zwnj;کنندگان ما بروند با رعایت خطوط اصلی مذاکره کنند اما تحمیل، تحقیر و تهدید را هرگز تحمل نکنند</p>\r\n\r\n<p dir="RTL">&nbsp;</p>\r\n\r\n<p dir="RTL">* امریکا از جنایت عظیم سعودی در یمن حمایت می&zwnj;کند و به آنها اطلاعات نظامی و سلاح می&zwnj;دهد/ بی&zwnj;آبرویی از این بیشتر؟/ یک ملت را محاصره غذایی دارویی و انرژی کرده&zwnj;اید و می&zwnj;گویید کسی کمک نکند؟</p>\r\n\r\n<p dir="RTL">* آموزش و پرورش کانون اساسی برای خلق دنیای آینده است/ هرچه برای این دستگاه هزینه کنیم هزینه نیست سرمایه&zwnj;گذاری است/ مسئولان باید معیشت معلمان را مورد توجه ویژه و جزء مسائل درجه یک قرار دهند.</p>\r\n\r\n<p><br />\r\n<img alt="heart" src="http://192.168.2.80/paper/assets/js/ckeditor/plugins/smiley/images/heart.png" style="height:23px; width:23px" title="heart" /></p>\r\n\r\n<p dir="RTL">&nbsp;</p>\r\n\r\n<p dir="RTL">این خبر در حال تکمیل است</p>\r\n\r\n<p><img alt="cheeky" src="http://192.168.2.80/paper/assets/js/ckeditor/plugins/smiley/images/tongue_smile.png" style="height:23px; width:23px" title="cheeky" /></p>\r\n', 0, 0),
(10, 1, 18, '2015-05-05 19:30:00', '<p style="text-align:justify">الیاس نادران نماینده مردم تهران در مجلس شورای اسلامی در گفت&zwnj;وگو با خبرنگار پارلمانی<a href="http://www.farsnews.com/" style="margin: 0px; padding: 0px; text-decoration: none; color: rgb(176, 37, 37);">خبرگزاری فارس</a>، با اشاره به پیگیری سؤال از وزیر نفت و عدم دریافت هرگونه پاسخی از سوی زنگنه، گفت: پرونده کرسنت از ناحیه طرف ایرانی هیچ پیشرفتی نداشته است.</p>\r\n\r\n<p style="text-align:justify">وی با یادآوری محکوم شدن ایران در داوری لاهه اظهار داشت: مسئله اساسی درباره کرسنت این است که آنهایی که این فساد را انجام داده و در تخلف دخیل بوده&zwnj;اند نه تنها محاکمه نشدند بلکه از سوی وزیر به سمت&zwnj;هایی نیز منصوب شدند.</p>\r\n\r\n<p style="text-align:justify">نادران یکی از دلایل محکومیت ایران در دادگاه لاهه را اعاده به کار مدیران متخلف در زمینه کرسنت خواند و گفت: وزارت نفت در این باره پاسخ روشنی نداشت.</p>\r\n\r\n<p style="text-align:justify">وی افراد موثر در پرونده&zwnj;های کرسنت، استات&zwnj;اویل و چند پرونده دیگر را مشترک ذکر کرد و خاطرنشان کرد: این افراد اکنون در دولت و غیردولت سمت داشته و مشغول به کارند.</p>\r\n\r\n<p style="text-align:justify">نماینده مردم تهران در مجلس شورای اسلامی گفت: در مورد موضوع کرسنت عدم اعلام وصول سؤال ناشی از هیات رئیسه مجلس نیست چرا که شورای عالی امنیت ملی روال کار را معین کرده اما ایراد به هیات رئیسه مجلس این است که از شورای عالی امنیت ملی مطالبه به جریان انداختن پرونده را نمی&zwnj;کند.</p>\r\n', 1, 0),
(11, 1, 20, '2015-05-05 19:30:00', '<p>gfhfdhhgh</p>\r\n', 0, 0),
(12, 1, 18, '2015-05-05 19:30:00', '<p>asdsadsadasdsadasdsadsadasd</p>\r\n\r\n<p>asdsadasdsadsadsa</p>\r\n\r\n<p>dsadsa</p>\r\n\r\n<p>d</p>\r\n\r\n<p>sadas</p>\r\n\r\n<p>dasd</p>\r\n\r\n<p>sa</p>\r\n', 0, 0),
(13, 1, 20, '2015-05-05 19:30:00', '<p>sasdsadsd</p>\r\n', 0, 0),
(14, 2, 18, '2015-05-05 19:30:00', '<p>hghghghghghg</p>\r\n', 0, 0),
(15, 1, 18, '2015-05-06 19:30:00', '<p>نزن آغا ...</p>\r\n\r\n<p>عه....</p>\r\n\r\n<p><img alt="devil" src="http://192.168.3.80/paper/assets/js/ckeditor/plugins/smiley/images/devil_smile.png" style="height:23px; width:23px" title="devil" /></p>\r\n', 0, 0),
(16, 3, 18, '2015-05-06 19:30:00', '<p>با سلام&nbsp;</p>\r\n\r\n<p>محسن جان این حمید کشت مارو<img alt="angry" src="http://192.168.3.80/paper/assets/js/ckeditor/plugins/smiley/images/angry_smile.png" style="height:23px; width:23px" title="angry" /></p>\r\n', 0, 0),
(17, 4, 20, '2015-05-06 19:30:00', '<p>sdfdsdsfdsfsdsdfsdfsd</p>\r\n', 0, 1),
(18, 5, 18, '2015-05-06 19:30:00', '', 0, 0),
(19, 6, 18, '2015-05-06 19:30:00', '<p>تاریخ اولیه از 1 روز بعد باشد. ولی امروز را بتواند انتخاب کند اما روز قبل کمتر از امروز نشود و امکان جستجو در قبل را هم نداشته باشد</p>\r\n\r\n<p>در عکس تاریخ پرواز Nan/Nan خورده است.</p>\r\n\r\n<p>زمانی که در صفحه ورود اطلاعات هستیم و صفحه برای ورود نام یا نام خانوادگی عوض می شود نام فیلد ورودی هم بیاید.</p>\r\n\r\n<p><a id="asdcasdas" name="asdcasdas"></a></p>\r\n', 0, 0),
(20, 7, 18, '2015-05-06 19:30:00', '', 0, 0),
(21, 8, 18, '2015-05-06 19:30:00', '', 0, 0),
(22, 9, 18, '2015-05-06 19:30:00', '<p>gfhgfhgfhfg</p>\r\n\r\n<p>fghfg</p>\r\n\r\n<p>fghfgh</p>\r\n\r\n<p>fghfg</p>\r\n\r\n<p>gfhfgh</p>\r\n\r\n<p>&nbsp;</p>\r\n', 0, 0),
(23, 10, 18, '2015-05-06 19:30:00', '<p>hkghjfh</p>\r\n', 0, 0),
(24, 11, 20, '2015-05-06 19:30:00', '<p>سیبسیبسیب</p>\r\n', 0, 0),
(25, 12, 19, '2015-05-09 19:30:00', '<p>czsczxczxc</p>\r\n', 0, 0),
(26, 13, 18, '2015-05-09 19:30:00', '<p>3453454</p>\r\n\r\n<p>drgfgdf</p>\r\n', 0, 1),
(27, 14, 18, '2015-05-09 19:30:00', '<p>ssss</p>\r\n', 0, 0),
(28, 15, 18, '2015-05-09 19:30:00', '<p>asdasd</p>\r\n', 0, 0),
(29, 16, 18, '2015-05-09 19:30:00', '<p>سلام</p>\r\n', 1, 1),
(30, 17, 18, '2015-05-09 19:30:00', '<p>تست&nbsp;</p>\r\n', 0, 0),
(31, 18, 19, '2015-05-09 19:30:00', '<p>سشیب</p>\r\n', 0, 1),
(32, 19, 18, '2015-05-09 19:30:00', '<p>dfgfdg</p>\r\n', 0, 1),
(33, 20, 18, '2015-05-09 19:30:00', '<p>sadsad</p>\r\n', 1, 1),
(34, 21, 18, '2015-05-09 19:30:00', '<p>321213kjkmgdds</p>\r\n', 0, 1),
(35, 22, 18, '2015-05-09 19:30:00', '<p>cbnbhnfghfggfhgfxhg</p>\r\n', 0, 1),
(36, 23, 18, '2015-05-09 19:30:00', '<p>fdhnbvnbnvb</p>\r\n', 0, 0),
(37, 24, 18, '2015-05-09 19:30:00', '<p>cgxbv</p>\r\n\r\n<p>gvhf</p>\r\n', 0, 0),
(38, 25, 19, '2015-05-09 19:30:00', '<p>سلام خوبی</p>\r\n', 0, 0),
(39, 25, 18, '2015-05-09 19:30:00', '<p>hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii</p>\r\n', 0, 0),
(40, 25, 19, '2015-05-09 19:30:00', '<p>slm azize delam</p>\r\n', 0, 0),
(41, 25, 19, '2015-05-09 19:30:00', '<p>ششششششششششششششششششششششششششششششش</p>\r\n', 0, 0),
(42, 26, 19, '2015-05-11 19:30:00', '<p>تقاضای درخواست مرخصی دارم.</p>\r\n', 0, 0),
(43, 26, 19, '2015-05-11 19:30:00', '<p>تاریخ 2/25</p>\r\n', 0, 0),
(44, 26, 19, '2015-05-11 19:30:00', '<p>فردا</p>\r\n', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `paper_letter_det_attach`
--

CREATE TABLE IF NOT EXISTS `paper_letter_det_attach` (
`id` int(11) NOT NULL,
  `letter_det_id` int(11) NOT NULL,
  `attach_type_id` int(11) NOT NULL,
  `addr` varchar(1000) COLLATE utf8_persian_ci NOT NULL,
  `toz` mediumtext COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `paper_letter_det_attach`
--

INSERT INTO `paper_letter_det_attach` (`id`, `letter_det_id`, `attach_type_id`, `addr`, `toz`) VALUES
(1, 1, 2, '2015-04-15-04-19-11.jpg', 'تو ۱'),
(2, 1, 1, '2015-04-15-04-19-111.jpg', 'تو ۲'),
(3, 1, 2, '2015-04-15-04-19-112.jpg', 'تو ۳'),
(4, 2, 3, '2015-04-15-04-51-56.jpg', ''),
(5, 1, 3, '2015-04-15-05-17-42.jpg', ''),
(6, 1, 3, '2015-04-15-05-17-42.png', ''),
(7, 5, 1, '2015-05-06-11-54-22.pdf', ''),
(8, 6, 1, '2015-05-06-11-58-07.pdf', 'ندارد'),
(9, 7, 3, '2015-05-06-11-59-37.jpg', 'خودم'),
(10, 8, 1, '2015-05-06-12-06-17.pdf', ''),
(11, 9, 3, '2015-05-06-12-20-31.jpg', 'fgfdgff'),
(12, 10, 1, '2015-05-06-12-23-30.jpg', ''),
(13, 14, 3, '2015-05-06-13-03-20.png', ''),
(14, 15, 3, '2015-05-07-10-16-05.jpg', 'من خوشتیپ'),
(15, 18, 1, '2015-05-07-16-38-51.png', ''),
(16, 19, 3, '2015-05-07-19-41-57.jpg', ''),
(17, 30, 1, '2015-05-10-10-16-57.jpg', ''),
(23, 38, 3, '2015-05-10-14-03-11.jpg', 'ندارد'),
(24, 39, 3, '2015-05-10-14-10-30.png', 'admin'),
(25, 40, 3, '2015-05-10-14-15-09.jpg', 'نداااااااااااارد'),
(26, 41, 3, '2015-05-10-14-32-34.jpg', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `paper_type`
--

CREATE TABLE IF NOT EXISTS `paper_type` (
`id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `paper_type`
--

INSERT INTO `paper_type` (`id`, `name`) VALUES
(1, 'درخواست'),
(2, 'شکواییه'),
(3, 'پیشنهاد'),
(4, 'عادی');

-- --------------------------------------------------------

--
-- Table structure for table `parvaz`
--

CREATE TABLE IF NOT EXISTS `parvaz` (
`id` int(11) NOT NULL,
  `mabda_id` int(11) NOT NULL,
  `maghsad_id` int(11) NOT NULL,
  `airline` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `tarikh` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `saat` time NOT NULL DEFAULT '00:00:00',
  `khadamat_factor_id` int(11) NOT NULL,
  `gohar_voucher_id` int(11) NOT NULL DEFAULT '-1',
  `adl` int(11) NOT NULL,
  `chd` int(11) NOT NULL,
  `inf` int(11) NOT NULL,
  `factor_id` int(11) NOT NULL,
  `is_bargasht` tinyint(1) NOT NULL DEFAULT '0',
  `class_parvaz` varchar(10) COLLATE utf8_persian_ci NOT NULL,
  `saat_vorood` time NOT NULL DEFAULT '00:00:00',
  `airplain` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `shomare` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `ticket_type` int(11) NOT NULL COMMENT 'یک داخلی ، دو خارجی ، سه زیارتی'
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `parvaz`
--

INSERT INTO `parvaz` (`id`, `mabda_id`, `maghsad_id`, `airline`, `tarikh`, `saat`, `khadamat_factor_id`, `gohar_voucher_id`, `adl`, `chd`, `inf`, `factor_id`, `is_bargasht`, `class_parvaz`, `saat_vorood`, `airplain`, `shomare`, `ticket_type`) VALUES
(1, 1, 2, 'fsdafsdf', '2015-05-25 19:30:00', '06:28:12', 0, -1, 1, 0, 0, 0, 0, '', '00:00:00', '', '7892', 1),
(2, 2, 1, 'ایران ایر', '2015-06-15 19:30:00', '11:05:00', 10, -1, 1, 1, 0, 0, 0, 'y', '11:08:00', 'ایرباس', '1562', 0),
(11, 1, 2, 'ایران ایر', '2015-06-09 19:30:00', '01:01:00', 23, -1, 2, 0, 0, 15, 0, 'y', '04:02:00', 'ایرباس', '1562', 0),
(13, -1, -1, '', '0000-00-00 00:00:00', '00:00:00', 10, 11111, 1, 0, 0, 10, 0, '', '00:00:00', '', '', 0),
(14, -1, -1, '', '0000-00-00 00:00:00', '00:00:00', 10, -1, 1, 0, 0, 10, 1, '', '00:00:00', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `reshte`
--

CREATE TABLE IF NOT EXISTS `reshte` (
`id` int(11) NOT NULL,
  `name` varchar(500) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `session`
--

CREATE TABLE IF NOT EXISTS `session` (
`pid` int(11) NOT NULL,
  `id` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `data` mediumtext COLLATE utf8_persian_ci NOT NULL,
  `firstTime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastUpdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shekl`
--

CREATE TABLE IF NOT EXISTS `shekl` (
`id` int(11) NOT NULL,
  `name` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `pic` varchar(200) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shoghl`
--

CREATE TABLE IF NOT EXISTS `shoghl` (
`id` int(11) NOT NULL,
  `name` varchar(500) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `shoghl`
--

INSERT INTO `shoghl` (`id`, `name`) VALUES
(1, 'آزاد'),
(2, 'بیکار');

-- --------------------------------------------------------

--
-- Table structure for table `tahsilat`
--

CREATE TABLE IF NOT EXISTS `tahsilat` (
`id` int(11) NOT NULL,
  `name` varchar(500) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `tahsilat`
--

INSERT INTO `tahsilat` (`id`, `name`) VALUES
(1, 'بی سواد'),
(2, 'سیکل');

-- --------------------------------------------------------

--
-- Table structure for table `taminkonande`
--

CREATE TABLE IF NOT EXISTS `taminkonande` (
`id` int(11) NOT NULL,
  `name` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `toz` mediumtext COLLATE utf8_persian_ci NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `taminkonande`
--

INSERT INTO `taminkonande` (`id`, `name`, `toz`, `ordering`) VALUES
(1, 'رسپینا', '', 0),
(2, 'مارکو پلو', '', 0),
(3, 'امیرتوس', '', 0),
(4, 'ره بال آسمان', '', 0),
(5, 'هتل قصر', '', 0),
(6, 'هتل درویشی', '', 0),
(7, 'داخلی-دنیاسیر', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tamin_khadamat`
--

CREATE TABLE IF NOT EXISTS `tamin_khadamat` (
`id` int(11) NOT NULL,
  `factor_id` int(11) NOT NULL,
  `taminkonande_id` int(11) NOT NULL,
  `mablagh` int(11) NOT NULL,
  `vahed_mablagh_id` int(11) NOT NULL,
  `khadamat_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tour`
--

CREATE TABLE IF NOT EXISTS `tour` (
`id` int(11) NOT NULL,
  `name` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `factor_id` int(11) NOT NULL,
  `khadamat_factor_id` int(11) NOT NULL,
  `parvaz_id` int(11) NOT NULL,
  `hotel_id` int(11) NOT NULL,
  `tarikh` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `shab` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
`id` int(11) NOT NULL,
  `fname` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `lname` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `code_melli` varchar(30) COLLATE utf8_persian_ci NOT NULL,
  `tarikh_tavalod` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `shoghl_id` int(11) NOT NULL,
  `tahsilat_id` int(11) NOT NULL,
  `grooh_khooni_id` int(11) NOT NULL,
  `tell` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `mob` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `address` mediumtext COLLATE utf8_persian_ci NOT NULL,
  `user` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `pass` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `pass_emza` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `emza_path` varchar(1000) COLLATE utf8_persian_ci NOT NULL,
  `group_id` int(11) NOT NULL DEFAULT '-1',
  `email` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `passport` varchar(30) COLLATE utf8_persian_ci NOT NULL,
  `pic` varchar(100) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fname`, `lname`, `code_melli`, `tarikh_tavalod`, `shoghl_id`, `tahsilat_id`, `grooh_khooni_id`, `tell`, `mob`, `address`, `user`, `pass`, `pass_emza`, `emza_path`, `group_id`, `email`, `passport`, `pic`) VALUES
(18, 'حمید', 'عبدی', '1', '1969-03-21 00:00:00', 1, 1, 4, '05137648023', '09332635752', 'شهرکرد خیابان امام خمینی پلاک ۵', 'admin', 'admin', '1', '', 1, 'hscomp2002@gmail.com', '7', 'profile_2015-05-17-21-37-35.png'),
(19, 'مرجان', 'عسگرپور', '19', '1969-03-21 00:00:00', 1, 1, 4, '05137648023', '09332635752', 'شهرکرد خیابان امام خمینی پلاک ۵', '19', '1', '1', '', 1, 'hscomp2002@gmail.com', '', ''),
(20, 'محسن', 'حاج میرزا', '20', '1969-03-21 00:00:00', 1, 1, 6, '05137648023', '09332635752', 'کرج شهرک پردیس', '20', '1', '1', '', 3, 'hscomp2002@gmail.com', '', ''),
(21, 'عباس', 'میرباقری', '212121212121', '1969-03-21 00:00:00', 1, 1, 4, '05137648023', '09332635752', 'شهرکرد خیابان امام خمینی پلاک ۵', '21', '1', '1', '', 1, 'hscomp2002@gmail.com', '', ''),
(23, '4444', 'defs', '0945315697', '1985-05-24 00:00:00', 1, 1, 0, '05138653949', '09012085536', 'ملک آباد', '0945315697', '123', '', '', 3, 'mahtab_m.@yahoo.com', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_vip`
--

CREATE TABLE IF NOT EXISTS `user_vip` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '-1',
  `tarikh_ezdevaj` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `fname_hamsar` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `lname_hamsar` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `shoghl_hamsar_id` int(11) NOT NULL,
  `tahsilat_hamsar_id` int(11) NOT NULL,
  `reshte_id` int(11) NOT NULL,
  `reshte_hamsar_id` int(11) NOT NULL,
  `grooh_khooni_hamsar_id` int(11) NOT NULL,
  `rang_1` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `rang_2` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `nooshidani` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `address_kar` mediumtext COLLATE utf8_persian_ci NOT NULL,
  `shekl_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `access`
--
ALTER TABLE `access`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `access_det`
--
ALTER TABLE `access_det`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `airline`
--
ALTER TABLE `airline`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conf`
--
ALTER TABLE `conf`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `country`
--
ALTER TABLE `country`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `factor`
--
ALTER TABLE `factor`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `grooh_khooni`
--
ALTER TABLE `grooh_khooni`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `grop`
--
ALTER TABLE `grop`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hotel`
--
ALTER TABLE `hotel`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hotel_room`
--
ALTER TABLE `hotel_room`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `khadamat`
--
ALTER TABLE `khadamat`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `khadamat_factor`
--
ALTER TABLE `khadamat_factor`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `log`
--
ALTER TABLE `log`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mosafer`
--
ALTER TABLE `mosafer`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paper_attach_type`
--
ALTER TABLE `paper_attach_type`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paper_history`
--
ALTER TABLE `paper_history`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paper_letter`
--
ALTER TABLE `paper_letter`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `shomare` (`shomare`);

--
-- Indexes for table `paper_letter_det`
--
ALTER TABLE `paper_letter_det`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paper_letter_det_attach`
--
ALTER TABLE `paper_letter_det_attach`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paper_type`
--
ALTER TABLE `paper_type`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parvaz`
--
ALTER TABLE `parvaz`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reshte`
--
ALTER TABLE `reshte`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `session`
--
ALTER TABLE `session`
 ADD PRIMARY KEY (`pid`), ADD UNIQUE KEY `id` (`id`), ADD UNIQUE KEY `pid` (`pid`), ADD KEY `pid_2` (`pid`);

--
-- Indexes for table `shekl`
--
ALTER TABLE `shekl`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shoghl`
--
ALTER TABLE `shoghl`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tahsilat`
--
ALTER TABLE `tahsilat`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `taminkonande`
--
ALTER TABLE `taminkonande`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tamin_khadamat`
--
ALTER TABLE `tamin_khadamat`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tour`
--
ALTER TABLE `tour`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_vip`
--
ALTER TABLE `user_vip`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `access`
--
ALTER TABLE `access`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `access_det`
--
ALTER TABLE `access_det`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `airline`
--
ALTER TABLE `airline`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `cache`
--
ALTER TABLE `cache`
MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `conf`
--
ALTER TABLE `conf`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `country`
--
ALTER TABLE `country`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `factor`
--
ALTER TABLE `factor`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `grooh_khooni`
--
ALTER TABLE `grooh_khooni`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `grop`
--
ALTER TABLE `grop`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `hotel`
--
ALTER TABLE `hotel`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `hotel_room`
--
ALTER TABLE `hotel_room`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `khadamat`
--
ALTER TABLE `khadamat`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `khadamat_factor`
--
ALTER TABLE `khadamat_factor`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mosafer`
--
ALTER TABLE `mosafer`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `paper_attach_type`
--
ALTER TABLE `paper_attach_type`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `paper_history`
--
ALTER TABLE `paper_history`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `paper_letter`
--
ALTER TABLE `paper_letter`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `paper_letter_det`
--
ALTER TABLE `paper_letter_det`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `paper_letter_det_attach`
--
ALTER TABLE `paper_letter_det_attach`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `paper_type`
--
ALTER TABLE `paper_type`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `parvaz`
--
ALTER TABLE `parvaz`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `reshte`
--
ALTER TABLE `reshte`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `session`
--
ALTER TABLE `session`
MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `shekl`
--
ALTER TABLE `shekl`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `shoghl`
--
ALTER TABLE `shoghl`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tahsilat`
--
ALTER TABLE `tahsilat`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `taminkonande`
--
ALTER TABLE `taminkonande`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tamin_khadamat`
--
ALTER TABLE `tamin_khadamat`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tour`
--
ALTER TABLE `tour`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `user_vip`
--
ALTER TABLE `user_vip`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
