-- phpMyAdmin SQL Dump
-- version 4.2.9.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 20, 2015 at 11:55 AM
-- Server version: 5.5.39
-- PHP Version: 5.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `crm`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`darma_sale`@`localhost` PROCEDURE `pc_check_saghf_enteghal`(IN cards_id INT,IN TARIKHH TIMESTAMP,IN MABLAGH INT,OUT RET INT)
BEGIN
                DECLARE TAR TIMESTAMP;
                DECLARE SAGHF_KHAR INT;
                DECLARE ROOZ_KHAR INT;
                DECLARE LKHARid INT;
                DECLARE CR CURSOR FOR SELECT TARIKH,SAGHF_ENTEGHAL,ROOZ_ENTEGHAL FROM cards
                        LEFT JOIN transactions ON (transactions.id=LAST_TRANS_KHARid) WHERE cards.id=cards_id;
                DECLARE CR1 CURSOR FOR SELECT LAST_TRANS_KHARid FROM cards  WHERE cards.id=cards_id;
                OPEN CR;
                SET RET := 0;
                FETCH CR INTO TAR,SAGHF_KHAR,ROOZ_KHAR;
                IF (DATE(TAR) = DATE(TARIKHH) AND SAGHF_KHAR>=ROOZ_KHAR+MABLAGH) THEN
                        SET RET := 1;
                ELSE
                        IF (DATE(TAR) <> DATE(TARIKHH)) THEN
                                UPDATE cards SET ROOZ_ENTEGHAL = 0 WHERE id = cards_id;
                                SET RET := 1;
                        END IF;
                END IF;
                CLOSE CR;
                IF (RET = 0) THEN
                        OPEN CR1;
                        FETCH CR1 INTO LKHARid;
                        IF (LKHARid <= 0) THEN
                                SET RET := 1;
                        END IF;
                END IF;
        END$$

CREATE DEFINER=`darma_sale`@`localhost` PROCEDURE `pc_check_saghf_kharid`(IN cards_id INT,IN TARIKHH TIMESTAMP,IN MABLAGH INT,OUT RET INT)
BEGIN
                DECLARE TAR TIMESTAMP;
                DECLARE SAGHF_KHAR INT;
                DECLARE ROOZ_KHAR INT;
                DECLARE LKHARid INT;
                DECLARE CR CURSOR FOR SELECT TARIKH,SAGHF_ROOZ,ROOZ_MABLAGH FROM cards
                        LEFT JOIN transactions ON (transactions.id=LAST_TRANS_KHARid) WHERE cards.id=cards_id;
                DECLARE CR1 CURSOR FOR SELECT LAST_TRANS_KHARid FROM cards  WHERE cards.id=cards_id;
                OPEN CR;
                SET RET := 0;
                FETCH CR INTO TAR,SAGHF_KHAR,ROOZ_KHAR;
                IF (DATE(TAR) = DATE(TARIKHH) AND SAGHF_KHAR>=ROOZ_KHAR+MABLAGH) THEN
                        SET RET := 1;
                ELSE
                        IF (DATE(TAR) <> DATE(TARIKHH)) THEN
                                UPDATE cards SET ROOZ_MABLAGH = 0 WHERE id = cards_id;
                                SET RET := 1;
                        END IF;
                END IF;
                CLOSE CR;
                IF (RET = 0) THEN
                        OPEN CR1;
                        FETCH CR1 INTO LKHARid;
                        IF (LKHARid <= 0) THEN
                                SET RET := 1;
                        END IF;
                END IF;
        END$$

CREATE DEFINER=`darma_sale`@`localhost` PROCEDURE `ps_check_saghf_enteghal`(IN cards_id INT,IN TARIKHH TIMESTAMP,IN MABLAGH INT,OUT RET INT)
BEGIN
                DECLARE TAR TIMESTAMP;
                DECLARE SAGHF_KHAR INT;
                DECLARE ROOZ_KHAR INT;
                DECLARE LKHARid INT;
                DECLARE CR CURSOR FOR SELECT TARIKH,SAGHF_ENTEGHAL,ROOZ_ENTEGHAL FROM cards
                        LEFT JOIN transactions ON (transactions.id=LAST_TRANS_KHARid) WHERE cards.id=cards_id;
                DECLARE CR1 CURSOR FOR SELECT LAST_TRANS_KHARid FROM cards  WHERE cards.id=cards_id;
                OPEN CR;
                SET RET := 0;
                FETCH CR INTO TAR,SAGHF_KHAR,ROOZ_KHAR;
                IF (DATE(TAR) = DATE(TARIKHH) AND SAGHF_KHAR>=ROOZ_KHAR+MABLAGH) THEN
                        SET RET := 1;
                ELSE
                        IF (DATE(TAR) <> DATE(TARIKHH)) THEN
                                UPDATE cards SET ROOZ_ENTEGHAL = 0 WHERE id = cards_id;
                                SET RET := 1;
                        END IF;
                END IF;
                CLOSE CR;
                IF (RET = 0) THEN
                        OPEN CR1;
                        FETCH CR1 INTO LKHARid;
                        IF (LKHARid <= 0) THEN
                                SET RET := 1;
                        END IF;
                END IF;
        END$$

CREATE DEFINER=`darma_sale`@`localhost` PROCEDURE `ps_check_saghf_kharid`(IN cards_id INT,IN TARIKHH TIMESTAMP,IN MABLAGH INT,OUT RET INT)
BEGIN
                DECLARE TAR TIMESTAMP;
                DECLARE SAGHF_KHAR INT;
                DECLARE ROOZ_KHAR INT;
                DECLARE LKHARid INT;
                DECLARE CR CURSOR FOR SELECT TARIKH,SAGHF_ROOZ,ROOZ_MABLAGH FROM cards
                        LEFT JOIN transactions ON (transactions.id=LAST_TRANS_KHARid) WHERE cards.id=cards_id;
                DECLARE CR1 CURSOR FOR SELECT LAST_TRANS_KHARid FROM cards  WHERE cards.id=cards_id;
                OPEN CR;
                SET RET := 0;
                FETCH CR INTO TAR,SAGHF_KHAR,ROOZ_KHAR;
                IF (DATE(TAR) = DATE(TARIKHH) AND SAGHF_KHAR>=ROOZ_KHAR+MABLAGH) THEN
                        SET RET := 1;
                ELSE
                        IF (DATE(TAR) <> DATE(TARIKHH)) THEN
                                UPDATE cards SET ROOZ_MABLAGH = 0 WHERE id = cards_id;
                                SET RET := 1;
                        END IF;
                END IF;
                CLOSE CR;
                IF (RET = 0) THEN
                        OPEN CR1;
                        FETCH CR1 INTO LKHARid;
                        IF (LKHARid <= 0) THEN
                                SET RET := 1;
                        END IF;
                END IF;
        END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `print_factor`
--

CREATE TABLE IF NOT EXISTS `print_factor` (
`id` int(11) NOT NULL,
  `print_theme_id` int(11) NOT NULL,
  `factor_id` int(11) NOT NULL,
  `tarikh` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(11) NOT NULL,
  `data` mediumtext COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `print_factor`
--

INSERT INTO `print_factor` (`id`, `print_theme_id`, `factor_id`, `tarikh`, `user_id`, `data`) VALUES
(1, 1, 10, '2015-05-20 15:07:01', 23, '[]'),
(2, 1, 10, '2015-05-20 15:47:24', 23, '{"visa_country":" u0622u0644u0645u0627u0646","visa_type":" u0634u06ccu0646u06afu0646","visa_time":" u06f5 u0647u0641u062au0647","visa_number":"123587","visa_tarikh":"1393/03/16","visa_address":"u0645u0634u0647u062f u0627u06ccu0646u0627","visa_tel":"37648023","visa_jaddress":"u062au0647u0631u0627u0646 u0627u06ccu0646u0627","visa_jtel":"736982525","visa_hazine_mosafer":["7889878787","878798798787","98798798798798"],"visa_kasr_sefarat":"787979879878","visa_ghimat_nafar":"654654654654","visa_ajancy":"u0644u0627u0641u063au0641u0642u0627u0628u0627u0644u0628u0644u0628","save_form":"1"}'),
(3, 1, 10, '2015-05-20 15:48:19', 23, '[]'),
(4, 1, 10, '2015-05-20 15:49:09', 23, '[]'),
(5, 1, 10, '2015-05-20 15:50:11', 23, '[{"visa_country":" u0622u0644u0645u0627u0646"},{"visa_type":" u0634u06ccu0646u06afu0646"},{"visa_time":" u06f5 u0647u0641u062au0647"},{"visa_number":"123587"},{"visa_tarikh":"1393/03/16"},{"visa_address":"u0645u0634u0647u062f u0627u06ccu0646u0627"},{"visa_tel":"37648023"},{"visa_jaddress":"u062au0647u0631u0627u0646 u0627u06ccu0646u0627"},{"visa_jtel":"736982525"},{"visa_hazine_mosafer":["7889878787","878798798787","98798798798798"]},{"visa_kasr_sefarat":"787979879878"},{"visa_ghimat_nafar":"654654654654"},{"visa_ajancy":"u0644u0627u0641u063au0641u0642u0627u0628u0627u0644u0628u0644u0628"}]'),
(6, 1, 10, '2015-05-20 16:22:45', 23, '"1"'),
(7, 1, 10, '2015-05-20 16:22:55', 23, '"1"');

-- --------------------------------------------------------

--
-- Table structure for table `print_theme`
--

CREATE TABLE IF NOT EXISTS `print_theme` (
`id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_persian_ci NOT NULL,
  `matn` mediumtext COLLATE utf8_persian_ci NOT NULL,
  `matn2` mediumtext COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `print_theme`
--

INSERT INTO `print_theme` (`id`, `name`, `matn`, `matn2`) VALUES
(1, 'ویزای انفرادی شینگن', '        <p dir="rtl" lang="en-US" style="text-align: center;" align="right"><strong><span lang="fa-IR">به</span> <span lang="fa-IR">نام</span> <span lang="fa-IR">خدا</span></strong></p>        <p dir="rtl" align="right"><strong><span lang="ar-SA"><span lang="fa-IR">كشـور</span></span>:#visa_country#</strong></p>        <p dir="rtl" align="right"><strong><span lang="ar-SA"><span lang="fa-IR">نوع</span> <span lang="fa-IR">ويزا</span></span>:#visa_type#</strong></p>        <p dir="rtl" align="right"><strong><span lang="ar-SA"><span lang="fa-IR">مدت</span> <span lang="fa-IR">ويزا</span> </span>:#visa_time#</strong></p>        <p dir="rtl" style="text-align: left;" align="right"><strong><span lang="ar-SA"><span lang="fa-IR">شماره</span> </span>:#visa_number#</strong></p>        <p dir="rtl" style="text-align: left;" align="right"><strong><span lang="ar-SA"><span lang="fa-IR">تاريخ</span> </span>:#visa_tarikh#</strong></p>        <p dir="rtl" align="center"> </p>        <p dir="rtl" align="center"><span style="font-size: 14pt;"><strong>( <span lang="ar-SA"><span lang="fa-IR">توافقنـامه</span></span>)</strong></span></p>        <p dir="rtl" align="right"> </p>        <p dir="rtl" align="center"><strong><span lang="fa-IR">جهت اخذ رواديد </span>/<span lang="fa-IR">توافقنامه به صورت عادي فوري ،ترانزيت ،توريستي،تجاري</span></strong></p>        <p dir="rtl" align="center"><strong><span lang="ar-SA"><span lang="fa-IR">لطفا</span></span>"<span lang="ar-SA"><span lang="fa-IR">قبل</span> <span lang="fa-IR">از</span> <span lang="fa-IR">تقاضاي</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">متن</span> <span lang="fa-IR">توافقنامه</span> <span lang="fa-IR">و</span> <span lang="fa-IR">شرايط</span> <span lang="fa-IR">آن</span> <span lang="fa-IR">را</span> <span lang="fa-IR">مطالعه</span> <span lang="fa-IR">نمائيد</span> </span>.</strong></p>        <p dir="rtl" align="right"><strong><span lang="ar-SA"><span lang="fa-IR">اين</span> <span lang="fa-IR">توافقنامه</span> <span lang="fa-IR">بين</span> <span lang="fa-IR">متقاضي</span> <span lang="fa-IR">و</span> <span lang="fa-IR">يانماينده</span> <span lang="fa-IR">ايشان</span> <span lang="fa-IR">و</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">درخواست</span> <span lang="fa-IR">كننده</span> <span lang="fa-IR">دعوت</span> <span lang="fa-IR">نامه</span> <span lang="fa-IR">با</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">كه</span> <span lang="fa-IR">منبعد</span> <span lang="fa-IR">متقاضي</span> <span lang="fa-IR">ناميده</span> <span lang="fa-IR">ميشود</span> <span lang="fa-IR">از</span> <span lang="fa-IR">يك</span> <span lang="fa-IR">طرف</span> <span lang="fa-IR">و</span> <span lang="fa-IR">دفتر</span> <span lang="fa-IR">خدمات</span> <span lang="fa-IR">مسافرتي</span> <span lang="fa-IR">دنيا</span> <span lang="fa-IR">سير</span> <span lang="fa-IR">كه</span> <span lang="fa-IR">منبعد</span> <span lang="fa-IR">دفتر</span> <span lang="fa-IR">ناميده</span> <span lang="fa-IR">ميشود</span> <span lang="fa-IR">به</span> <span lang="fa-IR">شرح</span> <span lang="fa-IR">زير</span> <span lang="fa-IR">و</span> <span lang="fa-IR">ادامه</span> <span lang="fa-IR">آن</span> <span lang="fa-IR">در</span> <span lang="fa-IR">پشت</span> <span lang="fa-IR">اين</span> <span lang="fa-IR">برگ</span> <span lang="fa-IR">منعقدمي</span> <span lang="fa-IR">گردد</span></span>:</strong></p>        <p dir="rtl" align="right"><strong><span lang="ar-SA"><span lang="fa-IR">آدرس</span> <span lang="fa-IR">و</span> <span lang="fa-IR">تلفن</span> <span lang="fa-IR">محل</span> <span lang="fa-IR">سكونت</span> </span>:#visa_address# #visa_tel#</strong></p>        <p dir="rtl" align="right"><strong><span lang="ar-SA"><span lang="fa-IR">آدرس</span> <span lang="fa-IR">و</span> <span lang="fa-IR">تلفن</span> <span lang="fa-IR">محل</span> <span lang="fa-IR">كار</span></span>:#visa_jaddress# #visa_jtel#</strong></p>        <p dir="rtl" align="right"> </p>        <p dir="rtl" align="right"> </p>        <p dir="rtl" align="right"><strong><span lang="ar-SA"><span lang="fa-IR">تقاضا</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">دعوت</span> <span lang="fa-IR">نامه</span> <span lang="fa-IR">جهت</span> <span lang="fa-IR">خودم</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">همراه</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">همراهان</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">افراد</span> <span lang="fa-IR">ديگربه</span> <span lang="fa-IR">شرح</span> <span lang="fa-IR">زير</span> <span lang="fa-IR">دريك</span> <span lang="fa-IR">پاسپورت</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">در</span> <span lang="fa-IR">پاسپورتهاي</span> <span lang="fa-IR">جداگانه</span> <span lang="fa-IR">رادارم</span></span>: </strong></p>        <p dir="rtl" align="right"> </p>        <table dir="rtl" style="width: 100%; margin-left: auto; margin-right: auto;" width="594" cellspacing="1" cellpadding="7">        <tbody>        <tr valign="top">        <td bgcolor="#e0e0e0" width="25" height="13">        <p align="center"><strong><span lang="fa-IR">رديف</span></strong></p>        </td>        <td bgcolor="#e0e0e0" width="124">        <p align="center"><strong><span lang="fa-IR">نام ونام خانوادگي</span></strong></p>        </td>        <td bgcolor="#e0e0e0" width="69">        <p align="center"><strong><span lang="fa-IR">نام پدر</span></strong></p>        </td>        <td bgcolor="#e0e0e0" width="88">        <p align="center"><strong><span lang="fa-IR">شماره پاسپورت</span></strong></p>        </td>        <td bgcolor="#e0e0e0" width="210">        <p align="center"><strong><span lang="fa-IR">هزينه ويزا</span></strong></p>        </td>        </tr>        #hamrahan#        </tbody>        </table>        <p dir="rtl" align="right"> </p>        <p dir="rtl" align="right"><strong>1-<span lang="ar-SA"><span lang="fa-IR">اينجانب #fname1# #lname1# </span></span><span lang="ar-SA"><span lang="fa-IR">به</span> <span lang="fa-IR">عنوان</span> <span lang="fa-IR">درخواست</span> <span lang="fa-IR">كننده</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">دعوت</span> <span lang="fa-IR">نامه</span> <span lang="fa-IR">به</span> <span lang="fa-IR">عنوان</span> <span lang="fa-IR">متقاضي</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">نماينده</span> <span lang="fa-IR">متقاضي</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">دعوت</span> <span lang="fa-IR">نامه</span> <span lang="fa-IR">شناخته</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">گردم</span></span>.</strong></p>        <p dir="rtl" align="right"><strong>2-<span lang="ar-SA"><span lang="fa-IR">متقاضي</span> <span lang="fa-IR">متعهد</span> <span lang="fa-IR">ميگردد</span> <span lang="fa-IR">كه</span> <span lang="fa-IR">خودش</span> <span lang="fa-IR">و</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">افرادي</span> <span lang="fa-IR">كه</span> <span lang="fa-IR">برايشان</span> <span lang="fa-IR">تقاضاي</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">گردد</span> <span lang="fa-IR">پيش</span> <span lang="fa-IR">از</span> <span lang="fa-IR">انقضاءمدت</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">از</span> <span lang="fa-IR">كشور</span> <span lang="fa-IR">مقصد</span> <span lang="fa-IR">خارج</span> <span lang="fa-IR">گردد</span> <span lang="fa-IR">و</span> <span lang="fa-IR">در</span> <span lang="fa-IR">غير</span> <span lang="fa-IR">اينصورت</span> <span lang="fa-IR">مسئوليت</span> <span lang="fa-IR">هرگونه</span> <span lang="fa-IR">ضرر</span> <span lang="fa-IR">و</span> <span lang="fa-IR">زيان</span> <span lang="fa-IR">ناشي</span> <span lang="fa-IR">از</span> <span lang="fa-IR">آن</span> <span lang="fa-IR">را</span> <span lang="fa-IR">متقاضي</span> <span lang="fa-IR">شخصا</span></span>"<span lang="ar-SA"><span lang="fa-IR">بعهده</span> <span lang="fa-IR">خواهد</span> <span lang="fa-IR">داشت</span> </span>.</strong></p>        <p dir="rtl" align="right"><strong>3-<span lang="ar-SA"><span lang="fa-IR">هرگونه</span> <span lang="fa-IR">جرائم</span> <span lang="fa-IR">و</span> <span lang="fa-IR">هزينه</span> <span lang="fa-IR">هاي</span> <span lang="fa-IR">مالي</span> <span lang="fa-IR">ناشي</span> <span lang="fa-IR">از</span> <span lang="fa-IR">اقامت</span> <span lang="fa-IR">غيرمجاز</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">ناشي</span> <span lang="fa-IR">از</span> <span lang="fa-IR">اعمال</span> <span lang="fa-IR">غير</span> <span lang="fa-IR">مجاز</span> <span lang="fa-IR">به</span> <span lang="fa-IR">عهده</span> <span lang="fa-IR">متقاضي</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">باشد</span> <span lang="fa-IR">كه</span> <span lang="fa-IR">ملزم</span> <span lang="fa-IR">به</span> <span lang="fa-IR">جبران</span> <span lang="fa-IR">و</span> <span lang="fa-IR">پرداخت</span> <span lang="fa-IR">آن</span> <span lang="fa-IR">ميباشد</span> <span lang="fa-IR">و</span> <span lang="fa-IR">چنانچه</span> <span lang="fa-IR">اين</span> <span lang="fa-IR">دفتر</span> <span lang="fa-IR">نيزهزينه</span> <span lang="fa-IR">هايي</span> <span lang="fa-IR">را</span> <span lang="fa-IR">پرداخت</span> <span lang="fa-IR">نمايد</span> <span lang="fa-IR">متقاضي</span> <span lang="fa-IR">ملزم</span> <span lang="fa-IR">به</span> <span lang="fa-IR">جبران</span> <span lang="fa-IR">آن</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">باشد</span> </span></strong></p>        <p dir="rtl" align="right"><strong>4-<span lang="ar-SA"><span lang="fa-IR">درخواست</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">دعوت</span> <span lang="fa-IR">نامه</span> <span lang="fa-IR">با</span> <span lang="fa-IR">ارائه</span> <span lang="fa-IR">اصل</span> <span lang="fa-IR">پاسپورت</span> <span lang="fa-IR">وپرداخت</span> <span lang="fa-IR">تمام</span> <span lang="fa-IR">وجه</span> <span lang="fa-IR">الزامي</span> <span lang="fa-IR">است</span> </span>.</strong></p>        <p dir="rtl" align="right"><strong>5- <span lang="ar-SA"><span lang="fa-IR">در</span> <span lang="fa-IR">صورت</span> <span lang="fa-IR">تقاضاي</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">گروه</span> <span lang="fa-IR">بيش</span> <span lang="fa-IR">از</span> <span lang="fa-IR">يك</span> <span lang="fa-IR">نفر</span> <span lang="fa-IR">يا</span> </span>(<span lang="ar-SA"><span lang="fa-IR">چند</span> <span lang="fa-IR">نفر</span> <span lang="fa-IR">با</span> <span lang="fa-IR">يكديگر</span> </span>)<span lang="ar-SA"><span lang="fa-IR">شخص</span> <span lang="fa-IR">متقاضي</span> <span lang="fa-IR">و</span> <span lang="fa-IR">پرداخت</span> <span lang="fa-IR">كننده</span> <span lang="fa-IR">وجه</span> <span lang="fa-IR">نماينده</span> <span lang="fa-IR">ساير</span> <span lang="fa-IR">ين</span> <span lang="fa-IR">شناخته</span> <span lang="fa-IR">ميشود</span> </span>. <span lang="ar-SA"><span lang="fa-IR">اين</span> <span lang="fa-IR">دفتر</span> <span lang="fa-IR">صرفا</span></span>"<span lang="ar-SA"><span lang="fa-IR">به</span> <span lang="fa-IR">همان</span> <span lang="fa-IR">شخص</span> <span lang="fa-IR">ارائه</span> <span lang="fa-IR">خدمات</span> <span lang="fa-IR">و</span> <span lang="fa-IR">پاسخگويي</span> <span lang="fa-IR">خواهد</span> <span lang="fa-IR">نمود</span> <span lang="fa-IR">و</span> <span lang="fa-IR">با</span> <span lang="fa-IR">امضاءاين</span> <span lang="fa-IR">قرارداد</span> <span lang="fa-IR">تمامي</span> <span lang="fa-IR">مفادآن</span> <span lang="fa-IR">و</span> <span lang="fa-IR">مسئوليتها</span> <span lang="fa-IR">را</span> <span lang="fa-IR">از</span> <span lang="fa-IR">جانب</span> <span lang="fa-IR">خود</span> <span lang="fa-IR">و</span> <span lang="fa-IR">همراهان</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">پذيرد</span></span>.</strong></p>        <p dir="rtl" align="right"><strong>6-<span lang="ar-SA"><span lang="fa-IR">در</span> <span lang="fa-IR">صورت</span> <span lang="fa-IR">تقاضاي</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">بيش</span> <span lang="fa-IR">از</span> <span lang="fa-IR">يك</span> <span lang="fa-IR">نفر</span> <span lang="fa-IR">با</span> <span lang="fa-IR">پاسپورت</span> <span lang="fa-IR">جداگانه</span> <span lang="fa-IR">در</span> <span lang="fa-IR">آن</span> <span lang="fa-IR">واحد</span> </span>(<span lang="ar-SA"><span lang="fa-IR">مانند</span> <span lang="fa-IR">يك</span> <span lang="fa-IR">زوج</span> <span lang="fa-IR">با</span> <span lang="fa-IR">پاسپورتهاي</span> <span lang="fa-IR">جداگانه</span> <span lang="fa-IR">–</span> <span lang="fa-IR">يك</span> <span lang="fa-IR">خانواده</span> <span lang="fa-IR">با</span> <span lang="fa-IR">پاسپورتهاي</span> <span lang="fa-IR">جداگانه</span> <span lang="fa-IR">–</span> <span lang="fa-IR">چند</span> <span lang="fa-IR">نفر</span> <span lang="fa-IR">همراه</span> <span lang="fa-IR">و</span> <span lang="fa-IR">آشنا</span> <span lang="fa-IR">و</span> <span lang="fa-IR">غيره</span> </span>)<span lang="ar-SA"><span lang="fa-IR">در</span> <span lang="fa-IR">صورت</span> <span lang="fa-IR">مرفوض</span> <span lang="fa-IR">شدن</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">عدم</span> <span lang="fa-IR">صدور</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">براي</span> <span lang="fa-IR">بعضي</span> <span lang="fa-IR">از</span> <span lang="fa-IR">ايشان</span> <span lang="fa-IR">اين</span> <span lang="fa-IR">دفتر</span> <span lang="fa-IR">هيچگونه</span> <span lang="fa-IR">مسئوليتي</span> <span lang="fa-IR">را</span> <span lang="fa-IR">نمي</span> <span lang="fa-IR">پذيرد</span> <span lang="fa-IR">و</span> <span lang="fa-IR">منوط</span> <span lang="fa-IR">نمودن</span> <span lang="fa-IR">صدور</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">به</span> <span lang="fa-IR">يكديگر</span> <span lang="fa-IR">از</span> <span lang="fa-IR">نظر</span> <span lang="fa-IR">مقامات</span> <span lang="fa-IR">آن</span> <span lang="fa-IR">كشور</span> <span lang="fa-IR">اعتباري</span> <span lang="fa-IR">ندارد</span></span>.</strong></p>        <p dir="rtl" align="right"><strong>7-<span lang="ar-SA"><span lang="fa-IR">اين</span> <span lang="fa-IR">دفتر</span> <span lang="fa-IR">جهت</span> <span lang="fa-IR">تامين</span> <span lang="fa-IR">جاي</span> <span lang="fa-IR">پرواز</span> <span lang="fa-IR">تلاش</span> <span lang="fa-IR">خود</span> <span lang="fa-IR">را</span> <span lang="fa-IR">معطوف</span> <span lang="fa-IR">ميدارد</span> <span lang="fa-IR">ولي</span> <span lang="fa-IR">هيچگونه</span> <span lang="fa-IR">تعهد</span> <span lang="fa-IR">و</span> <span lang="fa-IR">مسئوليتي</span> <span lang="fa-IR">را</span> <span lang="fa-IR">نمي</span> <span lang="fa-IR">پذيرد</span> <span lang="fa-IR">،منوط</span> <span lang="fa-IR">نمودن</span> <span lang="fa-IR">رواديدبه</span> <span lang="fa-IR">تاريخ</span> <span lang="fa-IR">پرواز</span> <span lang="fa-IR">به</span> <span lang="fa-IR">اين</span> <span lang="fa-IR">دفتر</span> <span lang="fa-IR">ارتباطي</span> <span lang="fa-IR">نخواهد</span> <span lang="fa-IR">داشت</span> </span>.</strong></p>        <p dir="rtl" align="right"><strong>8- <span lang="ar-SA"><span lang="fa-IR">مدت</span> <span lang="fa-IR">اعتبار</span> <span lang="fa-IR">استفاده</span> <span lang="fa-IR">ازويزا</span> <span lang="fa-IR">و</span> <span lang="fa-IR">مدت</span> <span lang="fa-IR">اقامت</span> <span lang="fa-IR">در</span> <span lang="fa-IR">كشور</span> <span lang="fa-IR">مقصد</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">نقطه</span> <span lang="fa-IR">ترانزيت</span> <span lang="fa-IR">بسته</span> <span lang="fa-IR">به</span> <span lang="fa-IR">نوع</span> <span lang="fa-IR">درخواست</span> <span lang="fa-IR">و</span> <span lang="fa-IR">موافقت</span> <span lang="fa-IR">ويزاي</span> <span lang="fa-IR">صادره</span> <span lang="fa-IR">از</span> <span lang="fa-IR">طرف</span> <span lang="fa-IR">مقامات</span> <span lang="fa-IR">كشور</span> <span lang="fa-IR">مورد</span> <span lang="fa-IR">نظر</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">باشد</span> </span>.</strong></p>        <p dir="rtl" align="right"><strong>9-<span lang="ar-SA"><span lang="fa-IR">متقاضي</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">پذيرد</span> <span lang="fa-IR">صدور</span> <span lang="fa-IR">رواديد</span> </span>/<span lang="ar-SA"><span lang="fa-IR">دعوت</span> <span lang="fa-IR">نامه</span> <span lang="fa-IR">و</span> <span lang="fa-IR">مدت</span> <span lang="fa-IR">اقامت</span> <span lang="fa-IR">بستگي</span> <span lang="fa-IR">به</span> <span lang="fa-IR">مقامات</span> <span lang="fa-IR">كشور</span> <span lang="fa-IR">مورد</span> <span lang="fa-IR">نظر</span> <span lang="fa-IR">دارد</span> <span lang="fa-IR">لذا</span> <span lang="fa-IR">عدم</span> <span lang="fa-IR">صدور</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">دعوت</span> <span lang="fa-IR">نامه</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">صدور</span> <span lang="fa-IR">با</span> <span lang="fa-IR">تاريخ</span> <span lang="fa-IR">اعتبار</span> <span lang="fa-IR">متفاوت</span> <span lang="fa-IR">بستگي</span> <span lang="fa-IR">به</span> <span lang="fa-IR">كشور</span> <span lang="fa-IR">مربوطه</span> <span lang="fa-IR">دارد</span> <span lang="fa-IR">و</span> <span lang="fa-IR">حتي</span> <span lang="fa-IR">گاهي</span> <span lang="fa-IR">اوقات</span> <span lang="fa-IR">با</span> <span lang="fa-IR">وجود</span> <span lang="fa-IR">صدور</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">از</span> <span lang="fa-IR">ورود</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">عبور</span> <span lang="fa-IR">متقاضي</span> <span lang="fa-IR">به</span> <span lang="fa-IR">كشور</span> <span lang="fa-IR">مربوطه</span> <span lang="fa-IR">ممانعت</span> <span lang="fa-IR">به</span> <span lang="fa-IR">عمل</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">آيدكه</span> <span lang="fa-IR">اين</span> <span lang="fa-IR">امرصرفا</span></span>"<span lang="ar-SA"><span lang="fa-IR">به</span> <span lang="fa-IR">كشور</span> <span lang="fa-IR">مربوطه</span> <span lang="fa-IR">بستگي</span> <span lang="fa-IR">دارد</span> <span lang="fa-IR">و</span> <span lang="fa-IR">از</span> <span lang="fa-IR">حيطه</span> <span lang="fa-IR">عمل</span> <span lang="fa-IR">اين</span> <span lang="fa-IR">دفتر</span> <span lang="fa-IR">خارج</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">باشد</span> <span lang="fa-IR">،لذا</span> <span lang="fa-IR">اين</span> <span lang="fa-IR">دفتر</span> <span lang="fa-IR">هيچگونه</span> <span lang="fa-IR">مسئوليتي</span> <span lang="fa-IR">در</span> <span lang="fa-IR">قبال</span> <span lang="fa-IR">اهداف</span> <span lang="fa-IR">سفر</span> <span lang="fa-IR">مانند</span> <span lang="fa-IR">وقت</span> <span lang="fa-IR">سفارت</span> <span lang="fa-IR">،آزمون</span> <span lang="fa-IR">و</span> <span lang="fa-IR">مسائل</span> <span lang="fa-IR">كاري</span> <span lang="fa-IR">،مسائل</span> <span lang="fa-IR">مالي</span> <span lang="fa-IR">نمي</span> <span lang="fa-IR">تواند</span> <span lang="fa-IR">عهده</span> <span lang="fa-IR">دار</span> <span lang="fa-IR">باشد</span></span>.</strong></p>        <p dir="rtl" align="right"><strong>10-<span lang="ar-SA"><span lang="fa-IR">حداكثر</span> <span lang="fa-IR">مدت</span> <span lang="fa-IR">اخذ</span> <span lang="fa-IR">رواديد</span></span>30 <span lang="ar-SA"><span lang="fa-IR">مي</span> <span lang="fa-IR">باشد</span> <span lang="fa-IR">و</span> <span lang="fa-IR">پس</span> <span lang="fa-IR">از</span> <span lang="fa-IR">اين</span> <span lang="fa-IR">مدت</span> <span lang="fa-IR">در</span> <span lang="fa-IR">صورت</span> <span lang="fa-IR">عدم</span> <span lang="fa-IR">صدور</span> <span lang="fa-IR">رواديد</span> <span lang="fa-IR">تمام</span> <span lang="fa-IR">وجه</span> <span lang="fa-IR">پرداختي</span> <span lang="fa-IR">پس</span> <span lang="fa-IR">از</span> <span lang="fa-IR">كسر</span> <span lang="fa-IR">هزينه</span> <span lang="fa-IR">هاي</span> <span lang="fa-IR">مربو</span> <span lang="fa-IR">طه</span> <span lang="fa-IR">استرداد</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">گردد</span></span>. <span lang="ar-SA"><span lang="fa-IR">هزينه</span> <span lang="fa-IR">كسري</span> <span lang="fa-IR">درصورت</span> <span lang="fa-IR">عدم</span> <span lang="fa-IR">صدور</span> <span lang="fa-IR">ويزا</span> <span lang="fa-IR">از</span> <span lang="fa-IR">سوي</span> <span lang="fa-IR">سفارت</span> <span lang="fa-IR">مربوطه</span> <span lang="fa-IR">مبلغ</span> <span lang="fa-IR">جمعاً</span> #visa_kasr_sefarat#</span> <span lang="ar-SA"><span lang="fa-IR">ريال</span></span> <span lang="fa-IR">به</span> <span lang="fa-IR">ازاي</span> <span lang="fa-IR">هر</span> <span lang="fa-IR">نفر</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">باشد</span>.</strong></p>        <p dir="rtl" align="right"><strong>11-<span lang="fa-IR">پس از درخواست دعوتنامه </span>/ <span lang="fa-IR">رواديد استرداد وجه امكان پذير نمي باشد و دلايل بيماري ،فوت ،اشكال در پاسپورت انصراف ممنوعيت خروج از كشور و غيره قابل قبول نخواهد بود</span>.</strong></p>        <p dir="rtl" align="right"><strong>12- <span lang="fa-IR">متقاضي توجه و قبول مي نمايد كه گاهي اوقات صدور رواديد منوط به تاييد مقامات امنيتي كشور مربوطه مي باشد كه اين امر ممكن است تا </span>40 <span lang="fa-IR">روز طول بكشد.</span></strong></p>        <p dir="rtl" align="right"><strong>13- <span lang="ar-SA"><span lang="fa-IR">از</span> <span lang="fa-IR">متقاضي</span> <span lang="fa-IR">درخواست</span> <span lang="fa-IR">ميگردد</span> <span lang="fa-IR">در</span> <span lang="fa-IR">هنگام</span> <span lang="fa-IR">دريافت</span> <span lang="fa-IR">دعوت</span> <span lang="fa-IR">نامه</span> </span>/<span lang="ar-SA"><span lang="fa-IR">رواديد</span> <span lang="fa-IR">مشخصات</span> <span lang="fa-IR">پاسپورت</span> <span lang="fa-IR">خود</span> <span lang="fa-IR">و</span> <span lang="fa-IR">همراهان</span> <span lang="fa-IR">تطبيق</span> <span lang="fa-IR">دهد</span> <span lang="fa-IR">و</span> <span lang="fa-IR">هرگونه</span> <span lang="fa-IR">اشتباه</span> <span lang="fa-IR">يا</span> <span lang="fa-IR">اختلاف</span> <span lang="fa-IR">مشخصات</span> <span lang="fa-IR">ر</span> <span lang="fa-IR">ا</span> <span lang="fa-IR">اطلاع</span> <span lang="fa-IR">دهد</span> <span lang="fa-IR">در</span> <span lang="fa-IR">غير</span> <span lang="fa-IR">اينصورت</span> <span lang="fa-IR">دفتر</span> <span lang="fa-IR">مسئوليتي</span> <span lang="fa-IR">را</span> <span lang="fa-IR">نمي</span> <span lang="fa-IR">پذيرد</span> </span>.</strong></p>        <p dir="rtl" align="right"><strong>14-<span lang="fa-IR">ممنوع الخروج يا ممنوع الورود بودن متقاضي از كشور مبداءبه مقصد و يا بالعكس به اين دفتر ارتباطي نداشته و وظيفه اين دفترانجام شده تلقي مي گردد</span>.</strong></p>        <p dir="rtl" align="right"><strong>15-<span lang="fa-IR">اشتباهات و اشكالات مندرج در پاسپورت به عهد ه متقاضي مي باشد</span>.</strong></p>        <p dir="rtl" align="right"><strong>16-<span lang="ar-SA"><span lang="fa-IR">در</span> <span lang="fa-IR">مورد</span> <span lang="fa-IR">ويزاهاي</span> <span lang="fa-IR">گروهي</span> <span lang="fa-IR">چين</span> <span lang="fa-IR">حداقل</span> <span lang="fa-IR">نفرات</span> </span>5 <span lang="ar-SA"><span lang="fa-IR">نفر</span> <span lang="fa-IR">و</span> <span lang="fa-IR">ورود</span> <span lang="fa-IR">و</span> <span lang="fa-IR">خروج</span> <span lang="fa-IR">از</span> <span lang="fa-IR">مرزها</span> <span lang="fa-IR">نيزبايد</span> <span lang="fa-IR">با</span> <span lang="fa-IR">هم</span> <span lang="fa-IR">باشد</span> <span lang="fa-IR">و</span> <span lang="fa-IR">حداكثر</span> <span lang="fa-IR">زمان</span> <span lang="fa-IR">تهيه</span> <span lang="fa-IR">ويزا</span> </span>15<span lang="ar-SA"><span lang="fa-IR">تا</span> </span>20 <span lang="ar-SA"><span lang="fa-IR">روز</span> <span lang="fa-IR">كاري</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">باشد</span> <span lang="fa-IR">و</span> <span lang="fa-IR">در</span> <span lang="fa-IR">صورت</span> <span lang="fa-IR">رد</span> <span lang="fa-IR">شدن</span> <span lang="fa-IR">هر</span> <span lang="fa-IR">يك</span> <span lang="fa-IR">از</span> <span lang="fa-IR">نفرات</span> <span lang="fa-IR">اگرحد</span> <span lang="fa-IR">نصاب</span> <span lang="fa-IR">گروه</span> <span lang="fa-IR">به</span> <span lang="fa-IR">كمتر</span> <span lang="fa-IR">از</span> </span>5 <span lang="ar-SA"><span lang="fa-IR">نفر</span> <span lang="fa-IR">برسد</span> <span lang="fa-IR">ويزاي</span> <span lang="fa-IR">گروهي</span> <span lang="fa-IR">صادر</span> <span lang="fa-IR">نخواهد</span> <span lang="fa-IR">شد</span> <span lang="fa-IR">و</span> <span lang="fa-IR">اين</span> <span lang="fa-IR">شركت</span> <span lang="fa-IR">هيچگونه</span> <span lang="fa-IR">مسئوليتي</span> <span lang="fa-IR">دراين</span> <span lang="fa-IR">قبال</span> <span lang="fa-IR">نخواهد</span> <span lang="fa-IR">داشت</span> <span lang="fa-IR">وجه</span> <span lang="fa-IR">دعوتنامه</span> <span lang="fa-IR">كسر</span> <span lang="fa-IR">شده</span> <span lang="fa-IR">و</span> <span lang="fa-IR">باقيمانده</span> <span lang="fa-IR">به</span> <span lang="fa-IR">مسافر</span> <span lang="fa-IR">برگردانده</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">شود</span> </span>.</strong></p>        <p dir="rtl" align="right"><strong>17- <span lang="ar-SA"><span lang="fa-IR">مبلغ</span> #visa_ghimat_nafar#</span> <span lang="ar-SA"><span lang="fa-IR">در</span> <span lang="fa-IR">ازاي</span> <span lang="fa-IR">هر</span> <span lang="fa-IR">نفر</span> <span lang="fa-IR">تحويل</span> <span lang="fa-IR">مسئول</span> <span lang="fa-IR">ويزاي</span> <span lang="fa-IR">شركت</span> <span lang="fa-IR">جهانگردي</span> <span lang="fa-IR">دنياسير</span> <span lang="fa-IR">گرديد</span></span>.</strong></p>        <p dir="rtl" align="right"><strong>18-<span lang="fa-IR">مسئوليت صدور بليط و رزرو هتل و</span>....<span lang="fa-IR">قبل از صدور ويزا به عهده مسافر ميباشدو اين آژانس هيچگونه مسئوليتي ندارد</span>.</strong></p>        <p dir="rtl" align="right"><strong>19-<span lang="ar-SA"><span lang="fa-IR">شركت</span> <span lang="fa-IR">دنيا</span> <span lang="fa-IR">سير</span> <span lang="fa-IR">صرفا</span></span>" <span lang="ar-SA"><span lang="fa-IR">اقدام</span> <span lang="fa-IR">كننده</span> <span lang="fa-IR">جهت</span> <span lang="fa-IR">ويزا</span> <span lang="fa-IR">ميباشد</span> <span lang="fa-IR">نه</span> <span lang="fa-IR">صادر</span> <span lang="fa-IR">كننده</span> <span lang="fa-IR">ويزا</span></span></strong></p>        <p dir="rtl" align="right"><strong>20- <span lang="ar-SA"><span lang="fa-IR">آژانس #visa_ajancy#</span></span> <span lang="ar-SA"><span lang="fa-IR">يا</span> <span lang="fa-IR">جناب</span> #fname1# #lname1#</span> <span lang="ar-SA"><span lang="fa-IR">متعهد</span> <span lang="fa-IR">مي</span> <span lang="fa-IR">گردد</span> <span lang="fa-IR">كه</span> <span lang="fa-IR">كليه</span> <span lang="fa-IR">مفاد</span> <span lang="fa-IR">اين</span> <span lang="fa-IR">توافقنامه</span> <span lang="fa-IR">را</span> <span lang="fa-IR">بطور</span> <span lang="fa-IR">كامل</span> <span lang="fa-IR">مطالعه</span> <span lang="fa-IR">كرده</span> <span lang="fa-IR">و</span> <span lang="fa-IR">بعد</span> <span lang="fa-IR">تصميم</span> <span lang="fa-IR">به</span> <span lang="fa-IR">عقد</span> <span lang="fa-IR">اين</span> <span lang="fa-IR">توافقنامه</span> <span lang="fa-IR">گرفته</span> <span lang="fa-IR">اند</span></span>.</strong></p>        <p dir="rtl" align="right"> </p>        <table style="height: 59px; width: 100%; margin-left: auto; margin-right: auto;" width="789">        <tbody>        <tr>        <td style="text-align: right; vertical-align: middle;"><span style="font-size: 12pt;"><strong><span lang="fa-IR">مهر</span> <span lang="fa-IR">و</span> <span lang="fa-IR">امضاءمسئول</span> <span lang="fa-IR">بخش</span> <span lang="fa-IR">ويزا</span> </strong></span></td>        <td style="text-align: left; vertical-align: middle;"><span style="font-size: 12pt;"><strong><span lang="fa-IR">نام</span> <span lang="fa-IR">ونام</span> <span lang="fa-IR">خانوادگي</span> <span lang="fa-IR">مسافر</span></strong></span></td>        </tr>        <tr style="text-align: center;">        <td style="text-align: right; vertical-align: middle;"><span style="font-size: 12pt;"><strong><span lang="fa-IR">آژانس</span> <span lang="fa-IR">دنيا</span> <span lang="fa-IR">سير</span> </strong></span></td>        <td style="text-align: left; vertical-align: middle;"><span style="font-size: 12pt;"><strong>امضاء</strong></span></td>        </tr>        </tbody>        </table>        <p dir="rtl" style="text-align: right;" align="right"> </p>        <p dir="rtl" style="text-align: right;" align="right"> </p>        <p dir="rtl" align="right"> </p>', '    <tr valign="top">         <td width="25" height="2">         <p align="center"><strong>#index#</strong></p>         </td>         <td width="124">         <p align="center">#name#</p>         </td>         <td width="69">         <p align="center">#pedar#</p>         </td>         <td width="88">         <p dir="ltr" align="center">#passport#</p>         </td>         <td width="210">         <p align="center"> #visa_hazine_mosafer[]# </p>         </td>     </tr>');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `print_factor`
--
ALTER TABLE `print_factor`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `print_theme`
--
ALTER TABLE `print_theme`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `print_factor`
--
ALTER TABLE `print_factor`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `print_theme`
--
ALTER TABLE `print_theme`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
